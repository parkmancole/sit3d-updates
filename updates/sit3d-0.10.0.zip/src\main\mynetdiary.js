'use strict';
// MyNetDiary live sync (unofficial; MyNetDiary has no public API). Same approach as mfp.js: the user signs in to mynetdiary.com inside an
// app window (the app never sees the password), the browser session lives in a private per-user profile, and the app then reads the
// user's own food-diary day totals by stepping back through the diary page, exactly as a person would.
const fs = require('fs');
const cdp = require('./cdp.js');

const DIARY = 'https://www.mynetdiary.com/meals.do';

// Runs inside the diary page and returns the totals currently shown (the selected day).
const EXTRACT = `(() => {
  const t = document.body ? document.body.innerText : '';
  const label = t.split('Calorie Budget')[0].trim().split('\\n')[0].slice(0, 40);
  const m = /Eaten\\s+([0-9,]+)/.exec(t);
  if (!m) return { ok: false, label };
  const g = (name) => { const r = new RegExp(name + '\\\\s+([0-9,.]+)\\\\s+(?:left|over|target|no target)').exec(t); return r ? parseFloat(r[1].replace(/,/g, '')) : 0; };
  // individual foods: each meal section lists "<name, serving>" followed by ten values (calories, carbs, protein, fat, grade, sat fat, trans fat, fiber, sodium, calcium)
  const items = []; const parts = t.split(/(?:^|\\n)[ \\t]*(BREAKFAST|LUNCH|DINNER|SNACKS)[ \\t]*\\n/);
  const isNum = (x) => /^-?[0-9][0-9,]*(\\.[0-9]+)?$/.test(x); const isVal = (x) => isNum(x) || /^[A-F][+-]?$/.test(x) || x === '-' || x === '';
  for (let k = 1; k < parts.length; k += 2) {
    const meal = parts[k].charAt(0) + parts[k].slice(1).toLowerCase(); const lines = parts[k + 1].split('\\n').map((x) => x.trim());
    const clean = lines.filter((x) => x !== '' && x.indexOf('\\t') < 0);
    for (let i = 0; i + 10 < clean.length; i++) {
      const nm = clean[i]; if (isVal(nm) || /^(ADD|search|DONE|DETAILS|CANCEL)$/.test(nm) || nm.length < 2) continue;
      const v = clean.slice(i + 1, i + 11); if (!v.every(isVal) || !isNum(v[0])) continue;
      const n = (x) => (isNum(x) ? parseFloat(x.replace(/,/g, '')) : 0);
      items.push({ meal, name: nm, kcal: n(v[0]), carbs: n(v[1]), protein: n(v[2]), fat: n(v[3]), fiber: n(v[7]), sodium: n(v[8]), sugar: 0 }); i += 10;
    }
  }
  return { ok: true, label, kcal: parseFloat(m[1].replace(/,/g, '')), carbs: g('Carbs'), protein: g('Protein'), fat: g('Total Fat'), fiber: g('Fiber'), sodium: g('Sodium'), items };
})()`;
const CLICK_PREV = `(() => { const b = document.querySelector('[aria-label="Go to Previous day"],[title="Go to Previous day"]'); if (b) { b.click(); return true; } return false; })()`;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rmrf = (p) => { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } };
const localIso = (d) => { const z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };
const addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return localIso(d); };

async function waitDiary(drv, ms) { const t0 = Date.now(); while (Date.now() - t0 < ms) { const r = await drv.evalJs(EXTRACT).catch(() => null); if (r && r.ok) return r; await sleep(500); } return null; }

// Opens a normal Edge/Chrome window on MyNetDiary (any sign-in method works there, including Google). Once the diary can be read the login
// is made to last 30 days, the window is closed and true is returned.
async function connect(parent, userId, log, profileDir) {
  const L = (m) => { try { if (log) log('mynetdiary login: ' + m); } catch (e) { /* ignore */ } };
  let drv; try { drv = await cdp.launch({ profileDir, headless: false, app: true, url: 'https://www.mynetdiary.com/' }); } catch (e) { L('browser start failed: ' + e.message); throw e; }
  L('browser opened'); const t0 = Date.now(); let lastCheck = 0, ok = false;
  try {
    while (!drv.exited() && Date.now() - t0 < 15 * 60 * 1000) {
      await sleep(1500); const u = await drv.url(); if (!u) continue;
      if (!/^https:\/\/([a-z0-9-]+\.)*mynetdiary\.com\/(dashboard|meals|plan|settings|analysis)\.do/.test(u)) continue;
      if (Date.now() - lastCheck < 6000) continue; lastCheck = Date.now(); L('signed-in page ' + u.split('?')[0]);
      await drv.goto(DIARY).catch(() => {}); const r = await waitDiary(drv, 15000); L('diary check -> ' + JSON.stringify({ ok: !!(r && r.ok) }));
      if (r && r.ok) { ok = true; break; }
    }
    if (ok) { const n = await drv.persistSessionCookies(30).catch(() => 0); L('login kept for 30 days (' + n + ' cookies)'); }
  } finally { await drv.close(); }
  if (!ok) {
    try { const h = await cdp.launch({ profileDir, headless: true, url: 'about:blank' }); try { await h.goto(DIARY); const r = await waitDiary(h, 15000); ok = !!(r && r.ok); L('check after close -> ' + ok); } finally { await h.close(); } } catch (e) { L('check after close failed: ' + String(e.message).slice(0, 100)); }
  }
  L('finished ' + ok); return ok;
}

// Reads each day from today back to fromIso by stepping the diary's date selector.   onDays(days, foods)
async function sync(userId, fromIso, onProgress, onDays, profileDir, log) {
  const L = (m) => { try { if (log) log('mynetdiary sync: ' + m); } catch (e) { /* ignore */ } };
  const today = localIso(new Date()); const total = Math.max(1, Math.round((new Date(today + 'T12:00:00') - new Date(fromIso + 'T12:00:00')) / 86400000) + 1);
  const days = {}, foods = {}; let read = 0, noData = 0;
  const drv = await cdp.launch({ profileDir, headless: true, url: 'about:blank' });
  try {
    await drv.goto(DIARY).catch(() => {}); let cur = await waitDiary(drv, 25000);
    if (!cur) { L('diary not readable (not signed in?) at ' + String(await drv.url()).split('?')[0]); throw new Error('NEED_LOGIN'); }
    for (let i = 0; i < total; i++) {
      const d = addDays(today, -i);
      if (cur.kcal > 0) { days[d] = { kcal: cur.kcal, carbs: cur.carbs, protein: cur.protein, fat: cur.fat, fiber: cur.fiber, sodium: cur.sodium, sugar: 0, n: 1 }; foods[d] = cur.items || []; read++; } else noData++;
      if (onProgress) onProgress({ p: (i + 1) / total, day: d });
      if (Object.keys(days).length >= 10 && onDays) { onDays(days, foods); for (const k of Object.keys(days)) delete days[k]; for (const k of Object.keys(foods)) delete foods[k]; }
      if (i === total - 1) break;
      const before = cur.label; const clicked = await drv.evalJs(CLICK_PREV);
      if (!clicked) throw new Error('The MyNetDiary diary page looks different than expected, so syncing stopped.');
      let next = null; const t0 = Date.now();
      while (Date.now() - t0 < 8000) { await sleep(350); const r = await drv.evalJs(EXTRACT).catch(() => null); if (r && r.ok && r.label !== before) { next = r; break; } }
      if (!next) throw new Error('MyNetDiary did not change day as expected, so syncing stopped.');
      await sleep(500); const settled = await drv.evalJs(EXTRACT).catch(() => null); cur = settled && settled.ok ? settled : next;
    }
    if (onDays && Object.keys(days).length) onDays(days, foods);
    return { read, noData, from: fromIso, to: today };
  } finally { await drv.close(); }
}

// MyNetDiary keeps weigh-ins on its Health/Analysis screens, which are part of the single-page app, so the menu is walked like a person would:
// open each top menu, click anything called "weight", and read the dates and weights that appear. Returns { 'YYYY-MM-DD': kg }.
const CLICK_TEXT = (re, exact) => `(() => { const r = new RegExp(${JSON.stringify(re)}, 'i'); const els = Array.from(document.querySelectorAll('a,button,li,div,span,td,h3')).filter((e) => e.offsetParent && e.children.length <= 1 && ${exact ? 'r.test(e.textContent.trim())' : 'r.test(e.textContent.trim()) && e.textContent.trim().length < 40'}); const e = els[els.length > 1 ? 0 : 0]; if (!e) return false; e.click(); return e.textContent.trim().slice(0, 40); })()`;
async function syncWeights(profileDir, log, hintUnit) {
  const L = (m) => { try { if (log) log('mynetdiary weights: ' + m); } catch (e) { /* ignore */ } };
  const { parseWeightText } = require('./weights_parse.js'); const drv = await cdp.launch({ profileDir, headless: true, url: 'about:blank' });
  try {
    await drv.goto(DIARY).catch(() => {}); const cur = await waitDiary(drv, 25000); if (!cur) throw new Error('NEED_LOGIN');
    const read = async () => parseWeightText(await drv.evalJs("document.body ? document.body.innerText : ''"), hintUnit);
    for (const menu of ['^HEALTH$', '^ANALYSIS$', '^PLAN$', '^DASHBOARD$']) {
      const m = await drv.evalJs(CLICK_TEXT(menu, true)); if (!m) continue; await sleep(1200);
      for (const item of ['^weight( chart| history| progress| tracking)?$', 'weight']) {
        const it = await drv.evalJs(CLICK_TEXT(item, false)); if (!it) continue; L('opened ' + menu + ' > ' + it); await sleep(2500);
        let got = await read(); let n = Object.keys(got).length;
        if (n >= 2) {   // load older rows: scroll down and press anything that looks like "more / older"
          for (let k = 0; k < 25; k++) {
            await drv.evalJs("(() => { window.scrollTo(0, document.body.scrollHeight); document.querySelectorAll('*').forEach((e) => { if (e.offsetParent && e.children.length === 0 && /^(show more|load more|more|older|previous|prev|see all|all|show all)$/i.test(e.textContent.trim())) e.click(); }); const sc = Array.from(document.querySelectorAll('*')).filter((e) => e.scrollHeight > e.clientHeight + 40 && /auto|scroll/.test(getComputedStyle(e).overflowY)); sc.forEach((e) => { e.scrollTop = e.scrollHeight; }); return true; })()").catch(() => null);
            await sleep(900); const more = await read(); const n2 = Object.keys(more).length; got = Object.assign(got, more); if (Object.keys(got).length <= n) break; n = Object.keys(got).length;
          }
          L('read ' + n + ' weigh-ins'); return got;
        }
      }
      await drv.goto(DIARY).catch(() => {}); await waitDiary(drv, 15000);
    }
    const sample = await drv.evalJs("document.body ? document.body.innerText.replace(/\s+/g, ' ').slice(0, 260) : ''"); L('no weight list found; page text starts: ' + JSON.stringify(sample)); return {};
  } finally { await drv.close(); }
}

async function disconnect(userId, profileDir) { rmrf(profileDir); }

module.exports = { connect, sync, syncWeights, disconnect, EXTRACT, localIso, addDays };
