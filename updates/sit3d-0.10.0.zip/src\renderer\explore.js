(function () {
'use strict';
// Dashboard "Explore" card: interactive trends (compare any metrics, hover to read them), a food calendar, weekday patterns,
// a food finder and an eating-vs-weight relationship view. Everything respects the global filter bar (date range) above it.
const S3 = window.S3, $ = (s, r) => (r || document).querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const DAY = 86400000, WD = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const isoOf = (ms) => { const d = new Date(ms), z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };
const msOf = (iso) => new Date(iso + 'T12:00:00').getTime();
const wdIdx = (iso) => (new Date(iso + 'T12:00:00').getDay() + 6) % 7;      // Monday = 0
const loadX = () => { try { return Object.assign({ tab: 'trends', pick: ['weight', 'body_fat'], cm: 'kcal', wd: [1, 1, 1, 1, 1, 1, 1], meal: {}, q: '', sort: 'kcal' }, JSON.parse(localStorage.getItem('sit3d.explore') || '{}')); } catch (e) { return { tab: 'trends', pick: ['weight', 'body_fat'], cm: 'kcal', wd: [1, 1, 1, 1, 1, 1, 1], meal: {}, q: '', sort: 'kcal' }; } };
const X = S3.dashX = S3.dashX || loadX(); const saveX = () => { try { localStorage.setItem('sit3d.explore', JSON.stringify(X)); } catch (e) { /* ignore */ } };
const chip = (on, attrs, label, dot) => `<button type="button" class="chip ${on ? 'on' : ''}" ${attrs}>${dot ? '<i style="background:' + dot + '"></i>' : ''}${label}</button>`;

let D = null;   // loaded data
async function loadData() {
  const [all, pg, scans] = await Promise.all([S3.api('nutrition:all').catch(() => ({ days: {}, weights: {} })), S3.api('nutrition:progress', 400).catch(() => null), S3.api('scans:list').catch(() => [])]);
  D = { days: all.days || {}, pg, scans, foods: null };
}
async function ensureFoods() { if (D.foods) return; try { D.foods = await S3.api('nutrition:foods'); } catch (e) { D.foods = {}; } }

// ---- series catalogue ----
const wt = (kg) => S3.kgVal(kg), ln = (cm) => S3.cmVal(cm);
function roll(field, win) {
  const keys = Object.keys(D.days).filter((d) => D.days[d].kcal >= 800).sort(); const out = [];
  keys.forEach((d) => { const t = msOf(d); const w = keys.filter((k) => { const x = msOf(k); return x <= t && x > t - win * DAY; }); if (w.length >= 3) out.push({ t: d + 'T12:00:00', v: w.reduce((a, k) => a + (D.days[k][field] || 0), 0) / w.length }); });
  return out;
}
const scanPts = (f) => D.scans.filter((s) => f(s) != null).map((s) => ({ t: s.created, v: f(s) }));
function catalogue() {
  const wAll = []; ((D.pg && D.pg.weights) || []).forEach((p) => wAll.push({ t: p.t, v: wt(p.v) })); ((D.pg && D.pg.scanWeights) || []).forEach((p) => wAll.push({ t: p.t, v: wt(p.v) })); wAll.sort((a, b) => (a.t < b.t ? -1 : 1));
  return {
    weight: { label: 'Weight', color: '#3B82F6', unit: S3.unitsWt(), pts: wAll, dec: 1 },
    body_fat: { label: 'Body fat', color: '#10B981', unit: '%', pts: scanPts((s) => s.body_fat_pct), dec: 1 },
    lean: { label: 'Lean mass', color: '#8B5CF6', unit: S3.unitsWt(), pts: scanPts((s) => (s.lean_mass_kg == null ? null : wt(s.lean_mass_kg))), dec: 1 },
    waist: { label: 'Waist', color: '#E5484D', unit: S3.unitsLen(), pts: scanPts((s) => (s.waist_cm == null ? null : ln(s.waist_cm))), dec: 1 },
    hips: { label: 'Hips', color: '#D97706', unit: S3.unitsLen(), pts: scanPts((s) => (s.hips_cm == null ? null : ln(s.hips_cm))), dec: 1 },
    chest: { label: 'Chest', color: '#0EA5E9', unit: S3.unitsLen(), pts: scanPts((s) => (s.chest_cm == null ? null : ln(s.chest_cm))), dec: 1 },
    shape: { label: 'Shape score', color: '#EC4899', unit: '/100', pts: scanPts((s) => s.shape_score), dec: 0 },
    kcal: { label: 'Calories (7-day avg)', color: '#F58220', unit: 'kcal', pts: roll('kcal', 7), dec: 0 },
    protein: { label: 'Protein (7-day avg)', color: '#14B8A6', unit: 'g', pts: roll('protein', 7), dec: 0 },
  };
}
const inSpan = (t) => { const sp = S3.dashSpan(); const ms = new Date(t).getTime(); return (sp.t0 == null || ms >= sp.t0) && (sp.t1 == null || ms <= sp.t1); };

// ---- Trends: any metrics, hover to read ----
function trendsHtml(cat) {
  const keys = Object.keys(cat).filter((k) => cat[k].pts.length); const pick = X.pick.filter((k) => cat[k] && cat[k].pts.length);
  const chips = keys.map((k) => chip(pick.indexOf(k) >= 0, `data-pick="${k}"`, esc(cat[k].label), cat[k].color)).join('');
  const ser = pick.map((k) => ({ k, c: cat[k], pts: cat[k].pts.filter((p) => inSpan(p.t)) })).filter((s) => s.pts.length);
  const sp = S3.dashSpan(); const all = [].concat.apply([], ser.map((s) => s.pts.map((p) => new Date(p.t).getTime())));
  if (!ser.length) return `<div class="chips">${chips}</div><div class="empty"><div class="big">Pick something to plot</div>Choose one or more metrics above (and widen the date range if they are empty).</div>`;
  const t0 = sp.t0 != null ? sp.t0 : Math.min.apply(null, all), t1 = sp.t1 != null ? sp.t1 : Math.max.apply(null, all); const span = Math.max(t1 - t0, DAY);
  const W = 860, H = 320, L = 54, Rr = 22, T = 16, B = 36; const single = ser.length === 1;
  const sc = ser.map((s) => { const v = s.pts.map((p) => p.v); let mn = Math.min.apply(null, v), mx = Math.max.apply(null, v); if (mx - mn < 1e-9) { mn -= 1; mx += 1; } const pd = (mx - mn) * 0.12; return { mn: mn - pd, mx: mx + pd }; });
  const Xp = (t) => L + ((new Date(t).getTime() - t0) / span) * (W - L - Rr); const Yp = (i, v) => T + (1 - (v - sc[i].mn) / (sc[i].mx - sc[i].mn)) * (H - T - B);
  let g = ''; for (let i = 0; i <= 4; i++) { const y = T + (H - T - B) * i / 4; g += `<line x1="${L}" x2="${W - Rr}" y1="${y}" y2="${y}" stroke="#F3E8DB"/>`; if (single) g += `<text x="${L - 10}" y="${y + 4}" text-anchor="end">${(sc[0].mx - (sc[0].mx - sc[0].mn) * i / 4).toFixed(ser[0].c.dec)}</text>`; }
  const f = (ms) => new Date(ms).toLocaleDateString(undefined, span / DAY > 330 ? { month: 'short', year: '2-digit' } : { month: 'short', day: 'numeric' });
  for (let i = 0; i <= 4; i++) g += `<text x="${L + (W - L - Rr) * i / 4}" y="${H - 12}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${f(t0 + span * i / 4)}</text>`;
  let body = ''; ser.forEach((s, i) => {
    const path = s.pts.map((p, j) => (j ? 'L' : 'M') + Xp(p.t).toFixed(1) + ',' + Yp(i, p.v).toFixed(1)).join(' '); const few = s.pts.length <= 40;
    if (s.pts.length > 1) body += `<path d="${path}" fill="none" stroke="${s.c.color}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"/>`;
    if (few) body += s.pts.map((p) => `<circle cx="${Xp(p.t).toFixed(1)}" cy="${Yp(i, p.v).toFixed(1)}" r="${s.pts.length <= 12 ? 5.5 : 3.5}" fill="#fff" stroke="${s.c.color}" stroke-width="2.5"/>`).join('');
  });
  const note = single ? '' : '<p class="small muted" style="margin:4px 0 0">Each line is scaled to its own range so different metrics can be compared by shape. Hover or touch the chart to read the real values.</p>';
  return `<div class="chips">${chips}</div><div class="xwrap" id="xwrap" data-t0="${t0}" data-span="${span}" data-l="${L}" data-w="${W}" data-r="${Rr}"><svg class="chart" viewBox="0 0 ${W} ${H}">${g}${body}<line id="xcur" x1="0" x2="0" y1="${T}" y2="${H - B}" stroke="#1D2026" stroke-opacity=".35" style="display:none"/></svg><div class="xtip" id="xtip" style="display:none"></div></div>${note}`;
}
function hoverTrends(cat) {
  const w = $('#xwrap'); if (!w) return; const t0 = +w.dataset.t0, span = +w.dataset.span, L = +w.dataset.l, W = +w.dataset.w, Rr = +w.dataset.r; const svg = w.querySelector('svg'), cur = $('#xcur'), tip = $('#xtip');
  const ser = X.pick.filter((k) => cat[k] && cat[k].pts.length).map((k) => ({ c: cat[k], pts: cat[k].pts.filter((p) => inSpan(p.t)) })).filter((s) => s.pts.length);
  const move = (ev) => {
    const r = svg.getBoundingClientRect(); const px = (ev.clientX - r.left) / r.width * W; const t = t0 + ((px - L) / (W - L - Rr)) * span; if (px < L || px > W - Rr) { cur.style.display = 'none'; tip.style.display = 'none'; return; }
    cur.setAttribute('x1', px); cur.setAttribute('x2', px); cur.style.display = '';
    const rows = ser.map((s) => { let b = null, bd = 1e18; s.pts.forEach((p) => { const d = Math.abs(new Date(p.t).getTime() - t); if (d < bd) { bd = d; b = p; } }); return b && bd < span * 0.08 + 3 * DAY ? `<div><i style="background:${s.c.color}"></i>${esc(s.c.label)}: <b>${b.v.toFixed(s.c.dec)}</b> ${esc(s.c.unit)} <span class="muted">${new Date(b.t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span></div>` : ''; }).join('');
    tip.innerHTML = `<div class="small muted">${new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</div>` + (rows || '<div class="muted">No readings near here</div>'); tip.style.display = '';
    const lx = (ev.clientX - r.left); tip.style.left = (lx > r.width * 0.6 ? lx - tip.offsetWidth - 12 : lx + 12) + 'px'; tip.style.top = '8px';
  };
  svg.addEventListener('pointermove', move); svg.addEventListener('pointerdown', move); svg.addEventListener('pointerleave', () => { cur.style.display = 'none'; tip.style.display = 'none'; });
}

// ---- helpers for the day-based views ----
const CM = { kcal: ['Calories', 'kcal'], protein: ['Protein', 'g'], carbs: ['Carbs', 'g'], fat: ['Fat', 'g'] };
const daysInSpan = () => { const sp = S3.dashSpan(); return Object.keys(D.days).filter((d) => D.days[d].kcal >= 800 && (sp.t0 == null || msOf(d) >= sp.t0 - DAY / 2) && (sp.t1 == null || msOf(d) <= sp.t1)); };
const metricChips = () => Object.keys(CM).map((k) => chip(X.cm === k, `data-cm="${k}"`, CM[k][0])).join('');
const wdChips = () => `<span class="muted small" style="align-self:center">Days:</span>` + WD.map((w, i) => chip(X.wd[i], `data-wd="${i}"`, w)).join('');

// ---- Calendar heat map ----
function calendarHtml() {
  const sp = S3.dashSpan(); const keys = Object.keys(D.days).sort(); if (!keys.length) return '<div class="empty"><div class="big">No food data yet</div>Connect MyFitnessPal or MyNetDiary in Profile.</div>';
  let end = sp.t1 != null ? Math.min(sp.t1, Date.now()) : Date.now(), start = sp.t0 != null ? sp.t0 : msOf(keys[0]); if (end - start > 182 * DAY) start = end - 182 * DAY;
  const first = new Date(start); first.setDate(first.getDate() - ((first.getDay() + 6) % 7)); const vals = []; const cells = [];
  for (let ms = first.getTime(); ms <= end; ms += DAY) { const iso = isoOf(ms + 3600000); const d = D.days[iso]; const ok = d && d.kcal >= 800 && ms >= start - DAY; cells.push({ iso, v: ok ? d[X.cm] : null, wd: wdIdx(iso) }); if (ok && X.wd[wdIdx(iso)]) vals.push(d[X.cm]); }
  const mx = Math.max.apply(null, vals.concat([1])), mn = Math.min.apply(null, vals.concat([mx]));
  const col = (v) => { const a = mx === mn ? 0.6 : 0.2 + 0.8 * (v - mn) / (mx - mn); return `rgba(245,130,32,${a.toFixed(2)})`; };
  const weeks = []; cells.forEach((c, i) => { if (c.wd === 0) weeks.push([]); if (!weeks.length) weeks.push([]); weeks[weeks.length - 1].push(c); });
  const grid = weeks.map((w) => `<div class="calcol">${[0, 1, 2, 3, 4, 5, 6].map((i) => { const c = w.find((x) => x.wd === i); if (!c) return '<b class="calcell blank"></b>'; const on = c.v != null && X.wd[i]; return `<b class="calcell ${c.v == null ? 'empty' : ''}" data-day="${c.iso}" style="${on ? 'background:' + col(c.v) : (c.v != null ? 'background:#f1e6d9' : '')}" title="${c.iso}${c.v != null ? ': ' + Math.round(c.v) + ' ' + CM[X.cm][1] : ''}"></b>`; }).join('')}</div>`).join('');
  const avg = vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
  return `<div class="chips">${metricChips()}</div><div class="chips">${wdChips()}</div><div class="calwrap"><div class="calaxis">${WD.map((w) => `<span>${w[0]}</span>`).join('')}</div><div class="calgrid">${grid}</div></div><p class="small muted" style="margin:6px 0">Darker means more. ${avg != null ? `Average on the selected days: <b>${avg.toLocaleString()} ${CM[X.cm][1]}</b> (${vals.length} days).` : ''} Tap a day to see what you ate.</p><div id="dayinfo"></div>`;
}
async function showDay(iso) {
  await ensureFoods(); const el = $('#dayinfo'); if (!el) return; const d = D.days[iso] || {}; const fl = D.foods[iso] || [];
  const byMeal = {}; fl.forEach((f) => { (byMeal[f.meal || 'Other'] = byMeal[f.meal || 'Other'] || []).push(f); });
  el.innerHTML = `<div class="card flat"><h3 style="margin:0 0 4px">${new Date(iso + 'T12:00:00').toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</h3><div class="small muted" style="margin-bottom:6px">${Math.round(d.kcal || 0).toLocaleString()} kcal · P ${Math.round(d.protein || 0)} g · C ${Math.round(d.carbs || 0)} g · F ${Math.round(d.fat || 0)} g</div>${fl.length ? Object.keys(byMeal).map((m) => `<div class="small"><b>${esc(m)}</b></div><table class="t"><tbody>${byMeal[m].map((f) => `<tr><td>${esc(f.name)}</td><td class="r">${Math.round(f.kcal)} kcal</td><td class="r">${Math.round(f.protein || 0)} g protein</td></tr>`).join('')}</tbody></table>`).join('') : '<p class="muted small" style="margin:0">No individual foods were saved for this day.</p>'}</div>`;
}

// ---- Weekday pattern ----
function weekdaysHtml() {
  const keys = daysInSpan(); if (!keys.length) return '<div class="empty"><div class="big">No food data in this range</div></div>';
  const sums = [0, 0, 0, 0, 0, 0, 0], n = [0, 0, 0, 0, 0, 0, 0]; keys.forEach((d) => { const i = wdIdx(d); sums[i] += D.days[d][X.cm] || 0; n[i]++; });
  const avg = sums.map((s, i) => (n[i] ? s / n[i] : null)); const mx = Math.max.apply(null, avg.filter((v) => v != null)); const all = keys.reduce((a, d) => a + (D.days[d][X.cm] || 0), 0) / keys.length;
  const bars = avg.map((v, i) => `<div class="wdbar" data-wd-pick="${i}"><div class="wdval small">${v == null ? '—' : Math.round(v).toLocaleString()}</div><div class="wdcol"><b style="height:${v == null ? 0 : Math.max(3, v / mx * 100)}%;background:${v != null && v > all * 1.1 ? '#E5484D' : v != null && v < all * 0.9 ? '#10B981' : '#F58220'}"></b></div><div class="small muted">${WD[i]}</div><div class="small muted">${n[i]}d</div></div>`).join('');
  const hi = avg.reduce((b, v, i) => (v != null && (b < 0 || v > avg[b]) ? i : b), -1), lo = avg.reduce((b, v, i) => (v != null && (b < 0 || v < avg[b]) ? i : b), -1);
  const wkend = [5, 6].map((i) => avg[i]).filter((v) => v != null), wkday = [0, 1, 2, 3, 4].map((i) => avg[i]).filter((v) => v != null); const m = (a) => a.reduce((x, y) => x + y, 0) / a.length;
  const cmp = wkend.length && wkday.length ? ` Weekends average <b>${Math.round(m(wkend)).toLocaleString()}</b> vs weekdays <b>${Math.round(m(wkday)).toLocaleString()}</b> ${CM[X.cm][1]} (${m(wkend) >= m(wkday) ? '+' : ''}${Math.round(m(wkend) - m(wkday))}).` : '';
  return `<div class="chips">${metricChips()}</div><div class="wdbars">${bars}</div><p class="small muted" style="margin:6px 0 0">Average ${CM[X.cm][0].toLowerCase()} per weekday over ${keys.length} logged days. Red is more than 10% above your average, green more than 10% below. Highest: <b>${WD[hi]}</b>, lowest: <b>${WD[lo]}</b>.${cmp}</p>`;
}

// ---- Food finder ----
function foodsHtml() {
  const foods = D.foods || {}; const sp = S3.dashSpan(); const q = (X.q || '').trim().toLowerCase(); const agg = {}; let ndays = 0;
  Object.keys(foods).forEach((d) => { const ms = msOf(d); if ((sp.t0 != null && ms < sp.t0 - DAY / 2) || (sp.t1 != null && ms > sp.t1) || !X.wd[wdIdx(d)]) return; ndays++; (foods[d] || []).forEach((f) => { const meal = f.meal || 'Other'; if (X.meal[meal]) return; const nm = String(f.name).split(',')[0].trim(); if (q && nm.toLowerCase().indexOf(q) < 0) return; const a = agg[nm] = agg[nm] || { name: nm, n: 0, kcal: 0, protein: 0 }; a.n++; a.kcal += f.kcal || 0; a.protein += f.protein || 0; }); });
  const rows = Object.keys(agg).map((k) => agg[k]); rows.forEach((r) => { r.dens = r.kcal > 0 ? r.protein / r.kcal * 100 : 0; });
  const key = { kcal: 'kcal', protein: 'protein', n: 'n', dens: 'dens' }[X.sort] || 'kcal'; rows.sort((a, b) => b[key] - a[key]);
  const meals = ['Breakfast', 'Lunch', 'Dinner', 'Snacks'].map((m) => chip(!X.meal[m], `data-meal="${m}"`, m)).join('');
  const sorts = [['kcal', 'Calories'], ['protein', 'Protein'], ['n', 'Most often'], ['dens', 'Protein per kcal']].map((s) => chip(X.sort === s[0], `data-sort="${s[0]}"`, s[1])).join('');
  const tot = rows.reduce((a, r) => ({ kcal: a.kcal + r.kcal, protein: a.protein + r.protein }), { kcal: 0, protein: 0 });
  return `<div class="row" style="gap:10px;margin-bottom:8px"><input type="search" id="foodq" placeholder="Search foods (for example: chicken)" value="${esc(X.q || '')}" style="flex:1;min-width:200px"></div><div class="chips">${meals}</div><div class="chips">${wdChips()}</div><div class="chips"><span class="muted small" style="align-self:center">Sort:</span>${sorts}</div>
    ${rows.length ? `<div style="max-height:360px;overflow:auto"><table class="t"><thead><tr><th>Food</th><th class="r">Times</th><th class="r">Calories</th><th class="r">Protein</th><th class="r">Protein / 100 kcal</th></tr></thead><tbody>${rows.slice(0, 40).map((r) => `<tr><td>${esc(r.name)}</td><td class="r">${r.n}×</td><td class="r">${Math.round(r.kcal).toLocaleString()}</td><td class="r">${Math.round(r.protein)} g</td><td class="r">${r.dens.toFixed(1)} g</td></tr>`).join('')}</tbody></table></div><p class="small muted" style="margin:6px 0 0">${rows.length} foods across ${ndays} days · ${Math.round(tot.kcal).toLocaleString()} kcal · ${Math.round(tot.protein)} g protein in total.</p>` : '<div class="empty"><div class="big">No matching foods</div>Try another search, meal or date range.</div>'}`;
}

// ---- Does eating track weight? weekly scatter ----
function relHtml() {
  const sp = S3.dashSpan(); const W = []; ((D.pg && D.pg.weights) || []).forEach((p) => W.push({ ms: new Date(p.t).getTime(), v: wt(p.v) })); ((D.pg && D.pg.scanWeights) || []).forEach((p) => W.push({ ms: new Date(p.t).getTime(), v: wt(p.v) }));
  const t0 = sp.t0 != null ? sp.t0 : Date.now() - 182 * DAY, t1 = sp.t1 != null ? sp.t1 : Date.now(); const wk = []; for (let s = t0; s + 7 * DAY <= t1 + DAY; s += 7 * DAY) {
    const kd = Object.keys(D.days).filter((d) => D.days[d].kcal >= 800 && msOf(d) >= s && msOf(d) < s + 7 * DAY); const ws = W.filter((p) => p.ms >= s && p.ms < s + 7 * DAY);
    if (kd.length >= 4 && ws.length) wk.push({ s, kcal: kd.reduce((a, d) => a + D.days[d].kcal, 0) / kd.length, w: ws.reduce((a, p) => a + p.v, 0) / ws.length });
  }
  const pts = []; for (let i = 1; i < wk.length; i++) if (wk[i].s - wk[i - 1].s <= 8 * DAY) pts.push({ x: wk[i - 1].kcal, y: wk[i].w - wk[i - 1].w, s: wk[i].s });
  if (pts.length < 4) return '<div class="empty"><div class="big">Not enough weeks yet</div>This view needs at least 5 weeks with both food logs and weigh-ins. Widen the date range, or keep syncing.</div>';
  const n = pts.length, mx = pts.reduce((a, p) => a + p.x, 0) / n, my = pts.reduce((a, p) => a + p.y, 0) / n; let sxy = 0, sxx = 0, syy = 0; pts.forEach((p) => { sxy += (p.x - mx) * (p.y - my); sxx += (p.x - mx) * (p.x - mx); syy += (p.y - my) * (p.y - my); });
  const slope = sxx ? sxy / sxx : 0, r = sxx && syy ? sxy / Math.sqrt(sxx * syy) : 0; const W2 = 860, H = 300, L = 54, R2 = 22, T = 16, B = 34;
  const xs = pts.map((p) => p.x), ys = pts.map((p) => p.y); let ax = Math.min.apply(null, xs), bx = Math.max.apply(null, xs), ay = Math.min.apply(null, ys.concat([0])), by = Math.max.apply(null, ys.concat([0])); const pxd = (bx - ax) * 0.08 || 50, pyd = (by - ay) * 0.12 || 1; ax -= pxd; bx += pxd; ay -= pyd; by += pyd;
  const Xp = (v) => L + (v - ax) / (bx - ax) * (W2 - L - R2), Yp = (v) => T + (1 - (v - ay) / (by - ay)) * (H - T - B); let g = '';
  for (let i = 0; i <= 4; i++) { const v = ay + (by - ay) * i / 4, y = Yp(v); g += `<line x1="${L}" x2="${W2 - R2}" y1="${y}" y2="${y}" stroke="#F3E8DB"/><text x="${L - 10}" y="${y + 4}" text-anchor="end">${v.toFixed(1)}</text>`; const xv = ax + (bx - ax) * i / 4; g += `<text x="${Xp(xv)}" y="${H - 10}" text-anchor="middle">${Math.round(xv / 10) * 10}</text>`; }
  g += `<line x1="${L}" x2="${W2 - R2}" y1="${Yp(0)}" y2="${Yp(0)}" stroke="#C9B8A6" stroke-dasharray="4 4"/>`;
  const dots = pts.map((p) => `<circle cx="${Xp(p.x).toFixed(1)}" cy="${Yp(p.y).toFixed(1)}" r="6" fill="#F58220" fill-opacity=".75"><title>Week of ${new Date(p.s).toLocaleDateString()}: ${Math.round(p.x)} kcal/day, ${p.y >= 0 ? '+' : ''}${p.y.toFixed(1)} ${S3.unitsWt()} next week</title></circle>`).join('');
  const line = `<line x1="${Xp(ax)}" y1="${Yp(my + slope * (ax - mx))}" x2="${Xp(bx)}" y2="${Yp(my + slope * (bx - mx))}" stroke="#1D2026" stroke-opacity=".6" stroke-width="2.5" stroke-dasharray="7 5"/>`;
  const per100 = slope * 100; const strength = Math.abs(r) > 0.6 ? 'a strong' : Math.abs(r) > 0.3 ? 'a moderate' : 'only a weak';
  return `<svg class="chart" viewBox="0 0 ${W2} ${H}">${g}${line}${dots}</svg><p class="small muted" style="margin:6px 0 0">Each dot is one week: your average calories (across) against how your average weight changed by the following week (up is gain). The dashed line is the trend over ${n} weeks: about <b>${per100 >= 0 ? '+' : ''}${per100.toFixed(2)} ${S3.unitsWt()}</b> per week for every extra 100 kcal a day, ${strength} link (r = ${r.toFixed(2)}). Weekly weight swings are noisy, so treat this as a hint, not a rule.</p>`;
}

// ---- the card ----
const TABS = [['trends', 'Trends'], ['calendar', 'Calendar'], ['weekdays', 'Weekdays'], ['foods', 'Foods'], ['rel', 'Eating vs weight']];
S3.exploreCard = async () => {
  const host = $('#explore'); if (!host) return; if (!D) { host.innerHTML = '<div class="card" style="margin-bottom:16px"><h3 style="margin:0">Explore</h3><p class="muted small">Loading…</p></div>'; await loadData(); } else { loadData().then(() => { if ($('#explore') && S3._exDraw) S3._exDraw(); }); }
  if (!$('#explore')) return;
  const draw = async () => {
    const h = $('#explore'); if (!h) return; if (X.tab === 'foods' || X.tab === 'calendar') await ensureFoods();
    const cat = catalogue(); const body = X.tab === 'trends' ? trendsHtml(cat) : X.tab === 'calendar' ? calendarHtml() : X.tab === 'weekdays' ? weekdaysHtml() : X.tab === 'foods' ? foodsHtml() : relHtml();
    h.innerHTML = `<div class="card chart-card" style="margin-bottom:16px"><div class="row" style="margin-bottom:8px;flex-wrap:wrap;gap:10px"><h3 class="grow" style="margin:0">Explore your data</h3><div class="seg" id="extabs">${TABS.map((t) => `<button type="button" data-tab="${t[0]}" class="${X.tab === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div></div>${body}</div>`;
    const re = () => { saveX(); draw(); };
    h.querySelectorAll('[data-tab]').forEach((b) => { b.onclick = () => { X.tab = b.dataset.tab; re(); }; });
    h.querySelectorAll('[data-pick]').forEach((b) => { b.onclick = () => { const k = b.dataset.pick, i = X.pick.indexOf(k); if (i >= 0) X.pick.splice(i, 1); else X.pick.push(k); re(); }; });
    h.querySelectorAll('[data-cm]').forEach((b) => { b.onclick = () => { X.cm = b.dataset.cm; re(); }; });
    h.querySelectorAll('[data-wd]').forEach((b) => { b.onclick = () => { X.wd[+b.dataset.wd] = X.wd[+b.dataset.wd] ? 0 : 1; if (!X.wd.some((v) => v)) X.wd = [1, 1, 1, 1, 1, 1, 1]; re(); }; });
    h.querySelectorAll('[data-wd-pick]').forEach((b) => { b.onclick = () => { const i = +b.dataset.wdPick; X.wd = [0, 0, 0, 0, 0, 0, 0]; X.wd[i] = 1; X.tab = 'calendar'; re(); }; });
    h.querySelectorAll('[data-meal]').forEach((b) => { b.onclick = () => { X.meal[b.dataset.meal] = !X.meal[b.dataset.meal]; re(); }; });
    h.querySelectorAll('[data-sort]').forEach((b) => { b.onclick = () => { X.sort = b.dataset.sort; re(); }; });
    h.querySelectorAll('[data-day]').forEach((b) => { b.onclick = () => showDay(b.dataset.day); });
    const q = $('#foodq'); if (q) q.oninput = () => { X.q = q.value; saveX(); const pos = q.selectionStart; draw().then(() => { const n = $('#foodq'); if (n) { n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) { /* ignore */ } } }); };
    if (X.tab === 'trends') hoverTrends(cat);
  };
  S3._exDraw = draw; draw();
};
})();
