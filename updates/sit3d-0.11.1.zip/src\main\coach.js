'use strict';
// AI coach for S*it3D (Google Gemini, "bring your own free key").
// Privacy by design: only an ANONYMOUS summary is ever sent (no name, email, username, birthday or ids), and only after the user has turned the
// coach on and acknowledged what is sent. The API key is stored per user, encrypted with Windows DPAPI (readable only by this Windows account).
// Node 12 compatible.
const fs = require('fs'), path = require('path'), https = require('https'), cp = require('child_process');

const TEXT_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite'];   // free-tier models get busy, so try several in turn
const TEXT_MODEL = TEXT_MODELS[0];
const LIVE_MODEL = 'gemini-3.8-live';
const VOICES = ['Kore', 'Aoede', 'Puck', 'Charon', 'Leda', 'Zephyr'];

// ---------- key storage (DPAPI) ----------
function ps(script, input) { return cp.execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { input, encoding: 'utf8', windowsHide: true, timeout: 20000 }).trim(); }
function protect(text) { try { return 'dpapi:' + ps("Add-Type -AssemblyName System.Security; $t = [Console]::In.ReadToEnd(); [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($t), $null, 'CurrentUser'))", text); } catch (e) { throw new Error('Could not protect the key on this PC.'); } }
function unprotect(blob) { if (!blob || blob.indexOf('dpapi:') !== 0) throw new Error('No key saved.'); return ps("Add-Type -AssemblyName System.Security; $b = [Console]::In.ReadToEnd().Trim(); [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($b), $null, 'CurrentUser'))", blob.slice(6)); }

const cfgFile = (dataDir, userId) => path.join(dataDir, 'ai', userId + '.json');
function loadCfg(dataDir, userId) { try { return JSON.parse(fs.readFileSync(cfgFile(dataDir, userId), 'utf8')); } catch (e) { return {}; } }
function saveCfg(dataDir, userId, cfg) { fs.mkdirSync(path.join(dataDir, 'ai'), { recursive: true }); fs.writeFileSync(cfgFile(dataDir, userId), JSON.stringify(cfg)); }
function setKey(dataDir, userId, key, consent) {
  key = String(key || '').trim(); if (key.length < 20 || /\s/.test(key)) throw new Error('That does not look like a Google AI key.');
  if (!consent) throw new Error('Please tick the box to confirm you understand what is sent.');
  const cfg = loadCfg(dataDir, userId); cfg.enc = protect(key); cfg.consent = new Date().toISOString(); cfg.voice = cfg.voice || 'Kore'; saveCfg(dataDir, userId, cfg); return status(dataDir, userId);
}
function getKey(dataDir, userId) { const cfg = loadCfg(dataDir, userId); if (!cfg.enc || !cfg.consent) throw new Error('The AI coach is not set up yet. Add your Google AI key in Profile.'); return unprotect(cfg.enc); }
function clear(dataDir, userId) { try { fs.unlinkSync(cfgFile(dataDir, userId)); } catch (e) { /* none */ } }
function status(dataDir, userId) { const c = loadCfg(dataDir, userId); return { enabled: !!(c.enc && c.consent), voice: c.voice || 'Kore', voices: VOICES, since: c.consent || null, model: TEXT_MODEL, liveModel: LIVE_MODEL }; }
function setVoice(dataDir, userId, v) { const c = loadCfg(dataDir, userId); if (VOICES.indexOf(v) < 0) throw new Error('Unknown voice.'); c.voice = v; saveCfg(dataDir, userId, c); return status(dataDir, userId); }

// ---------- the anonymous packet ----------
const r1 = (v) => (v == null ? null : Math.round(v * 10) / 10);
function weekly(days, today, weeks) {
  const out = []; const NP = require('../pipeline/nutrition_progress.js');
  for (let w = weeks - 1; w >= 0; w--) {
    const end = NP.addDays(today, -7 * w), start = NP.addDays(end, -6); const g = NP.goodDays(days, start, NP.addDays(end, 1)); if (!g.length) continue;
    const avg = (k) => Math.round(g.reduce((a, x) => a + (x[k] || 0), 0) / g.length);
    out.push({ week_ending: end, days_logged: g.length, kcal: avg('kcal'), protein_g: avg('protein'), carbs_g: avg('carbs'), fat_g: avg('fat') });
  }
  return out;
}
// user: {sex, age, height_cm, goal, units}; scans: summaries (oldest first); progress: result of nutrition:progress; days: nutrition days
// Everything the AI sees is in the user's own units (lb/in or kg/cm), and it gets the facts it needs to judge how much to trust a change.
function buildPacket(user, scans, progress, days, today) {
  const NP = require('../pipeline/nutrition_progress.js');
  const imp = user.units === 'imperial'; const wf = imp ? 2.2046226 : 1, lf = imp ? 1 / 2.54 : 1; const wu = imp ? 'lb' : 'kg', lu = imp ? 'in' : 'cm';
  const W = (v) => (v == null ? null : r1(v * wf)), Lg = (v) => (v == null ? null : r1(v * lf));
  const ageBand = user.age == null ? null : Math.floor(user.age / 5) * 5 + '-' + (Math.floor(user.age / 5) * 5 + 4);
  const goal = String(user.goal || '').replace(/[^\w\s.,%+\-/'()]/g, '').slice(0, 140);
  const day = (x) => String(x.created).slice(0, 10); const dayN = (a, b) => Math.round((new Date(b + 'T12:00:00') - new Date(a + 'T12:00:00')) / 86400000);
  const last8 = scans.slice(-8);
  const scanRows = last8.map((x, k) => ({ date: day(x), days_since_previous_scan: k ? dayN(day(last8[k - 1]), day(x)) : null, ['weight_' + wu]: W(x.weight_kg), body_fat_pct: x.body_fat_pct, ['lean_mass_' + wu]: W(x.lean_mass_kg), ['waist_' + lu]: Lg(x.waist_cm), ['hips_' + lu]: Lg(x.hips_cm), ['chest_' + lu]: Lg(x.chest_cm), shape_score: x.shape_score, posture_score: x.posture_score, bmi: x.bmi, visceral_index: x.visceral }));
  const gaps = scanRows.map((x) => x.days_since_previous_scan).filter((x) => x != null);
  const scanInfo = { count: scans.length, first_scan_date: scans.length ? day(scans[0]) : null, latest_scan_date: scans.length ? day(scans[scans.length - 1]) : null, days_since_latest_scan: scans.length ? dayN(day(scans[scans.length - 1]), today) : null,
    shortest_gap_days: gaps.length ? Math.min.apply(null, gaps) : null, latest_gap_days: gaps.length ? gaps[gaps.length - 1] : null,
    reading_the_changes: 'See comparisons: each change was compared with a method chosen for how many scans exist and how far apart they are, and carries its own verdict.' };

  // how each key measurement changed, compared the way the amount of data allows (see pipeline/compare.js)
  const CMP = require('../pipeline/compare.js'); const cmpOut = {};
  [['weight', 'weight_kg', wf, wu], ['body_fat', 'body_fat_pct', 1, '%'], ['lean_mass', 'lean_mass_kg', wf, wu], ['waist', 'waist_cm', lf, lu]].forEach(([name, key, fac, un]) => {
    const c = CMP.compare(scans.map((x) => ({ t: x.created, v: x[key] })), CMP.NOISE[key]); if (!c.ok) { cmpOut[name] = { result: 'not enough scans to compare yet' }; return; }
    const rr = (v) => (v == null ? null : Math.round(v * fac * 100) / 100); const tr = CMP.trend(scans.map((x) => ({ t: x.created, v: x[key] })), 14);
    cmpOut[name] = { unit: un, how_compared: c.note, scans_in_latest_group: c.nCur, scans_in_earlier_group: c.nPrev, latest_value: rr(c.cur), earlier_value: rr(c.prev), change: rr(c.delta), normal_scan_noise_for_this_comparison: rr(c.noise), verdict: CMP.verdictText[c.verdict], trend_per_week_over_last_14_days: tr ? rr(tr.perWeek) : null };
  });
  let nutrition = null;
  if (progress && progress.hasData) {
    const wnd = (w) => { if (!w) return w; const o = Object.assign({}, w); delete o.proteinPerKg; o['protein_per_' + wu] = w.proteinPerKg == null ? null : Math.round(w.proteinPerKg / wf * 100) / 100; return o; };
    const btw = (progress.between || []).slice(-4).map((b) => { const o = Object.assign({}, b); delete o.dWeight; delete o.dLean; delete o.dWaist; o['weight_change_' + wu] = W(b.dWeight); o['lean_change_' + wu] = W(b.dLean); o['waist_change_' + lu] = Lg(b.dWaist); return o; });
    // logged scale weights over the last 4 weeks -> weekly trend
    const ws = (progress.weights || []).filter((p) => String(p.t).slice(0, 10) >= NP.addDays(today, -27));
    let slope = null; if (ws.length >= 6) { const xs = ws.map((p) => -dayN(String(p.t).slice(0, 10), today)), ys = ws.map((p) => p.v), n = xs.length, mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n; let nu = 0, de = 0; for (let k = 0; k < n; k++) { nu += (xs[k] - mx) * (ys[k] - my); de += (xs[k] - mx) * (xs[k] - mx); } slope = de ? nu / de * 7 : null; }
    const g28 = NP.goodDays(days || {}, NP.addDays(today, -27), NP.addDays(today, 1)); const avgK = g28.length ? g28.reduce((a, x) => a + x.kcal, 0) / g28.length : null;
    const wk = [], we = []; for (let k = 0; k < 28; k++) { const d = NP.addDays(today, -k), x = (days || {})[d]; if (!x || x.kcal < 800) continue; const dw = new Date(d + 'T12:00:00').getDay(); (dw === 0 || dw === 6 ? we : wk).push(x.kcal); }
    const mean = (a) => (a.length ? Math.round(a.reduce((p, q) => p + q, 0) / a.length) : null);
    const m30 = progress.windows.w30; const macro = m30 ? (() => { const kc = m30.protein * 4 + m30.carbs * 4 + m30.fat * 9 || 1; return { protein_pct: Math.round(m30.protein * 400 / kc), carbs_pct: Math.round(m30.carbs * 400 / kc), fat_pct: Math.round(m30.fat * 900 / kc) }; })() : null;
    const trend = {}; if (slope != null) { trend['change_per_week_' + wu] = Math.round(slope * wf * 100) / 100; trend.weigh_ins_in_last_28_days = ws.length; trend.implied_energy_balance_kcal_per_day = Math.round(slope * 7700 / 7); trend.implied_maintenance_kcal = avgK == null ? null : Math.round(avgK - slope * 7700 / 7); }
    nutrition = {
      last_7_days: wnd(progress.windows.w7), last_30_days: wnd(progress.windows.w30), last_90_days: wnd(progress.windows.w90), weekly_trend: weekly(days || {}, today, 12),
      logging_days_of_last_28: g28.length, avg_kcal_weekdays: mean(wk), avg_kcal_weekends: mean(we), macro_split_30d: macro, logged_weight_trend: slope == null ? null : trend,
      between_scans: btw, most_eaten_foods_30d: progress.top.byFrequency, biggest_protein_sources_30d: progress.top.byProtein,
      food_roi_last_14_days: progress.roi ? { note: 'best = highest protein per 100 kcal (keep); worst = most calories spent for the least protein (cut or swap). lowValueKcalPerDay is the calories per day that could be saved by cutting or swapping that food.', best: progress.roi.best, worst: progress.roi.worst, potentialSavingsPerDay: progress.roi.potentialSavingsPerDay } : null,
    };
  }
  return {
    units: { weight: wu, length: lu, note: 'Use these units in every number you write. Never use ' + (imp ? 'kg or cm' : 'lb or inches') + '.' },
    profile: { sex: user.sex, age_range: ageBand, ['height_' + lu]: Lg(user.height_cm), stated_goal: goal || null },
    scan_timing: scanInfo, comparisons: cmpOut, scans: scanRows, nutrition,
    caveats: ['Body measurements come from a home 3D scanner and are estimates; clothing and posture affect them.', 'Calories under 800 on a day are treated as incomplete logging.'],
  };
}
const SYSTEM = 'You are a supportive nutrition and body-composition coach inside a home body-scanner app. You are not a doctor and must not give medical advice, diagnose, or suggest supplements or drugs. ' +
  'Use ONLY the data provided. Be concrete: name the foods from the lists, give calorie and protein ranges in numbers, and say what to track next. If the data is too thin to conclude something, say what is missing. ' +
  'If calories look dangerously low or the user seems to be eating very little, gently suggest speaking with a doctor or dietitian. Keep a warm, plain tone and avoid shaming. Always write weights, lengths and per-weight numbers in the units given in the data (lb and inches for imperial users); never convert to the other system. Do not draw conclusions from changes within normal measurement noise or from scans taken within a few days of each other.';

// ---------- Gemini text ----------
function post(url, key, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url); const data = JSON.stringify(body);
    const req = https.request({ method: 'POST', hostname: u.hostname, path: u.pathname + u.search, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key, 'Content-Length': Buffer.byteLength(data) }, timeout: 30000 }, (res) => {
      const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(ch).toString('utf8')); } catch (e) { /* not json */ } resolve({ status: res.statusCode, json: j }); });
    });
    req.on('timeout', () => req.destroy(new Error('The AI service timed out.'))); req.on('error', reject); req.end(data);
  });
}
function explain(res) {
  const msg = res.json && res.json.error && res.json.error.message ? String(res.json.error.message).slice(0, 160) : '';
  if (res.status === 429) return 'The free AI limit was reached for now. Try again in a little while.';
  if (res.status === 503) return 'The free Google AI models are busy right now. Try again in a minute.';
  if (res.status === 400 && /API key/i.test(msg)) return 'Google did not accept the key. Check it in Profile.';
  if (res.status === 401 || res.status === 403) return 'Google did not accept the key. Check it in Profile.';
  return 'The AI service had a problem (' + res.status + ').' + (msg ? ' ' + msg : '');
}
async function coachText(key, packet, question) {
  const prompt = (question ? 'The user asks: ' + question + '\n\n' : 'First, think through the data carefully (do not show this): how the changes were compared (comparisons: each says whether it is a 7-day average vs the previous 7 days, a direct comparison, or an early read, plus its verdict), what logged_weight_trend and implied_maintenance_kcal say, whether intake and protein fit the stated goal, how consistent logging is. Be honest: name the comparison method in plain words (for example \"7-day average vs the week before\"); if the verdict is \"too early to call\" or \"within normal scan noise\", say plainly that it is not a real change yet and lean on the weight trend and nutrition instead. Never call a change real unless its verdict says so. Use only the units given in the data. Then give a SHORT insights report for a busy reader who will skim it. Exactly these sections: "## Where you are" (at most 3 short bullets: the honest read on progress toward their goal and how many days separate the scans, what the logged weight trend and implied maintenance calories say, and whether calories and protein support the goal; if no goal is stated just say so in a few words, do not dwell on it), "## Best value foods" (the 3 best from food_roi_last_14_days.best, one bullet each: bold short food name, then at most 6 words), "## Foods to cut or swap" (the 3 worst from food_roi_last_14_days.worst, one bullet each: bold short food name, a dash, the kcal per day saved; then on the NEXT line, indented by two spaces and NOT starting with a dash, write Swap for: and the replacement), "## Next steps" (exactly 3 bullets, at most 10 words each). Shorten food names (drop brand prefixes and serving counts). No filler, no caveats about short time windows unless they change the advice.\n\n') + 'DATA (anonymous):\n' + JSON.stringify(packet);
  const body = {
    systemInstruction: { parts: [{ text: SYSTEM + ' Format: short markdown with "## " headings and "- " bullets, under 130 words.' }] },
    contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 1500 },
  };
  let res = null;
  for (const model of TEXT_MODELS) {
    try { res = await post('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', key, body); } catch (e) { res = { status: 0, json: null }; continue; }   // timeout: try the next model
    if (res.status === 200 && res.json) break;
    if (res.status === 401 || res.status === 403 || (res.status === 400 && res.json && res.json.error && /API key/i.test(res.json.error.message || ''))) break;   // a bad key will not get better
  }
  if (!res || res.status !== 200 || !res.json) throw new Error(res && res.status ? explain(res) : 'The AI service did not answer in time. Try again in a moment.');
  const c = res.json.candidates && res.json.candidates[0]; const text = c && c.content && c.content.parts ? c.content.parts.map((p) => p.text || '').join('').trim() : '';
  if (!text) throw new Error('The AI returned an empty answer. Try again.');
  return text;
}

// ---------- Live voice (the renderer opens the WebSocket; this prepares its configuration) ----------
function liveConfig(dataDir, userId, packet) {
  const key = getKey(dataDir, userId); const c = loadCfg(dataDir, userId);
  const system = SYSTEM + ' You are speaking out loud with the user: use short spoken sentences, no markdown, no lists read symbol by symbol. When asked to walk them through everything, cover in order: latest scan and body composition, how it changed, nutrition and food choices, then three concrete suggestions, and ask if they want to go deeper on anything. ' +
    'You may answer questions about this data only.\n\nDATA (anonymous):\n' + JSON.stringify(packet);
  return { key, model: 'models/' + LIVE_MODEL, voice: c.voice || 'Kore', system };
}

module.exports = { setKey, getKey, clear, status, setVoice, buildPacket, coachText, liveConfig, weekly, SYSTEM, TEXT_MODEL, LIVE_MODEL, protect, unprotect };
