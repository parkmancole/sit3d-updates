(function () {
'use strict';
const S3 = window.S3;
S3.state = { user: null, info: null, scans: [], metric: 'body_fat_pct', picked: [] };

S3.go = async (route, arg) => {
  try {
    if (!S3.state.user) return S3.viewAuth('login');
    window.scrollTo(0, 0);
    if (route === 'dash') await S3.viewDash();
    else if (route === 'scan') await S3.viewScan();
    else if (route === 'history') await S3.viewHistory();
    else if (route === 'profile') await S3.viewProfile();
    else if (route === 'nutrition') await S3.viewNutrition();
    else if (route === 'results') await S3.viewResults(arg);
    else await S3.viewDash();
  } catch (e) { S3.toast(e.message); console.error(e); }
};
S3.afterAuth = async () => { S3.state.info = await S3.api('app:info'); S3.go('dash'); };

S3.on('sync:progress', (p) => { const h = S3.progressHandlers || {}; if (h[p.app]) h[p.app](p); if (h.note) h.note(p); });
S3.on('sync:needlogin', (d) => {
  if (document.getElementById('relogin-' + d.app)) return;
  const o = document.createElement('div'); o.id = 'relogin-' + d.app; o.style.cssText = 'position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(30,20,10,.45);z-index:10000;display:flex;align-items:center;justify-content:center';
  o.innerHTML = '<div class="card" style="max-width:380px;text-align:center"><h3>' + d.name + ' needs you to log in again</h3><p class="muted small">Your login expired, so new food data cannot be fetched. Log in once and syncing carries on from where it stopped.</p><div class="row" style="justify-content:center"><button class="btn" id="rl-go">Log in</button><button class="btn ghost" id="rl-no">Later</button></div></div>';
  document.body.appendChild(o);
  o.querySelector('#rl-no').onclick = () => o.remove();
  o.querySelector('#rl-go').onclick = async () => { o.remove(); try { const r = await S3.api('sync:connect', d.app); S3.toast(r.connected ? d.name + ' connected. Syncing…' : 'Login window closed.'); } catch (e) { S3.toast(e.message); } };
});
S3.on('update:ready', (u) => { S3.toast('Update ' + u.version + ' downloaded. It applies the next time you open the app (see Profile to restart now).'); });
(async function boot() {
  try {
    S3.state.info = await S3.api('app:info');
    if (S3.state.info.user) { S3.state.user = S3.state.info.user; S3.go('dash'); } else S3.viewAuth('login');
  } catch (e) { document.body.innerHTML = '<pre style="padding:30px">Startup error: ' + S3.esc(e.message) + '</pre>'; }
})();

})();
