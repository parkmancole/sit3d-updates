(function () {
'use strict';
// Dashboard weight card: every weigh-in in one chart (Fit3D scans and the nutrition apps in different colors) with slicers and filters.
const S3 = window.S3, $ = (s, r) => (r || document).querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const RANGES = [['7d', 7, '1W'], ['14d', 14, '2W'], ['1m', 30, '1M'], ['3m', 90, '3M'], ['6m', 182, '6M'], ['ytd', -2, 'YTD'], ['1y', 365, '1Y'], ['2y', 730, '2Y'], ['scan', -1, 'First scan'], ['all', 0, 'All']];
const SRC = { scan: { name: 'Fit3D scan', color: '#F58220' }, mfp: { name: 'MyFitnessPal', color: '#3B82F6' }, mnd: { name: 'MyNetDiary', color: '#10B981' }, import: { name: 'Imported file', color: '#8B93A1' } };
S3.SRC = SRC;

// ---- slicer state (remembered on this PC) ----
const load = () => { try { return Object.assign({ range: '3m', off: {}, smooth: true, cal: false }, JSON.parse(localStorage.getItem('sit3d.dash') || '{}')); } catch (e) { return { range: '3m', off: {}, smooth: true, cal: false }; } };
S3.dash = S3.dash || load();
const save = () => { try { localStorage.setItem('sit3d.dash', JSON.stringify(S3.dash)); } catch (e) { /* ignore */ } };
const dayStart = (iso) => new Date(iso + 'T00:00:00').getTime(), dayEnd = (iso) => new Date(iso + 'T23:59:59').getTime();
// the active date window as { t0, t1 } in ms (null = open ended); used by every chart and table on the dashboard
S3.dashSpan = () => {
  const st = S3.dash;
  if (st.range === 'custom') return { t0: st.from ? dayStart(st.from) : null, t1: st.to ? dayEnd(st.to) : null };
  const r = RANGES.find((x) => x[0] === st.range) || RANGES[3];
  if (r[1] === -2) return { t0: new Date(new Date().getFullYear(), 0, 1).getTime(), t1: null };
  if (r[1] > 0 && st.shift > 0) { const t1 = Date.now() - st.shift * r[1] * 86400000; return { t0: t1 - r[1] * 86400000, t1 }; }   // panned back by whole windows
  if (r[1] === -1) { const sc = S3.state.scans || []; return { t0: sc.length ? new Date(sc[0].created).getTime() - 43200000 : null, t1: null }; }
  return { t0: r[1] ? Date.now() - r[1] * 86400000 : null, t1: null };
};
S3.dashRange = () => { const sp = S3.dashSpan(); if (sp.t0 == null && sp.t1 == null) return null; return (iso) => { const t = new Date(iso).getTime(); return (sp.t0 == null || t >= sp.t0) && (sp.t1 == null || t <= sp.t1); }; };
S3.dashRefresh = () => { if (S3.filterBar) S3.filterBar(); if (S3._wtDraw) S3._wtDraw(); if (S3.dashRedraw) S3.dashRedraw(); if (S3._exDraw) S3._exDraw(); };
const isoOf = (ms) => { const d = new Date(ms), z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };
// the time slicers (presets, back/forward arrows and the dates shown); the same bar is placed on every chart card and Explore page
S3.rangeBarHtml = (noPan) => {
  const st = S3.dash; const rr = RANGES.find((x) => x[0] === st.range); const pan = rr && rr[1] > 0; if (!pan) st.shift = 0;
  const sp = S3.dashSpan(); const f = (ms) => new Date(ms).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  const label = sp.t0 == null && sp.t1 == null ? 'All time' : (sp.t0 != null ? f(sp.t0) : 'Start') + ' to ' + (sp.t1 != null ? f(sp.t1) : 'today');
  return `<div class="rbar"><div class="seg">${RANGES.map((r) => `<button type="button" data-r="${r[0]}" class="${st.range === r[0] ? 'on' : ''}">${r[2]}</button>`).join('')}</div>${pan && !noPan ? `<div class="row" style="gap:4px"><button type="button" class="btn secondary" data-pan="back" aria-label="Earlier">&#8249;</button><button type="button" class="btn secondary" data-pan="fwd" aria-label="Later" ${st.shift > 0 ? '' : 'disabled'}>&#8250;</button></div>` : ''}<span class="small muted">${label}</span></div>`;
};
S3.bindRangeBar = (root) => {
  const st = S3.dash;
  root.querySelectorAll('[data-r]').forEach((b) => { b.onclick = () => { st.range = b.dataset.r; st.shift = 0; save(); S3.dashRefresh(); }; });
  root.querySelectorAll('[data-pan]').forEach((b) => { b.onclick = () => { st.shift = b.dataset.pan === 'back' ? (st.shift || 0) + 1 : Math.max(0, (st.shift || 0) - 1); save(); S3.dashRefresh(); }; });
};
// ---- the global filter bar at the top: the slicers plus exact dates ----
S3.filterBar = () => {
  const h = $('#fbar'); if (!h) return; const st = S3.dash; const sp = S3.dashSpan();
  const cf = st.range === 'custom' ? (st.from || '') : (sp.t0 != null ? isoOf(sp.t0) : ''), ct = st.range === 'custom' ? (st.to || '') : isoOf(sp.t1 != null ? sp.t1 : Date.now());
  h.innerHTML = `<div class="card flat fbar"><div class="row" style="gap:10px;flex-wrap:wrap;align-items:center">${S3.rangeBarHtml(true)}<label class="small row" style="gap:6px">From <input type="date" id="dfrom" value="${cf}"></label><label class="small row" style="gap:6px">to <input type="date" id="dto" value="${ct}"></label>${st.range === 'custom' ? '<button type="button" class="btn ghost" id="dreset">Reset</button>' : ''}</div></div>`;
  S3.bindRangeBar(h);
  const custom = () => { st.range = 'custom'; st.shift = 0; st.from = $('#dfrom').value || null; st.to = $('#dto').value || null; save(); S3.dashRefresh(); };
  $('#dfrom').onchange = custom; $('#dto').onchange = custom; if ($('#dreset')) $('#dreset').onclick = () => { st.range = '3m'; st.shift = 0; save(); S3.dashRefresh(); };
};

// ---- chart with several series on one time axis ----
// series: [{ name, color, kind: 'scan'|'app', pts: [{t, v}] }]; o: { unit, dec, from, to, avg: [{t, v}], cal: [{t, v}] }
S3.multiChart = (series, o) => {
  const W = o.w || 860, H = o.h || 320, L = 54, R = o.cal && o.cal.length ? 64 : 22, T = 18, B = 38;
  const all = []; series.forEach((s) => s.pts.forEach((p) => all.push(p))); (o.avg || []).forEach((p) => all.push(p)); (o.trend || []).forEach((p) => all.push(p));
  if (!all.length) return '<div class="empty"><div class="big">No weights in this range</div>Try a longer range or turn a source back on.</div>';
  let t0 = o.from != null ? o.from : Math.min.apply(null, all.map((p) => new Date(p.t).getTime())), t1 = o.to != null ? o.to : Math.max.apply(null, all.map((p) => new Date(p.t).getTime())); if (t1 - t0 < 86400000) { t0 -= 43200000; t1 += 43200000; }
  const ys = all.map((p) => p.v); let mn = Math.min.apply(null, ys), mx = Math.max.apply(null, ys); if (mx - mn < 1) { mn -= 1; mx += 1; } const pad = (mx - mn) * 0.15; mn -= pad; mx += pad;
  const X = (t) => L + ((new Date(t).getTime() - t0) / (t1 - t0)) * (W - L - R), Y = (v) => T + (1 - (v - mn) / (mx - mn)) * (H - T - B);
  const dec = o.dec == null ? 1 : o.dec; let g = '';
  for (let i = 0; i <= 4; i++) { const v = mn + (mx - mn) * i / 4, y = Y(v); g += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="#F3E8DB"/><text x="${L - 10}" y="${y + 4}" text-anchor="end">${v.toFixed(dec)}</text>`; }
  // date ticks: five evenly spaced labels, so they can never collide
  const spanD = (t1 - t0) / 86400000; const fmt = (ms) => new Date(ms).toLocaleDateString(undefined, spanD > 330 ? { month: 'short', year: '2-digit' } : { month: 'short', day: 'numeric' });
  for (let i = 0; i <= 4; i++) { const ms = t0 + (t1 - t0) * i / 4, x = L + (W - L - R) * i / 4; g += `<text x="${x}" y="${H - 12}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${fmt(ms)}</text>`; }
  let calSvg = '';
  if (o.cal && o.cal.length > 1) {
    const cv = o.cal.map((p) => p.v); const lo = Math.floor(Math.min.apply(null, cv) * 0.9 / 250) * 250, hi = Math.max(lo + 1000, Math.ceil(Math.max.apply(null, cv) * 1.05 / 250) * 250); const Yc = (v) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
    const line = o.cal.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Yc(p.v).toFixed(1)).join(' ');
    calSvg = `<path d="${line} L${X(o.cal[o.cal.length - 1].t).toFixed(1)},${H - B} L${X(o.cal[0].t).toFixed(1)},${H - B} Z" fill="#F5C99B" fill-opacity=".22"/><path d="${line}" fill="none" stroke="#E0A56A" stroke-width="1.8" stroke-linejoin="round"/>`;
    for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4; calSvg += `<text x="${W - R + 8}" y="${Yc(v) + 4}" text-anchor="start" fill="#C98F55">${Math.round(v).toLocaleString()}</text>`; }
    calSvg += `<text x="${W - R + 8}" y="${T - 6}" text-anchor="start" fill="#C98F55" font-weight="700">kcal / day</text>`;
  }
  const avg = o.avg && o.avg.length > 1 ? `<path d="${o.avg.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Y(p.v).toFixed(1)).join(' ')}" fill="none" stroke="#1D2026" stroke-opacity=".55" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="7 5"/>` : '';
  const trendSvg = o.trend && o.trend.length > 1 ? `<path d="${o.trend.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Y(p.v).toFixed(1)).join(' ')}" fill="none" stroke="#8B5CF6" stroke-width="2.5" stroke-dasharray="2 6" stroke-linecap="round"/>` : '';
  const conn = o.connect ? series.filter((s) => s.kind === 'scan' && s.pts.length > 1).map((s) => `<path d="${s.pts.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Y(p.v).toFixed(1)).join(' ')}" fill="none" stroke="${s.color}" stroke-width="2.5" stroke-linejoin="round" stroke-opacity=".55"/>`).join('') : '';
  let dots = '';
  series.filter((s) => s.kind === 'app').forEach((s) => { dots += s.pts.map((p) => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="3.8" fill="${s.color}" fill-opacity=".85"><title>${esc(s.name)}, ${new Date(p.t).toLocaleDateString()}: ${p.v.toFixed(dec)} ${esc(o.unit || '')}</title></circle>`).join(''); });
  series.filter((s) => s.kind === 'scan').forEach((s) => { dots += s.pts.map((p) => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="${s.pts.length > 20 ? 4.5 : 7}" fill="#fff" stroke="${s.color}" stroke-width="${s.pts.length > 20 ? 2.5 : 3.5}"><title>${esc(s.name)}, ${new Date(p.t).toLocaleString()}: ${p.v.toFixed(dec)} ${esc(o.unit || '')}</title></circle>`).join(''); });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}">${g}${calSvg}${conn}${trendSvg}${avg}${dots}</svg>`;
};

const trailingAvg = (pts, days) => pts.map((p, i) => { const t = new Date(p.t).getTime(); const w = pts.filter((q) => { const x = new Date(q.t).getTime(); return x <= t && x > t - days * 86400000; }); return { t: p.t, v: w.reduce((a, q) => a + q.v, 0) / w.length }; });

S3.metricCard = (scans) => {
  const host = $('#mchart'); if (!host) return; const M = S3.METRICS, mv = S3.metricVal, st = S3.dash; const key = S3.state.metric || 'body_fat_pct'; const m = M.find((x) => x.k === key) || M[1];
  const inR = S3.dashRange(), sp = S3.dashSpan(), now = Date.now(); const fac = m.get({ [m.k]: 1 }); const noise = (window.Compare ? (window.Compare.NOISE[m.k] || 0) : 0) * (fac == null ? 1 : fac);
  const all = scans.map((x) => ({ t: x.created, v: mv(m, x) })).filter((p) => p.v != null).sort((a, b) => (a.t < b.t ? -1 : 1)); const pts = all.filter((p) => !inR || inR(p.t));
  const avg = st.mavg && pts.length >= 3 ? trailingAvg(pts, 7) : null;
  let trend = null; if (st.mtrend && pts.length >= 3) { const xs = pts.map((p) => new Date(p.t).getTime()), ys = pts.map((p) => p.v), n = xs.length, mx = xs.reduce((a, b) => a + b, 0) / n, my = ys.reduce((a, b) => a + b, 0) / n; let a = 0, b = 0; for (let i = 0; i < n; i++) { a += (xs[i] - mx) * (ys[i] - my); b += (xs[i] - mx) * (xs[i] - mx); } if (b) { const sl = a / b; trend = [{ t: pts[0].t, v: my + sl * (xs[0] - mx) }, { t: pts[n - 1].t, v: my + sl * (xs[n - 1] - mx) }]; } }
  const chips = M.map((x) => `<button type="button" class="chip ${x.k === m.k ? 'on' : ''}" data-mk="${x.k}">${esc(x.label)}</button>`).join('') + `<button type="button" class="chip ${st.mavg ? 'on' : ''}" data-mopt="mavg"><i style="background:#1D2026;opacity:.55"></i>7-day average</button><button type="button" class="chip ${st.mtrend ? 'on' : ''}" data-mopt="mtrend"><i style="background:#8B5CF6"></i>Trend line</button>`;
  const last = pts[pts.length - 1], first = pts[0]; const chg = first && last && pts.length > 1 ? last.v - first.v : null; const c = window.Compare ? window.Compare.compare(all, noise) : { ok: false };
  const stats = last ? `<div class="wtstats"><div><div class="lbl small muted">Latest</div><b>${last.v.toFixed(m.dec)}</b> ${esc(m.unit())}<div class="small muted">${new Date(last.t).toLocaleDateString()}</div></div><div><div class="lbl small muted">Change in range</div><b>${chg == null ? '—' : (chg > 0 ? '+' : '') + chg.toFixed(m.dec)}</b> ${chg == null ? '' : esc(m.unit())}</div><div><div class="lbl small muted">Lowest / highest</div><b>${Math.min.apply(null, pts.map((p) => p.v)).toFixed(m.dec)}</b> / <b>${Math.max.apply(null, pts.map((p) => p.v)).toFixed(m.dec)}</b></div><div><div class="lbl small muted">Scans</div><b>${pts.length}</b></div>${c.ok ? `<div style="max-width:260px"><div class="lbl small muted">How it is read</div><span class="small">${esc(c.note)}</span></div>` : ''}</div>` : '';
  const chart = pts.length ? S3.multiChart([{ name: m.label, color: '#F58220', kind: 'scan', pts }], { unit: m.unit(), dec: m.dec, from: sp.t0, to: sp.t1 != null ? sp.t1 : now, avg, trend, connect: true }) : '<div class="empty"><div class="big">No scans in this range</div>Try a longer range.</div>';
  host.innerHTML = `<div class="card chart-card"><div class="row" style="margin-bottom:8px"><h3 class="grow" style="margin:0">${esc(m.label)} over time</h3></div>${S3.rangeBarHtml()}<div class="chips" style="margin-top:10px">${chips}</div>${stats}${chart}</div>`;
  S3.bindRangeBar(host);
  host.querySelectorAll('[data-mk]').forEach((b) => { b.onclick = () => { S3.state.metric = b.dataset.mk; Array.from(document.querySelectorAll('[data-m]')).forEach((t) => t.classList.toggle('sel', t.dataset.m === b.dataset.mk)); S3.metricCard(scans); }; });
  host.querySelectorAll('[data-mopt]').forEach((b) => { b.onclick = () => { st[b.dataset.mopt] = !st[b.dataset.mopt]; save(); S3.metricCard(scans); }; });
};

S3.weightCard = async () => {
  const host = $('#wtcard'); if (!host) return;
  let pg = null; try { pg = await S3.api('nutrition:progress', 400); } catch (e) { pg = null; }
  if (!$('#wtcard')) return;   // the user left the page
  const unit = S3.unitsWt(); const kv = (v) => S3.kgVal(v);
  const raw = { scan: ((pg && pg.scanWeights) || []).map((p) => ({ t: p.t, v: kv(p.v) })) }; ((pg && pg.weights) || []).forEach((p) => { const k = SRC[p.src] ? p.src : 'import'; (raw[k] = raw[k] || []).push({ t: p.t, v: kv(p.v) }); });
  const kcal = ((pg && pg.kcal7) || []).map((p) => ({ t: p.t, v: p.v }));
  const draw = () => {
    const st = S3.dash, inR = S3.dashRange(); const now = Date.now(), sp = S3.dashSpan();
    const keys = Object.keys(raw).filter((k) => raw[k].length); const counts = {}; keys.forEach((k) => { counts[k] = raw[k].filter((p) => !inR || inR(p.t)).length; });
    const series = keys.filter((k) => !st.off[k]).map((k) => ({ name: SRC[k].name, color: SRC[k].color, kind: k === 'scan' ? 'scan' : 'app', pts: raw[k].filter((p) => !inR || inR(p.t)).sort((a, b) => (a.t < b.t ? -1 : 1)) }));
    const apps = [].concat.apply([], series.filter((s) => s.kind === 'app').map((s) => s.pts)).sort((a, b) => (a.t < b.t ? -1 : 1));
    const chips = keys.map((k) => `<button type="button" class="chip ${st.off[k] ? '' : 'on'}" data-src="${k}"><i style="background:${SRC[k].color}"></i>${SRC[k].name} <span class="muted">${counts[k]}</span></button>`).join('') +
      `<button type="button" class="chip ${st.smooth ? 'on' : ''}" data-opt="smooth"><i style="background:#1D2026;opacity:.55"></i>7-day average</button><button type="button" class="chip ${st.cal ? 'on' : ''}" data-opt="cal"><i style="background:#E0A56A"></i>Calories</button>`;
    const every = [].concat.apply([], series.map((s) => s.pts)).sort((a, b) => (a.t < b.t ? -1 : 1));
    const first = every[0], last = every[every.length - 1]; const chg = first && last && every.length > 1 ? last.v - first.v : null;
    const stats = last ? `<div class="wtstats"><div><div class="lbl small muted">Latest</div><b>${last.v.toFixed(1)}</b> ${unit}<div class="small muted">${new Date(last.t).toLocaleDateString()}</div></div><div><div class="lbl small muted">Change in range</div><b style="color:${chg == null ? 'inherit' : chg > 0 ? '#E5484D' : '#10B981'}">${chg == null ? '—' : (chg > 0 ? '+' : '') + chg.toFixed(1)}</b> ${chg == null ? '' : unit}</div><div><div class="lbl small muted">Lowest / highest</div><b>${Math.min.apply(null, every.map((p) => p.v)).toFixed(1)}</b> / <b>${Math.max.apply(null, every.map((p) => p.v)).toFixed(1)}</b> ${unit}</div><div><div class="lbl small muted">Weigh-ins</div><b>${every.length}</b></div></div>` : '';
    const chart = S3.multiChart(series, { unit, dec: 1, from: sp.t0, to: sp.t1 != null ? sp.t1 : now, avg: st.smooth && apps.length > 2 ? trailingAvg(apps, 7) : null, cal: st.cal ? kcal.filter((p) => !inR || inR(p.t)) : null });
    host.innerHTML = `<div class="card chart-card" style="margin-bottom:16px"><div class="row" style="margin-bottom:8px;flex-wrap:wrap;gap:10px"><h3 class="grow" style="margin:0">Weight</h3></div>${S3.rangeBarHtml()}<div class="chips" style="margin-top:10px">${chips}</div>${stats}${chart}<p class="small muted" style="margin:6px 0 0">Orange rings are Fit3D scans. Dots are weights logged in your nutrition apps.</p></div>`;
    S3.bindRangeBar(host);
    host.querySelectorAll('[data-src]').forEach((b) => { b.onclick = () => { st.off[b.dataset.src] = !st.off[b.dataset.src]; save(); draw(); }; });
    host.querySelectorAll('[data-opt]').forEach((b) => { b.onclick = () => { st[b.dataset.opt] = !st[b.dataset.opt]; save(); draw(); }; });
  };
  S3._wtDraw = draw; draw();
};
})();
