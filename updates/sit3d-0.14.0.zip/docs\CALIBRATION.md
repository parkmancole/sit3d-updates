# Calibrating S*it3D for accuracy

The scanner measures what it sees: the surface of your body and clothes. It reads some sites too big (clothing, surface thickness) and its camera
scale is slightly off. Calibration teaches the app those errors from a tape measure and corrects **every** scan, old and new.

## How to do a session (about 3 minutes)
1. Take a normal scan (underwear or tight clothing, same as always).
2. **Straight afterwards**, measure yourself with a flexible tape, standing relaxed, in the same clothes. Measure each site **twice** and use the average.
   - **Neck**: just below the Adam's apple, level, not tight.
   - **Chest**: across the nipple line, arms relaxed, after a normal breath out.
   - **Waist**: level with the belly button, relaxed (do not suck in).
   - **Hips**: around the widest part of the buttocks, feet together.
   - **Thighs** (each): just below the crease where buttock meets thigh.
3. Profile, **Accuracy calibration**, **Open calibration lab**: pick that scan, type the numbers, **Save session**.
4. Optional: a bathroom-scale weight (compared with the platform), and a body-fat % from a DEXA scan or good calipers (the app then offsets its body-fat estimate to match).

## How many sessions?
- 1 session: a gain per site (tape / scanner). Usable, but the accuracy cannot be judged yet.
- 3+ sessions on **different days**: the lab re-tests each session against a fit made from the others ("expected on a new scan"), which is the honest error to expect.
- 5+ sessions with a real spread of sizes: gain **and** offset (a robust straight line), otherwise gain only.
A wild tape reading cannot wreck the fit (medians are used). Re-entering a session for the same scan replaces it. Removing or resetting a session re-analyses all scans.

## Height and camera scale
Every session records the scanner's measured height. The lab compares the median with your true height (Profile) and offers **Correct the camera scale**
for scans taken from then on. Old scans keep their tape-corrected circumferences.

## Your own noise
With 6+ pairs of scans on consecutive days the app measures how much *your* scans wobble day to day (robust estimate) and uses that, instead of the default,
to decide whether a change between scans is real.

## Targets
| Expected error on a new scan | Grade |
|---|---|
| up to 1 cm | Excellent |
| up to 2 cm | Good |
| up to 3.5 cm | Fair |
| more | Needs more data |
