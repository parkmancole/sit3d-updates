'use strict';
// Developer "try to break it" pass (SIT3D_BREAK=1 with SIT3D_SHOTS): hostile data, empty accounts, both unit systems, the scan tutorial flow,
// odd date ranges and a few hundred random clicks, while watching for JavaScript errors and broken text (NaN, undefined, [object ...]).
// Writes break_report.txt next to the screenshots. Never touches real user data (it runs against the throw-away test profile).
const fs = require('fs'), path = require('path');
const BAD = /NaN|undefined|\[object|Infinity/;

async function run(ctx) {
  const { wc, store, uid, base, log, shot, js, sleep, dir } = ctx; const day = 86400000; const issues = []; const note = (m) => { issues.push(m); log('ISSUE ' + m); };
  wc.on('console-message', (e, level, msg, line, src) => { if (level >= 2) note('console: ' + String(msg).slice(0, 220) + ' @' + String(src).split('/').pop() + ':' + line); });
  wc.on('render-process-gone', (e, d) => note('RENDERER CRASHED ' + JSON.stringify(d)));
  await js(`window.confirm = () => false; window.alert = () => {}; window.prompt = () => null; 0`);   // a native dialog would freeze the whole run
  await js(`window.__errs = []; window.addEventListener('error', e => window.__errs.push(String(e.message))); window.addEventListener('unhandledrejection', e => window.__errs.push('rejection: ' + String((e.reason && e.reason.message) || e.reason)));`);
  const check = async (label) => {
    const txt = await js(`document.body.innerText`); const m = BAD.exec(txt); if (m) { const i = txt.indexOf(m[0]); note(label + ': page text has "' + m[0] + '" near: ' + txt.slice(Math.max(0, i - 50), i + 50).replace(/\s+/g, ' ')); }
    (await js(`window.__errs.splice(0)`)).forEach((x) => note(label + ': ' + x));
  };
  const go = async (page, arg, wait) => { await js(`S3.go('${page}'${arg ? ", '" + arg + "'" : ''})`); await sleep(wait || 1400); await check(page + (arg ? ' ' + arg : '')); };
  const iso = (ms) => { const d = new Date(ms), z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };

  // ---- 1. hostile data in the rich account ----
  await js(`S3.api('auth:login', 'alex', '4821').then(u => { S3.state.user = u; S3.state.info = null; return S3.afterAuth(); })`); await sleep(2500); await check('after login');
  store.mergeFoods(uid, { [iso(Date.now())]: [{ meal: 'Lunch', name: '<img src=x onerror="window.__xss=1">Bad & "quoted" food', kcal: 300, protein: 10 }, { meal: '', name: '', kcal: null, protein: undefined }] });
  store.mergeDays(uid, { '2026-02-30': { kcal: 'abc' }, '2026-01-05': { kcal: null }, '2026-01-06': {}, [iso(Date.now() - 2 * day)]: { kcal: 99999, protein: -5, carbs: 0, fat: 0 } });
  store.mergeWeights(uid, { '2026-05-05': 9999, '2026-05-06': -5, '2026-05-07': 0 }, 'mfp');
  const bad = JSON.parse(JSON.stringify(base.scan)); bad.id = '20269901'; bad.created = new Date(Date.now() + 3 * day).toISOString(); bad.analysis.composition = {}; bad.analysis.circumferences_cm = {}; bad.weight_kg = null; store.saveScan(uid, bad, new Int16Array(base.view));
  const dup = JSON.parse(JSON.stringify(base.scan)); dup.id = '20269902'; store.saveScan(uid, dup, new Int16Array(base.view));
  for (const pg of ['dash', 'nutrition', 'history', 'profile', 'scan']) await go(pg);
  for (const n of [30, 90, 180, 365]) { await js(`S3.viewNutrition(${n})`); await sleep(1200); await check('nutrition ' + n); }
  { await js(`S3.go('nutrition')`); await sleep(1500); const t = await js(`document.body.innerText`); const m = /Avg calories[\s\S]{0,60}?([0-9][0-9,]*)\s*kcal/.exec(t); if (m && Number(m[1].replace(/,/g, '')) > 5000) note('absurd calories got into the averages: ' + m[1]); }
  await shot('50_hostile_dash', 200); if (await js(`window.__xss`)) note('XSS: a food name ran script');
  await go('dash', null, 2500); for (const t of ['calendar', 'weekdays', 'foods', 'rel', 'trends']) { await js(`document.querySelector('[data-tab=${t}]').click()`); await sleep(900); await check('explore ' + t); }
  // history / results / compare with the odd scans
  const scans = await js(`S3.api('scans:list')`); for (const s of [scans[0], scans[scans.length - 1], scans.find((x) => x.id === '20269901')].filter(Boolean)) { await go('results', s.id, 2000); for (const tab of ['Measurements', 'Body', 'Posture', 'Balance']) { await js(`Array.from(document.querySelectorAll('.tabs button')).filter(b => /${tab}/i.test(b.textContent)).forEach(b => b.click())`); await sleep(500); } await check('results tabs ' + s.id); }
  await js(`S3.go('history')`); await sleep(1200); await js(`Array.from(document.querySelectorAll('[data-pick]')).slice(0, 2).forEach(c => { c.checked = true; c.dispatchEvent(new Event('change', { bubbles: true })); })`); await sleep(500); await js(`(Array.from(document.querySelectorAll('button')).find(b => /compare/i.test(b.textContent)) || { click() {} }).click()`); await sleep(1500); await check('compare');

  // ---- 2. odd date ranges ----
  await go('dash', null, 2200);
  for (const [label, code] of [['custom reversed', `S3.dash.range='custom'; S3.dash.from='2030-01-01'; S3.dash.to='2020-01-01'`], ['custom from only', `S3.dash.range='custom'; S3.dash.from='2026-09-01'; S3.dash.to=null`], ['custom to only', `S3.dash.range='custom'; S3.dash.from=null; S3.dash.to='2026-09-01'`], ['panned far back', `S3.dash.range='1m'; S3.dash.shift=60`], ['one week', `S3.dash.range='7d'; S3.dash.shift=0`], ['ytd', `S3.dash.range='ytd'; S3.dash.shift=0`], ['all', `S3.dash.range='all'; S3.dash.shift=0`]]) {
    await js(`${code}; S3.dashRefresh()`); await sleep(1200); await check('range ' + label);
    for (const t of ['calendar', 'weekdays', 'foods', 'rel', 'trends']) { await js(`document.querySelector('[data-tab=${t}]').click()`); await sleep(500); await check('range ' + label + ' / ' + t); }
  }
  await js(`S3.dash.range='3m'; S3.dash.shift=0; S3.dash.from=null; S3.dash.to=null; S3.dashRefresh()`); await sleep(800);

  // ---- 3. unit systems ----
  for (const u of ['imperial', 'metric', 'imperial']) { await js(`S3.api('user:update', { units: '${u}' }).then(x => { S3.state.user = x; })`); await sleep(300); for (const pg of ['dash', 'nutrition', 'history', 'profile']) await go(pg, null, 1500); }

  // ---- 3b. the calibration lab: several tape sessions, then the report and re-analysed history ----
  await go('profile', null, 1800); if (!(await js(`!!document.querySelector('#calibgo')`))) note('profile: no calibration card'); await js(`S3.go('calib')`); await sleep(1500); await check('calib page empty');
  for (let i = 0; i < 4; i++) {
    await js(`(function () { const s = document.querySelector('#calscan'); s.selectedIndex = ${i}; s.dispatchEvent(new Event('change')); })()`); await sleep(600);
    await js(`document.querySelector('[data-t=waist]').value = '${(33 + i * 0.4).toFixed(1)}'; document.querySelector('[data-t=chest]').value = '38'; document.querySelector('[data-t=hips]').value = '${(40 + (i % 2) * 0.3).toFixed(1)}'; document.querySelector('#calwt').value = '158'; document.querySelector('#calbf').value = '17.5'; document.querySelector('#calsave').click(); 0`); await sleep(3500); await check('calib session ' + (i + 1));
  }
  if (!(await js(`/calibrated error/i.test(document.body.innerText)`))) note('calib: no accuracy report after 4 sessions');
  await shot('55_calib_lab', 300); await js(`(document.querySelector('[data-delcal]') || { click() {} }).click(); 0`); await sleep(2500); await check('calib remove');
  await go('dash', null, 2500); await check('dash after calibration'); await js(`S3.go('calib')`); await sleep(1200); await js(`document.querySelector('#calreset').click(); 0`); await sleep(2500); await check('calib reset');  // confirm() is stubbed to false, so this must be a safe no-op
  if (!(await js(`/calibrated error/i.test(document.body.innerText)`))) note('calib: reset ran although confirm was declined');

  // ---- 4. the scan tutorial, with a stubbed scanner ----
  await js(`(() => { const real = S3.api; S3.__real = real; window.__scanStarted = 0; S3.api = async (n, ...a) => { if (n === 'app:info') { const i = await real(n, ...a); return Object.assign({}, i, { hardware: { ok: true } }); } if (n === 'scan:start') { window.__scanStarted++; throw new Error('test stop'); } return real(n, ...a); }; })()`);
  const q = (sel) => js(`!!document.querySelector('${sel}')`); const click = (sel) => js(`document.querySelector('${sel}').click()`);
  await js(`S3.api('user:update', { skipTutorial: false }).then(x => { S3.state.user = x; })`);
  await go('scan'); if (!(await q('#go'))) note('tutorial: no Start scan button'); else {
    await click('#go'); await sleep(400);
    for (let i = 1; i <= 5; i++) {
      if (await js(`document.querySelector('#tnext') ? document.querySelector('#tnext').disabled : 'missing'`) !== false) note('tutorial step ' + i + ': Next button is not enabled');
      if (await q('#treplay')) note('tutorial step ' + i + ': a Replay voice button is still there');
      if (!(await js(`/Step ${i} of 5/.test(document.body.innerText)`))) note('tutorial: expected "Step ' + i + ' of 5"');
      if (i === 1 && (await q('#tback'))) note('tutorial: Back shown on step 1');
      if (i === 2) { await click('#tback'); await sleep(200); if (!(await js(`/Step 1 of 5/.test(document.body.innerText)`))) note('tutorial: Back did not return to step 1'); await click('#tnext'); await sleep(200); }
      if (i < 5) { await click('#tnext'); await sleep(200); }
    }
    await shot('51_tutorial_last', 200); if (!(await js(`/Start scan/.test(document.querySelector('#tnext').textContent)`))) note('tutorial: last step does not say Start scan');
    await click('#tnext'); await sleep(600); if ((await js(`window.__scanStarted`)) !== 1) note('tutorial: finishing did not start the scan (' + (await js(`window.__scanStarted`)) + ')');
    await go('scan'); await click('#go'); await sleep(300); await click('#tskip'); await sleep(500); if ((await js(`window.__scanStarted`)) !== 2) note('tutorial: Skip did not start the scan');
    await go('scan'); await click('#go'); await sleep(300); await click('#tcancel'); await sleep(400); if (!(await q('#go'))) note('tutorial: Cancel did not return to the start screen'); if ((await js(`window.__scanStarted`)) !== 2) note('tutorial: Cancel started a scan');
    await go('scan'); await click('#go'); await sleep(300); await click('#tnever'); await sleep(500); await go('scan'); await click('#go'); await sleep(500); if ((await js(`window.__scanStarted`)) !== 3) note('tutorial: "Always skip" did not skip it next time');
    await js(`S3.api('user:update', { skipTutorial: false }).then(x => { S3.state.user = x; })`);
  }
  await js(`S3.api = S3.__real; 0`);

  // ---- 5. random clicking ----
  const DENY = /calibrat|scale|adjust|delete|remove|sign ?out|log ?out|disconnect|connect|sync|new scan|start|import|clear|update|restart|refresh|analy|summar|coach|save|key|stop|cancel|demo|rehome|align/i;
  let seed = 12345; const rnd = (n) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; };
  for (let k = 0; k < 260; k++) {
    if (k % 40 === 0) { await js(`S3.go(['dash', 'nutrition', 'history', 'dash', 'profile'][${rnd(5)}])`); await sleep(1300); }
    const count = await js(`window.__cl = Array.from(document.querySelectorAll('#root button, #root .tile, #root .chip, #root .callout, #root summary, #root .calcell[data-day], #root tr.click, #root [data-wd-pick]')).filter(e => e.offsetParent && !e.closest('.cp-panel') && !e.closest('#cpBtn') && e.id !== 'out' && !e.closest('#out') && !/${DENY.source}/i.test((e.textContent || '') + ' ' + (e.id || '') + ' ' + (e.className || ''))); window.__cl.length`);
    if (!count) continue; await js(`(function () { const e = window.__cl[${rnd(1000)} % window.__cl.length]; if (e.matches('tr.click')) return; e.click(); })()`); await sleep(110);
    if (k % 20 === 19) await check('random click #' + k);
  }
  await shot('52_after_random_clicks', 300);

  // ---- 5b. rapid navigation (races), odd window sizes ----
  if (await js(`!!document.querySelector('.auth')`)) { note('the random clicks signed the user out'); await js(`S3.api('auth:login', 'alex', '4821').then(u => { S3.state.user = u; S3.state.info = null; return S3.afterAuth(); })`); await sleep(2000); }
  await js(`['dash', 'nutrition', 'history', 'dash', 'profile', 'dash', 'nutrition', 'dash', 'scan', 'dash', 'history', 'dash'].forEach((p, i) => setTimeout(() => S3.go(p), i * 40)); 0`); await sleep(3500); await check('rapid navigation');
  await js(`S3.go('dash'); 0`); await sleep(2000);
  for (const [w, h] of [[800, 600], [1920, 1080], [1024, 768], [1300, 820]]) { ctx.win.setSize(w, h); await sleep(900); await check('resize ' + w + 'x' + h); await shot('54_resize_' + w + 'x' + h, 300); }
  for (let k = 0; k < 40; k++) await js(`(document.querySelector('#explore [data-r="' + ['7d', '1m', '3m', 'all', '1y'][${k} % 5] + '"]') || { click() {} }).click(); 0`);
  await sleep(1500); await check('slicer hammering');

  // ---- 6. an empty account, then an account with one scan ----
  await js(`S3.api('auth:signup', { name: 'Empty Person', username: 'empty', email: 'e@example.com', sex: 'female', dob: '1990-01-01', height_cm: 160, units: 'imperial', goal: '', password: '1357' }).then(u => { S3.state.user = u; S3.state.info = null; return S3.afterAuth(); })`); await sleep(2000); await check('empty account dashboard');
  for (const pg of ['nutrition', 'history', 'profile', 'scan', 'dash']) await go(pg);
  await go('history'); if (await js(`new RegExp('Compare selected [(][12][/]2[)]').test(document.body.innerText)`)) note('history: a stale comparison selection from another account is still shown');
  await js(`S3.api('scan:demo').then(s => S3.go('results', s.id))`); await sleep(5000); await check('one-scan results');
  for (const pg of ['dash', 'nutrition', 'history']) await go(pg, null, 2000); await shot('53_one_scan_dash', 300);
  await js(`document.querySelector('#explore') && Array.from(document.querySelectorAll('#explore [data-tab]')).forEach(b => b.click())`); await sleep(800); await check('one-scan explore');

  const left = await js(`window.__errs.splice(0)`); left.forEach((x) => note('late: ' + x));
  fs.writeFileSync(path.join(dir, 'break_report.txt'), issues.length ? issues.join('\n') : 'No issues found.'); log('break test finished: ' + issues.length + ' issue(s)');
}
module.exports = { run };
