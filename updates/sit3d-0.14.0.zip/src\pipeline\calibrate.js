'use strict';
// Accuracy calibration: fits the scanner's raw circumference readings to tape-measure ground truth collected over several sessions.
// Each SAMPLE pairs what the scanner measured (cm) with what a tape measure said (cm) for the same scan.
//   - one or two samples: a gain per site (tape / scanner), the median so one bad tape reading cannot dominate
//   - five or more samples that cover a wide enough range: a robust straight line (Theil-Sen) per site, gain AND offset
// Honest accuracy: the error the CURRENT samples would have had if each were held out (leave-one-out) is reported next to the raw error.
// Pure functions, Node 12 compatible; also used by the tests.
const SITES = ['neck', 'chest', 'waist', 'hips', 'thigh_left', 'thigh_right'];
const LABEL = { neck: 'Neck', chest: 'Chest', waist: 'Waist (navel)', hips: 'Hips', thigh_left: 'Left thigh', thigh_right: 'Right thigh' };
const median = (a) => { const s = a.slice().sort((x, y) => x - y); const n = s.length; return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : null; };
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
const r3 = (v) => Math.round(v * 1000) / 1000, r2 = (v) => Math.round(v * 100) / 100, r1 = (v) => Math.round(v * 10) / 10;

// samples: [{ scan: { site: cm }, tape: { site: cm } }]   -> pairs for one site
function pairs(samples, site) { return samples.filter((s) => s.scan && s.tape && s.scan[site] > 10 && s.tape[site] > 10).map((s) => ({ x: s.scan[site], y: s.tape[site] })); }

// fit one site's correction. returns { a, b, kind } (value' = a * value + b)
function fitSite(p) {
  if (!p.length) return null;
  const gain = median(p.map((q) => q.y / q.x));
  const xs = p.map((q) => q.x); const range = Math.max.apply(null, xs) - Math.min.apply(null, xs);
  if (p.length >= 5 && range >= 4) {   // Theil-Sen: the median of all pairwise slopes, then the median intercept
    const slopes = []; for (let i = 0; i < p.length; i++) for (let j = i + 1; j < p.length; j++) if (Math.abs(p[j].x - p[i].x) > 0.5) slopes.push((p[j].y - p[i].y) / (p[j].x - p[i].x));
    if (slopes.length >= 3) { const a = Math.max(0.7, Math.min(1.3, median(slopes))); const b = median(p.map((q) => q.y - a * q.x)); return { a, b, kind: 'line' }; }
  }
  return { a: gain, b: 0, kind: 'gain' };
}
const apply = (f, x) => f.a * x + f.b;

// full report for one site
function siteReport(site, samples) {
  const p = pairs(samples, site); if (!p.length) return { site, label: LABEL[site], n: 0 };
  const f = fitSite(p); const before = mean(p.map((q) => Math.abs(q.x - q.y))), bias = mean(p.map((q) => q.x - q.y));
  const after = mean(p.map((q) => Math.abs(apply(f, q.x) - q.y)));
  let loo = null; if (p.length >= 3) { const errs = p.map((q, i) => { const rest = p.filter((_, j) => j !== i); const g = fitSite(rest); return Math.abs(apply(g, q.x) - q.y); }); loo = mean(errs); }
  const expected = loo != null ? loo : (p.length === 2 ? after * 1.6 : null);
  const grade = expected == null ? 'unknown' : expected <= 1 ? 'excellent' : expected <= 2 ? 'good' : expected <= 3.5 ? 'fair' : 'poor';
  return { site, label: LABEL[site], n: p.length, a: r3(f.a), b: r2(f.b), kind: f.kind, rawMean: r1(mean(p.map((q) => q.x))), tapeMean: r1(mean(p.map((q) => q.y))), rawBias: r1(bias), errBefore: r1(before), errAfter: r1(after), errExpected: expected == null ? null : r1(expected), grade };
}

// the per-site correction map the analysis uses: { site: { a, b } }
function buildCalib(samples) {
  const out = {}; for (const s of SITES) { const f = fitSite(pairs(samples, s)); if (f) out[s] = { a: r3(f.a), b: r2(f.b) }; } return out;
}

// height: scanner height vs the true height gives the camera scale (fxScale) correction
function heightReport(samples, trueHeightCm) {
  const hs = samples.filter((s) => s.scan && s.scan.height > 100).map((s) => s.scan.height); if (!hs.length || !trueHeightCm) return null;
  const m = median(hs); return { n: hs.length, scannerMedian: r1(m), trueHeight: r1(trueHeightCm), errorPct: r1((m - trueHeightCm) / trueHeightCm * 100), scaleFactor: r3(trueHeightCm / m) };
}
// optional references: a bathroom scale, DEXA / calipers
function refReport(samples, key, pick) { const d = samples.filter((s) => s[key] != null && pick(s) != null).map((s) => pick(s) - s[key]); return d.length ? { n: d.length, bias: r2(median(d)), mae: r2(mean(d.map(Math.abs))) } : null; }

// overall one-line verdict for the UI
function overall(reports) {
  const g = reports.filter((r) => r.n > 0); if (!g.length) return { grade: 'none', text: 'No calibration yet. Add at least one tape-measure session.' };
  const known = g.filter((r) => r.errExpected != null); if (!known.length) return { grade: 'starting', text: 'Calibration started. Add sessions on 2 or more different days to measure how accurate it really is.' };
  const worst = Math.max.apply(null, known.map((r) => r.errExpected)), avg = mean(known.map((r) => r.errExpected));
  return { grade: worst <= 1 ? 'excellent' : worst <= 2 ? 'good' : worst <= 3.5 ? 'fair' : 'poor', text: 'Typical error on a new scan: about ' + r1(avg) + ' cm on average, up to ' + r1(worst) + ' cm at the least accurate site.' };
}

module.exports = { SITES, LABEL, fitSite, apply, siteReport, buildCalib, heightReport, refReport, overall, median, mean };
