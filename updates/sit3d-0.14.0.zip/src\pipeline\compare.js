'use strict';
// Decides HOW to compare a measurement over time, depending on how many scans there are and how far apart they are.
//   n < 3 or all within ~2 days  -> "early": latest vs previous, flagged as too early to call
//   about daily scans            -> 7-day average vs the 7 days before (needs 3+ scans in each week)
//   4+ scans within ~8 days      -> newer half vs older half (low confidence)
//   scans spread out             -> 14-day, then 30-day windows with 2+ scans each
//   otherwise                    -> latest scan vs the previous one, directly
// Each result carries a verdict from comparing the change with the scanner's normal scan-to-scan wobble (noise):
// 'real' (change > 2x its noise), 'likely' (> 1x), 'noise' (inside it) or 'early'.
// Works in Node and in the browser (UMD). Node 12 compatible.
// (Electron's renderer has both `module` and `window`, so the browser global is always set as well)
(function (root, factory) { const api = factory(); if (typeof module === 'object' && module.exports) module.exports = api; if (typeof window !== 'undefined') window.Compare = api; else if (root) root.Compare = api; })(typeof self !== 'undefined' ? self : this, function () {
  const DAY = 86400000;
  // typical scan-to-scan standard deviation of ONE reading, in the stored (metric) units
  const NOISE = { weight_kg: 0.9, body_fat_pct: 1.2, lean_mass_kg: 0.9, waist_cm: 1.5, hips_cm: 1.5, chest_cm: 1.5, shape_score: 3, posture_score: 3, bmi: 0.3, metabolic_age: 2 };
  const mean = (a) => a.reduce((x, y) => x + y, 0) / a.length;

  function compare(points, noise1) {
    const pts = (points || []).filter((p) => p.v != null && isFinite(p.v)).map((p) => ({ t: typeof p.t === 'number' ? p.t : new Date(p.t).getTime(), v: p.v })).sort((a, b) => a.t - b.t);
    const n = pts.length; const out = { ok: false, mode: 'none', n };
    if (n < 2) { out.note = 'Take another scan to see a change.'; return out; }
    const end = pts[n - 1].t, spanDays = (end - pts[0].t) / DAY;
    const win = (w) => ({ cur: pts.filter((p) => p.t > end - w * DAY), prev: pts.filter((p) => p.t > end - 2 * w * DAY && p.t <= end - w * DAY) });
    const finish = (mode, w, cur, prev, extra) => {
      const c = mean(cur.map((p) => p.v)), p0 = mean(prev.map((p) => p.v)), delta = c - p0; const sd = noise1 * Math.sqrt(1 / cur.length + 1 / prev.length); const z = sd ? Math.abs(delta) / sd : 0;
      let verdict = z >= 2 ? 'real' : z >= 1 ? 'likely' : 'noise'; if (extra && extra.early) verdict = 'early'; else if (mode === 'window' && w <= 3 && verdict === 'real') verdict = 'likely';
      return Object.assign({ ok: true, mode, windowDays: w, nCur: cur.length, nPrev: prev.length, cur: c, prev: p0, delta, noise: sd, z, verdict, n, spanDays }, extra || {});
    };
    // not enough history to say anything solid
    if (n < 3 || spanDays < 2) {
      const r = finish('early', 0, [pts[n - 1]], [pts[n - 2]], { early: true });
      r.gapDays = (pts[n - 1].t - pts[n - 2].t) / DAY; r.note = 'Only ' + n + ' scans so far' + (r.gapDays < 2 ? ', ' + (r.gapDays < 1 ? 'less than a day' : Math.round(r.gapDays) + ' day' + (Math.round(r.gapDays) === 1 ? '' : 's')) + ' apart' : '') + ', so this is too early to call.'; return r;
    }
    let w = win(7); if (w.cur.length >= 3 && w.prev.length >= 3) return finish('window', 7, w.cur, w.prev, { note: '7-day average vs the 7 days before' });
    if (n >= 4 && spanDays < 9) {   // a young history: the newer half against the older half
      const k = Math.floor(n / 2), prev = pts.slice(0, n - k), cur = pts.slice(n - k);
      return finish('window', 3, cur, prev, { note: 'Average of your latest ' + cur.length + ' scans vs your first ' + prev.length + ' (early read: confidence grows with more scans)' });
    }
    for (const d of [14, 30]) { w = win(d); if (w.cur.length >= 2 && w.prev.length >= 2) return finish('window', d, w.cur, w.prev, { note: d + '-day average vs the ' + d + ' days before' }); }
    // sparse scans: compare the latest with the previous one directly
    const r = finish('direct', 0, [pts[n - 1]], [pts[n - 2]], {}); r.gapDays = (pts[n - 1].t - pts[n - 2].t) / DAY; r.note = 'Latest scan vs the previous one, ' + Math.round(r.gapDays) + ' day' + (Math.round(r.gapDays) === 1 ? '' : 's') + ' apart';
    if (r.gapDays < 4 && r.verdict === 'real') r.verdict = 'likely'; return r;
  }

  // slope in units per week over the last `days` days (needs 5+ points over 5+ days)
  function trend(points, days) {
    const pts = (points || []).filter((p) => p.v != null).map((p) => ({ t: typeof p.t === 'number' ? p.t : new Date(p.t).getTime(), v: p.v })).sort((a, b) => a.t - b.t); if (!pts.length) return null;
    const end = pts[pts.length - 1].t; const w = pts.filter((p) => p.t >= end - days * DAY); if (w.length < 5 || (end - w[0].t) / DAY < 5) return null;
    const xs = w.map((p) => (p.t - w[0].t) / DAY), ys = w.map((p) => p.v), mx = mean(xs), my = mean(ys); let a = 0, b = 0; for (let i = 0; i < xs.length; i++) { a += (xs[i] - mx) * (ys[i] - my); b += (xs[i] - mx) * (xs[i] - mx); }
    return b ? { perWeek: a / b * 7, points: w.length, days: Math.round((end - w[0].t) / DAY) } : null;
  }
  // The user's OWN scan-to-scan wobble, from consecutive scans no more than 2 days apart: the difference of two independent readings has
  // variance 2 sigma^2, so sigma = median(|diff|) / 0.6745 / sqrt(2) (robust to the odd real change). Needs 6+ pairs, else null.
  function estimateNoise(points) {
    const pts = (points || []).filter((p) => p.v != null && isFinite(p.v)).map((p) => ({ t: typeof p.t === 'number' ? p.t : new Date(p.t).getTime(), v: p.v })).sort((a, b) => a.t - b.t); const d = [];
    for (let i = 1; i < pts.length; i++) if (pts[i].t - pts[i - 1].t <= 2 * DAY && pts[i].t - pts[i - 1].t > 0.1 * DAY) d.push(Math.abs(pts[i].v - pts[i - 1].v));
    if (d.length < 6) return null; const s = d.slice().sort((a, b) => a - b); const med = s.length % 2 ? s[(s.length - 1) / 2] : (s[s.length / 2 - 1] + s[s.length / 2]) / 2;
    return { sd: med / 0.6745 / Math.SQRT2, pairs: d.length };
  }
  const verdictText = { real: 'a real change', likely: 'probably real', noise: 'within normal scan noise', early: 'too early to call' };
  return { compare, trend, estimateNoise, NOISE, verdictText };
});
