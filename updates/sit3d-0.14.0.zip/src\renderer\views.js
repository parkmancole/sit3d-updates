(function () {
'use strict';
const S3 = window.S3, { esc, $, $$ } = S3;

const METRICS = [
  { k: 'weight_kg', label: 'Weight', unit: () => S3.unitsWt(), get: s => S3.kgVal(s.weight_kg), good: 0, dec: 1 },
  { k: 'body_fat_pct', label: 'Body fat', unit: () => '%', get: s => s.body_fat_pct, good: -1, dec: 1 },
  { k: 'lean_mass_kg', label: 'Lean mass', unit: () => S3.unitsWt(), get: s => S3.kgVal(s.lean_mass_kg), good: 1, dec: 1 },
  { k: 'waist_cm', label: 'Waist', unit: () => S3.unitsLen(), get: s => S3.cmVal(s.waist_cm), good: -1, dec: 1 },
  { k: 'shape_score', label: 'Shape score', unit: () => '/100', get: s => s.shape_score, good: 1, dec: 0 },
  { k: 'posture_score', label: 'Posture score', unit: () => '/100', get: s => s.posture_score, good: 1, dec: 0 },
  { k: 'bmi', label: 'BMI', unit: () => '', get: s => s.bmi, good: 0, dec: 1 },
  { k: 'hips_cm', label: 'Hips', unit: () => S3.unitsLen(), get: s => S3.cmVal(s.hips_cm), good: 0, dec: 1 },
  { k: 'chest_cm', label: 'Chest', unit: () => S3.unitsLen(), get: s => S3.cmVal(s.chest_cm), good: 0, dec: 1 },
  { k: 'metabolic_age', label: 'Metabolic age', unit: () => 'yrs', get: s => s.metabolic_age, good: -1, dec: 0 },
];
const metricVal = (m, s) => { const v = m.get(s); return v == null ? null : v; };
const fmt = (v, dec) => (v == null ? '—' : v.toFixed(dec));
function deltaHtml(m, cur, prev) {
  if (cur == null || prev == null) return '<span class="delta neu">first scan</span>';
  const d = cur - prev; if (Math.abs(d) < Math.pow(10, -m.dec) / 2) return '<span class="delta neu">no change</span>';
  const cls = m.good === 0 ? 'neu' : ((d > 0) === (m.good > 0) ? 'good' : 'bad');
  return `<span class="delta ${cls}">${d > 0 ? '▲' : '▼'} ${Math.abs(d).toFixed(m.dec)} ${esc(m.unit())}</span>`;
}
// Dynamic comparison (see pipeline/compare.js): 7-day average vs the 7 days before when scans are frequent, direct latest-vs-previous when they are
// spread out, and an honest "too early" while there is little data. Changes inside normal scan noise are shown in grey.
function deltaCmp(m, scans, compact) {
  if (!window.Compare) return '';   // never let a missing helper stop the dashboard from drawing
  const f = m.get({ [m.k]: 1 }); const pts = scans.map(s => ({ t: s.created, v: metricVal(m, s) })); const est = window.Compare.estimateNoise(pts);   // the user's own scan-to-scan wobble once there are enough daily scans
  const c = window.Compare.compare(pts, est ? est.sd : (window.Compare.NOISE[m.k] || 0) * (f == null ? 1 : f));
  if (!c.ok) return '<span class="delta neu">first scan</span>';
  const d = c.delta, tiny = Math.abs(d) < Math.pow(10, -m.dec) / 2; const solid = c.verdict === 'real' || c.verdict === 'likely';
  const cls = (tiny || m.good === 0 ? 'neu' : ((d > 0) === (m.good > 0) ? 'good' : 'bad')) + (solid ? '' : ' weak');   // direction keeps its colour; it is just paler until the read is solid
  const how = c.mode === 'window' ? (c.windowDays >= 7 ? c.windowDays + 'd avg vs prior ' + c.windowDays + 'd' : 'newer vs older scans') : c.mode === 'early' ? 'vs last scan' : 'vs scan ' + Math.round(c.gapDays) + 'd ago';
  const vt = { real: 'real change', likely: 'likely real', noise: 'within noise', early: 'too early' }[c.verdict];
  return `<span class="delta ${cls}" title="${esc(c.note + '. ' + vt + '.')}">${tiny ? 'no change' : (d > 0 ? '▲ ' : '▼ ') + Math.abs(d).toFixed(m.dec) + ' ' + esc(m.unit())}</span>${compact ? '' : `<div class="cmpnote">${esc(how)} · ${vt}</div>`}`;
}
const root = () => $('#root');
let activeViewer = null;
function killViewer() { if (activeViewer) { activeViewer.destroy(); activeViewer = null; } }

// ---------------- auth ----------------
S3.viewAuth = (mode = 'login', msg = '') => {
  if (S3.coachUnmount) S3.coachUnmount(); S3.state.insightsAuto = false; S3.state.insights = null; S3.state.insightsP = null; S3.state.insightsErr = null; S3.state.scanDone = false; killViewer(); const first = S3.state.info.users === 0; if (first && mode === 'login') mode = 'signup';
  const art = `<div class="auth-art"><div class="logo">S<span class="star">*</span>it3D</div><div><h2>Your body, in 3D. Your progress, in one place.</h2><p>Scan in under a minute, see your measurements and how they change, and keep every scan private on this computer.</p></div><div class="small" style="opacity:.8">Local app · no cloud · your data stays on this PC</div><div class="ring"></div><div class="ring r2"></div></div>`;
  if (mode === 'login') {
    const users = S3.state.authUsers || [];
    const pick = (u) => { const ini = esc(u.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase());
      root().innerHTML = `<div class="auth">${art}<div class="auth-form"><form class="auth-card" id="f"><button type="button" class="btn ghost" id="back" style="align-self:flex-start">← All users</button><div class="center col" style="align-items:center;gap:8px"><div class="avatar" style="width:84px;height:84px;font-size:32px">${ini}</div><h1 style="margin:0">${esc(u.name)}</h1></div>${msg ? `<div class="err">${esc(msg)}</div>` : ''}<div class="f"><span>Enter your PIN</span>${S3.pinPad('password')}</div><button class="btn big" type="submit">Sign in</button></form></div></div>`;
      $('#back').onclick = () => S3.viewAuth('login');
      $('#f').onsubmit = async (e) => { e.preventDefault(); const f = new FormData(e.target); try { S3.state.user = await S3.api('auth:login', u.id, f.get('password')); await S3.afterAuth(); } catch (err) { pick2(u, err.message); } };
    };
    const pick2 = (u, m) => { msg = m; pick(u); };
    S3.api('auth:users').then((list) => {
      S3.state.authUsers = list;
      root().innerHTML = `<div class="auth">${art}<div class="auth-form"><div class="auth-card"><h1>Who's scanning?</h1><p class="muted" style="margin:0">Tap your name to sign in.</p><div class="usergrid">${list.map((u, i) => `<button class="usertile" data-i="${i}"><span class="avatar">${esc(u.name.split(/\s+/).map(w => w[0]).join('').slice(0, 2).toUpperCase())}</span><span>${esc(u.name)}</span></button>`).join('')}</div><button class="btn big" id="go2">Create an account</button></div></div></div>`;
      root().querySelectorAll('.usertile').forEach(b => b.onclick = () => { msg = ''; pick(list[+b.dataset.i]); });
      $('#go2').onclick = () => S3.viewAuth('signup');
    });
  } else {
    root().innerHTML = `<div class="auth">${art}<div class="auth-form"><form class="auth-card" id="f"><h1>Create your account</h1><p class="muted" style="margin:0">A few basics so we can calculate your results.${first ? ' This is the first account on this computer.' : ''}</p><div class="err" id="ferr" style="display:none"></div>
      <div class="grid2"><label class="f">First name<input type="text" name="first" autocapitalize="words" autocomplete="given-name" required></label><label class="f">Last name<input type="text" name="last" autocapitalize="words" autocomplete="family-name" required></label></div>
      <label class="f">Email (optional)<input type="email" name="email" autocapitalize="none"></label>
      <div class="grid2"><label class="f">Sex (for body-composition formulas)<select name="sex"><option value="">Choose…</option><option value="male">Male</option><option value="female">Female</option></select></label><label class="f">Date of birth<input type="date" name="dob" required></label></div>
      <div class="grid2"><label class="f">Height<input type="number" step="0.1" name="height" placeholder="cm or inches" required></label><label class="f">Units<select name="units"><option value="metric">Metric (cm, kg)</option><option value="imperial">Imperial (in, lb)</option></select></label></div>
      <label class="f">Goal (optional)<input type="text" name="goal" autocapitalize="sentences" placeholder="e.g. lose 5 kg, build muscle"></label>
      <div class="f"><span>PIN (4 to 8 digits, numbers only)</span>${S3.pinPad('password')}</div>
      <button class="btn big" type="submit">Create account</button><div class="center muted">${first ? '' : 'Already have an account? <a href="#" id="go" style="color:var(--orange-dark);font-weight:600">Sign in</a>'}</div></form></div></div>`;
    if ($('#go')) $('#go').onclick = (e) => { e.preventDefault(); S3.viewAuth('login'); };
    $('#f').onsubmit = async (e) => {
      e.preventDefault(); const f = new FormData(e.target); const imp = f.get('units') === 'imperial'; const h = parseFloat(f.get('height'));
      try { S3.state.user = await S3.api('auth:signup', { name: (String(f.get('first')).trim() + ' ' + String(f.get('last')).trim()).trim(), email: f.get('email'), sex: f.get('sex'), dob: f.get('dob'), height_cm: imp ? h * 2.54 : h, units: f.get('units'), goal: f.get('goal'), password: f.get('password') }); await S3.afterAuth(); }
      catch (err) { const el = $('#ferr'); el.textContent = err.message; el.style.display = 'block'; el.scrollIntoView({ block: 'nearest' }); }
    };
  }
};

// ---------------- shell ----------------
S3.shell = (route, inner) => {
  const u = S3.state.user, nav = [['dash', 'Dashboard', S3.icon.dash], ['scan', 'New scan', S3.icon.scan], ['history', 'History', S3.icon.hist], ['nutrition', 'Nutrition', S3.icon.food], ['profile', 'Profile', S3.icon.user]];
  root().innerHTML = `<div id="app"><aside class="side"><div class="logo">S<span class="star">*</span>it3D<small>body scanner</small></div>${nav.map(n => `<button class="nav ${route === n[0] ? 'active' : ''}" data-go="${n[0]}">${n[2]}${n[1]}</button>`).join('')}<div class="spacer"></div><div class="userchip"><div class="avatar">${esc((u.name || '?')[0].toUpperCase())}</div><div class="grow"><div class="nm">${esc(u.name)}</div><div class="un">${S3.state.scans && S3.state.scans.length ? S3.state.scans.length + " scan" + (S3.state.scans.length > 1 ? "s" : "") : "Signed in"}</div></div><button class="nav" style="width:auto;padding:8px" title="Sign out" id="out">${S3.icon.out}</button></div></aside><main class="main" id="main">${inner}</main></div>`;
  $$('[data-go]').forEach(b => b.onclick = () => S3.go(b.dataset.go));
  $('#out').onclick = async () => { await S3.api('auth:logout'); S3.state.user = null; S3.viewAuth('login'); };
  if (S3.coachMount) S3.coachMount();
};

// ---------------- dashboard ----------------
S3.updBanner = async () => {
  const el = $('#updbanner'); if (!el) return;
  try {
    const st = await S3.api('update:status'); if (!st.available) return;
    el.innerHTML = `<div class="card flat" style="margin-bottom:16px;border-left:4px solid var(--orange)"><div class="row"><div class="grow"><b>Update ${esc(st.available.version)} is ready</b><div class="small muted">${esc(st.available.notes || 'Restart the app to use the new version.')}</div></div><button class="btn" id="updnow">Restart now</button></div></div>`;
    $('#updnow').onclick = () => S3.api('update:restart').catch((e) => S3.toast(e.message));
  } catch (e) { /* optional */ }
};
S3.nutCard = async (lastScan) => {
  const el = $('#nutcard'); if (!el) return;
  try {
    const n = await S3.api('nutrition:get'); const sm = n.summary;
    if (!sm) { el.innerHTML = `<div class="card flat" style="margin-bottom:16px"><div class="row"><div class="grow"><h3 style="margin:0 0 4px">Add nutrition to your progress</h3><p class="muted small" style="margin:0">Import a MyFitnessPal, Cronometer or Lose It! export to see your calorie and protein intake next to your scans.</p></div><button class="btn secondary" id="nutgo">Import</button></div></div>`; $('#nutgo').onclick = () => S3.go('profile'); return; }
    const a = sm.avg28, mx = Math.max(1, ...sm.series.map(x => x.kcal || 0)); const bw = 100 / sm.series.length;
    const bars = sm.series.map((x, i) => `<rect x="${(i * bw + 0.6).toFixed(2)}" y="${(40 - (x.kcal || 0) / mx * 38).toFixed(1)}" width="${(bw - 1.2).toFixed(2)}" height="${((x.kcal || 0) / mx * 38).toFixed(1)}" rx="1" fill="${x.kcal ? '#F58220' : '#F3E6D6'}"></rect>`).join('');
    const stale = sm.staleDays > 14 ? `<div class="small muted">Your last imported day is ${esc(sm.last)}. Import a newer export to keep this current.</div>` : '';
    el.innerHTML = `<div class="card" style="margin-bottom:16px"><div class="row" style="margin-bottom:6px"><h3 class="grow" style="margin:0">Nutrition</h3><button class="btn ghost" id="nutgo">Manage</button></div><div class="row" style="gap:28px;flex-wrap:wrap;align-items:flex-start"><div><div class="lbl small muted">Average intake (${a.n} logged days)</div><div style="font-size:30px;font-weight:750">${a.kcal == null ? '—' : a.kcal.toLocaleString()}<small> kcal/day</small></div></div><div><div class="lbl small muted">Protein</div><div style="font-size:22px;font-weight:700">${a.protein == null ? '—' : a.protein}<small> g</small></div>${sm.proteinPerKg ? `<div class="small muted">${S3.perWt(sm.proteinPerKg)}</div>` : ''}</div><div><div class="lbl small muted">Carbs</div><div style="font-size:22px;font-weight:700">${a.carbs == null ? '—' : a.carbs}<small> g</small></div></div><div><div class="lbl small muted">Fat</div><div style="font-size:22px;font-weight:700">${a.fat == null ? '—' : a.fat}<small> g</small></div></div><div class="grow" style="min-width:220px"><svg viewBox="0 0 100 42" preserveAspectRatio="none" style="width:100%;height:56px">${bars}</svg><div class="small muted">Daily calories, last 28 days</div></div></div><div class="small muted" id="syncnote"></div>${stale}</div>`;
    $('#nutgo').onclick = () => S3.go('profile');
    S3.progressHandlers = S3.progressHandlers || {}; S3.progressHandlers.note = (p) => { const n = $('#syncnote'); if (n) n.textContent = p.running ? 'Syncing ' + (p.app === 'mnd' ? 'MyNetDiary' : 'MyFitnessPal') + '… ' + Math.round((p.p || 0) * 100) + '%' : ''; };
  } catch (e) { /* nutrition card is optional */ }
};
S3.viewDash = async () => {
  killViewer(); const u = S3.state.user; const scans = await S3.api('scans:list'); S3.state.scans = scans; const sel = S3.state.metric || 'body_fat_pct';
  const hello = (() => { const h = new Date().getHours(); return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening'; })();
  if (!scans.length) {
    S3.shell('dash', `<div class="page-head"><div><h1>${hello}, ${esc(u.name.split(' ')[0])}</h1><p>Let’s take your first scan — it only takes about a minute.</p></div></div><div class="card empty"><div class="big">No scans yet</div><p>Your dashboard will show your measurements and progress here.</p><div class="row" style="justify-content:center;margin-top:18px"><button class="btn big" data-go="scan">Start your first scan</button><button class="btn secondary big" id="demo">Try a demo scan</button></div></div>`);
    $$('[data-go]').forEach(b => b.onclick = () => S3.go(b.dataset.go)); $('#demo').onclick = async () => { $('#demo').disabled = true; $('#demo').textContent = 'Processing…'; try { const s = await S3.api('scan:demo'); S3.go('results', s.id); } catch (e) { S3.toast(e.message); $('#demo').disabled = false; } };
    return;
  }
  const last = scans[scans.length - 1], prev = scans.length > 1 ? scans[scans.length - 2] : null, first = scans[0];
  const curOf = (m) => { for (let i = scans.length - 1; i >= 0; i--) { const v = metricVal(m, scans[i]); if (v != null) return v; } return null; };   // the latest scan that actually has this measurement
  const tileOf = (k) => { const m = METRICS.find(x => x.k === k); const cur = curOf(m);
    return `<div class="tile ${sel === m.k ? 'sel' : ''}" data-m="${m.k}"><div class="lbl">${m.label}</div><div class="val">${fmt(cur, m.dec)}<small>${esc(m.unit())}</small></div>${deltaCmp(m, scans)}${S3.sparkline(scans.map(s => metricVal(m, s)))}</div>`; };
  // body map: a figure with call-outs to where the chest, waist and hips are measured
  const callout = (k, side, top) => { const m = METRICS.find(x => x.k === k); const cur = curOf(m);
    return `<div class="callout ${side} ${sel === k ? 'sel' : ''}" data-m="${k}" style="top:${top}%"><div class="lbl">${m.label}</div><div class="val">${fmt(cur, m.dec)}<small>${esc(m.unit())}</small></div>${deltaCmp(m, scans, true)}</div>`; };
  const yc = 420 * 0.27, yw = 420 * 0.39, yh = 420 * 0.54;
  const bodyMap = `<div class="card bodymap"><h3 style="margin:0 0 4px">Body measurements</h3><div class="bm"><svg viewBox="0 0 360 420" class="bmsvg"><g fill="#FFEBD6" stroke="#F4B67A" stroke-width="2"><circle cx="180" cy="40" r="24"/><rect x="171" y="62" width="18" height="18" rx="5"/><path d="M138 88 Q180 76 222 88 L218 140 Q212 172 218 215 Q222 235 214 250 L146 250 Q138 235 142 215 Q148 172 142 140 Z"/><path id="arm" d="M138 90 Q112 100 106 150 L100 215 Q100 226 109 226 Q118 226 118 215 L125 152 Q131 122 144 112 Z"/><use href="#arm" transform="translate(360,0) scale(-1,1)"/><path id="leg" d="M147 248 L179 248 L174 396 Q173 408 163 408 Q153 408 153 396 Z"/><use href="#leg" transform="translate(360,0) scale(-1,1)"/></g><g stroke="#F58220" stroke-width="2" fill="#F58220"><line x1="221" y1="${yc}" x2="262" y2="${yc}"/><circle cx="221" cy="${yc}" r="4.5"/><line x1="143" y1="${yw}" x2="98" y2="${yw}"/><circle cx="143" cy="${yw}" r="4.5"/><line x1="219" y1="${yh}" x2="262" y2="${yh}"/><circle cx="219" cy="${yh}" r="4.5"/></g></svg>${callout('chest_cm', 'r', 27)}${callout('waist_cm', 'l', 39)}${callout('hips_cm', 'r', 54)}</div></div>`;
  const tiles = `<div class="dtop"><div class="dleft"><div class="tiles2">${['body_fat_pct', 'weight_kg', 'lean_mass_kg', 'bmi'].map(tileOf).join('')}</div><div class="tiles2 three">${['shape_score', 'posture_score', 'metabolic_age'].map(tileOf).join('')}</div></div>${bodyMap}</div>`;
  const m = METRICS.find(x => x.k === sel);
  const changeSince = (mm) => { const a = metricVal(mm, first), b = metricVal(mm, last); return a == null || b == null || scans.length < 2 ? null : b - a; };
  const rows = scans.slice().reverse().slice(0, 6).map(s => `<tr class="click" data-open="${s.id}"><td>${S3.fmtDate(s.created, true)}</td><td class="r">${S3.kg(s.weight_kg)} ${S3.unitsWt()}</td><td class="r">${fmt(s.body_fat_pct, 1)}%</td><td class="r">${S3.cm(s.waist_cm)} ${S3.unitsLen()}</td><td class="r">${s.shape_score == null ? '—' : s.shape_score}</td></tr>`).join('');
  const goal = u.goal ? `<div class="card flat"><h3>Your goal</h3><p style="margin:0;font-size:17px">${esc(u.goal)}</p></div>` : '';
  const sinceBlock = scans.length > 1 ? `<div class="card"><h3>Since your first scan</h3><div class="kv">${[['Body fat', 'body_fat_pct'], ['Lean mass', 'lean_mass_kg'], ['Waist', 'waist_cm'], ['Weight', 'weight_kg']].map(([l, k]) => { const mm = METRICS.find(x => x.k === k); const d = changeSince(mm); return `<div>${l}</div><div>${d == null ? '—' : (d > 0 ? '+' : '') + d.toFixed(mm.dec) + ' ' + mm.unit()}</div>`; }).join('')}</div></div>` : '';
  S3.shell('dash', `<div class="page-head"><div><h1>${hello}, ${esc(u.name.split(' ')[0])}</h1><p>${scans.length} scan${scans.length > 1 ? 's' : ''} · last scan ${S3.fmtDate(last.created, true)}</p></div><button class="btn big" data-go="scan">New scan</button></div>
    <div id="updbanner"></div><div id="aicard"></div><div id="fbar"></div>${tiles}<div id="nutcard"></div><div id="wtcard"></div><div id="explore"></div>
    <div id="mchart"></div>
    <div class="two"><div class="card"><div class="row" style="margin-bottom:8px"><h3 class="grow" style="margin:0">Recent scans</h3><button class="btn ghost" data-go="history">See all</button></div><table class="t"><thead><tr><th>Date</th><th class="r">Weight</th><th class="r">Body fat</th><th class="r">Waist</th><th class="r">Shape</th></tr></thead><tbody>${rows}</tbody></table></div><div class="col">${sinceBlock}${goal}<div class="card flat"><h3>Tip</h3><p style="margin:0;color:var(--ink-2);line-height:1.5">For the most comparable results, scan at a similar time of day in the same form-fitting clothes — loose clothing adds to your measurements.</p></div></div></div>`);
  $$('[data-go]').forEach(b => b.onclick = () => S3.go(b.dataset.go)); $$('[data-m]').forEach(t => t.onclick = () => { S3.state.metric = t.dataset.m; S3.viewDash(); }); $$('[data-open]').forEach(r => r.onclick = () => S3.go('results', r.dataset.open));
  S3.METRICS = METRICS; S3.metricVal = metricVal; S3.dashRedraw = () => S3.metricCard(scans); S3.metricCard(scans);
  if (S3.filterBar) S3.filterBar(); if (S3.weightCard) S3.weightCard(); if (S3.exploreCard) S3.exploreCard();
  S3.nutCard(last); S3.updBanner(); if (S3.aiCard) S3.aiCard();
};

// ---------------- scan flow ----------------
const PHASE_ORDER = ['starting', 'sensors', 'board', 'armed', 'countdown', 'scanning', 'finishing', 'saving', 'processing'];
S3.viewScan = async () => {
  killViewer(); const info = await S3.api('app:info'); S3.state.info = info; const hw = info.hardware;
  const sim = !hw.ok;
  S3.shell('scan', `<div class="page-head"><div><h1>New scan</h1><p>${sim ? 'The turntable was not detected. Check that its USB cable is plugged in.' : 'Turntable connected and ready.'}</p></div></div>
    <div class="row scanrow" style="align-items:flex-start;gap:22px"><div class="grow"><div class="stage" id="stage"></div></div>
    <div style="width:340px;flex:none" class="col"><div class="card"><h3>Before you scan</h3><ul class="checklist"><li>Wear <b>underwear or very tight, minimal clothing</b>. The scanner measures whatever it sees, so clothes add size.</li><li>Tie back long hair and take off shoes, jewellery and anything in your pockets.</li><li>Stand on the footprints, <b>facing the pole</b>, feet shoulder-width apart.</li><li>Hold <b>both handle buttons</b> the whole time — about 40 seconds.</li><li><b>Stand completely still</b> while the platform turns once: no talking, no shifting, look straight ahead.</li></ul></div><div class="card flat"><h3>Scanner</h3><div class="kv"><div>Turntable</div><div>${hw.ok ? 'Connected' : 'Not found'}</div><div>Mode</div><div>${sim ? 'Not connected' : 'Live'}</div></div>${hw.ok ? '<button class="btn ghost" id="rehome" style="margin-top:8px">Align platform now</button>' : '<button class="btn ghost" id="recheck" style="margin-top:8px">Check again</button>'}</div></div></div>`);
  if ($('#recheck')) $('#recheck').onclick = () => S3.viewScan();
  if ($('#rehome')) $('#rehome').onclick = async () => { if (!confirm('The platform will turn by itself. Make sure nobody is standing on it.')) return; stage({ kind: 'homing', message: 'Re-homing the platform. Stay clear of it.' }); try { await S3.api('scanner:rehome'); } catch (e) { S3.toast(e.message); } S3.viewScan(); };
  const stage = (st) => { const el = $('#stage'); if (!el) return; el.innerHTML = stageHtml(st); const b = $('#go'); if (b) b.onclick = () => begin(false); const bs = $('#sim'); if (bs) bs.onclick = () => startScan(true); const bc = $('#recheck2'); if (bc) bc.onclick = () => S3.viewScan(); const c = $('#cancel'); if (c) c.onclick = () => S3.api('scan:cancel'); };
  const idleStage = () => stage({ kind: 'idle', sim, tt: hw.ok });
  let cdTimer = null, progTimer = null, cdActive = false;
  const clearTimers = () => { clearInterval(cdTimer); clearInterval(progTimer); cdActive = false; };
  S3.on('scan:phase', (p) => {
    const ph = p.phase;
    if (ph === 'starting' || ph === 'sensors' || ph === 'board' || ph === 'homing') { stage({ kind: 'prep', ph, message: p.message }); }
    else if (ph === 'armed') { stage({ kind: 'armed', message: p.message }); S3.sfx.armed(); }
    else if (ph === 'countdown') { if (cdActive) return; clearTimers(); cdActive = true; let n = 4; const tick = () => { stage({ kind: 'count', n }); if (n > 0) { n > 3 ? S3.sfx.tick() : S3.sfx.countdown(); } n--; if (n < 0) clearInterval(cdTimer); }; tick(); cdTimer = setInterval(tick, 1000); }
    else if (ph === 'scanning') { clearTimers(); S3.sfx.go(); const t0 = p.startedAt || Date.now(), exp = p.expectedS || 38; const upd = () => { const e = (Date.now() - t0) / 1000; stage({ kind: 'scanning', frac: Math.min(0.99, e / exp), e }); }; upd(); progTimer = setInterval(upd, 500); }
    else if (ph === 'finishing') { clearTimers(); S3.sfx.done(); stage({ kind: 'finishing', message: p.message }); }
    else if (ph === 'saving') stage({ kind: 'prep', ph: 'saving', message: p.message });
    else if (ph === 'processing') stage({ kind: 'processing', frac: 0, message: p.message });
    else if (ph === 'error') { clearTimers(); S3.sfx.error(); stage({ kind: 'error', message: p.message }); }
  });
  S3.on('scan:progress', (p) => { const b = $('#procbar'); if (b) { b.style.width = Math.round(p.p * 100) + '%'; const m = $('#procmsg'); if (m) m.textContent = p.msg || ''; } });
  async function startScan(simulated) { try { stage({ kind: 'prep', ph: 'starting', message: 'Getting ready…' }); const s = await S3.api('scan:start', simulated ? 'simulate' : 'live'); S3.toast('Scan saved.'); S3.state.scanDone = true; S3.state.insightsAuto = false; if (S3.runInsights) S3.runInsights(); S3.go('results', s.id); } catch (e) { /* error stage already shown */ } }
  // ---- required walkthrough before each scan (skippable; Preferences can switch it off for good) ----
  const runTutorial = () => new Promise((resolve) => {
    let i = 0;
    const show = () => {
      const s = S3.TUT[i], last = i === S3.TUT.length - 1;
      stage({ kind: 'tut', i, n: S3.TUT.length, s, last, never: !!(S3.state.user && S3.state.user.skipTutorial) });
      if ($('#tnext')) $('#tnext').onclick = () => { if (last) { resolve(true); } else { i++; show(); } };
      if ($('#tback')) $('#tback').onclick = () => { i = Math.max(0, i - 1); show(); };
      if ($('#tskip')) $('#tskip').onclick = () => { resolve(true); };
      if ($('#tcancel')) $('#tcancel').onclick = () => { resolve(false); };
      if ($('#tnever')) $('#tnever').onchange = async (e) => { try { S3.state.user = await S3.api('user:update', { skipTutorial: e.target.checked }); } catch (err) { S3.toast(err.message); } };
    };
    show();
  });
  const begin = async (simulated) => {
    if (!simulated && !(S3.state.user && S3.state.user.skipTutorial)) { const ok = await runTutorial(); if (!ok) return idleStage(); }
    startScan(simulated);
  };
  idleStage();
};
S3.TUT = [
  { key: 'tut1', title: 'Wear underwear or very tight clothing', text: 'The scanner measures whatever it sees, so loose or thick clothes add size to your results.' },
  { key: 'tut2', title: 'Tie back hair, remove extras', text: 'Tie back long hair. Take off shoes and jewellery, and empty your pockets.' },
  { key: 'tut3', title: 'Stand on the footprints', text: 'After the platform lines itself up, step on. Face the pole with your feet shoulder-width apart.' },
  { key: 'tut4', title: 'Hold both handle buttons', text: 'Keep holding them the whole time. The scan starts 4 seconds after you grip both, and takes about 40 seconds.' },
  { key: 'tut5', title: 'Stand completely still', text: 'No talking or shifting while the platform turns once. Look straight ahead and let go only when it stops.' },
];
function stageHtml(st) {
  const steps = (i) => `<div class="steps">${[0, 1, 2, 3].map(j => `<i class="${j <= i ? 'on' : ''}"></i>`).join('')}</div>`;
  switch (st.kind) {
    case 'idle': return st.sim
      ? `<div class="avatar" style="width:92px;height:92px;font-size:44px;background:#E5484D">!</div><h1>Turntable not detected</h1><p>Plug in the turntable's USB cable, wait a few seconds, then press <b>Check again</b>. The platform will turn by itself to line up its start mark before every scan, so keep it clear.</p><button class="btn big" id="recheck2">Check again</button><button class="btn ghost" id="sim">Try a simulated scan instead</button>`
      : `<div class="avatar" style="width:92px;height:92px;font-size:38px">${S3.icon.scan.replace('<svg', '<svg width="46" height="46"')}</div><h1>Ready when you are</h1><p>Press start. The platform will first turn by itself to line up with its start mark (stay <b>off</b> it until it stops). Then you will be told when to step on.</p><button class="btn big" id="go">Start scan</button>`;
    case 'prep': return `${steps({ starting: 0, sensors: 1, board: 2, homing: 2, saving: 3 }[st.ph] || 0)}<div class="pulse">${S3.icon.scan.replace('<svg', '<svg width="54" height="54"')}</div><h1>${{ starting: 'Starting up', sensors: 'Sensors ready', board: 'Turntable ready', homing: 'Resetting the platform', saving: 'Saving your scan' }[st.ph] || 'One moment'}</h1><p>${esc(st.message || '')}</p>${st.ph === 'homing' ? '<p><b>Please stay off the platform until it stops.</b></p>' : ''}<button class="btn secondary" id="cancel">Cancel</button>`;
    case 'tut': return `${'<div class="steps">' + Array.from({ length: st.n }, (_, j) => `<i class="${j <= st.i ? 'on' : ''}"></i>`).join('') + '</div>'}<div class="muted small">Step ${st.i + 1} of ${st.n}</div><h1>${esc(st.s.title)}</h1><p style="font-size:18px;max-width:520px">${esc(st.s.text)}</p><div class="row" style="justify-content:center">${st.i ? '<button class="btn secondary" id="tback">Back</button>' : ''}<button class="btn big" id="tnext">${st.last ? 'I am ready. Start scan' : 'Next'}</button></div><div class="row" style="justify-content:center"><button class="btn ghost" id="tskip">Skip tutorial</button><button class="btn ghost" id="tcancel">Cancel</button></div><label class="row small muted" style="justify-content:center"><input type="checkbox" id="tnever" ${st.never ? 'checked' : ''}> Always skip this tutorial</label>`;
    case 'armed': return `${steps(3)}<div class="pulse"><span style="font-size:46px;font-weight:800">GO</span></div><h1>Step on and hold both buttons</h1><p>${esc(st.message || '')}</p><p class="muted">The scan starts 4 seconds after you grip both buttons.</p><button class="btn secondary" id="cancel">Cancel</button>`;
    case 'count': return `<div class="bignum">${st.n || '✓'}</div><h1>${st.n ? 'Hold still…' : 'Scanning'}</h1><p>Keep holding both buttons.</p>`;
    case 'scanning': return `<div class="ringwrap">${S3.ring(st.frac)}<div class="mid">${S3.fmtDur(st.e)}</div></div><h1>Scanning…</h1><p>Keep holding both buttons until the platform stops. Let go only at the end.</p>`;
    case 'finishing': return `<div class="avatar" style="width:92px;height:92px;font-size:44px">✓</div><h1>Scan complete</h1><p>${esc(st.message || '')}</p>`;
    case 'processing': return `<div class="pulse"><span style="font-size:34px">3D</span></div><h1>Building your 3D model</h1><div class="bar"><b id="procbar" style="width:3%"></b></div><p id="procmsg" class="muted">Working…</p>`;
    case 'homing': return `<div class="pulse">⟳</div><h1>Re-homing the platform</h1><p>${esc(st.message)}</p>`;
    case 'error': return `<div class="avatar" style="width:92px;height:92px;font-size:44px;background:#E5484D">!</div><h1>Scan didn’t finish</h1><p>${esc(st.message)}</p><button class="btn big" id="go">Try again</button>`;
  } return '';
}

// ---------------- results ----------------
S3.viewResults = async (id, tab = 'overview') => {
  killViewer(); const { scan, view } = await S3.api('scans:get', id); const a = scan.analysis, u = S3.state.user, c = a.composition, b = a.body;
  const tabs = [['overview', 'Overview'], ['measure', 'Measurements'], ['comp', 'Body composition'], ['posture', 'Posture & balance']];
  const sc = c.shape_score;
  const tile = (l, v, un, extra = '') => `<div class="tile" style="cursor:default"><div class="lbl">${l}</div><div class="val">${v}<small>${un}</small></div>${extra}</div>`;
  let body = '';
  if (tab === 'overview') {
    body = `<div class="tiles">${tile('Shape score', sc == null ? '—' : sc, '/100', sc == null ? '' : S3.gauge(sc))}${tile('Body fat', c.body_fat_pct == null ? '—' : c.body_fat_pct.toFixed(1), '%', `<span class="tag ${c.confidence === 'medium' ? 'med' : 'low'}">${esc(c.confidence)} confidence</span>`)}${tile('Lean mass', S3.kg(c.lean_mass_kg), S3.unitsWt())}${tile('BMI', b.bmi == null ? '—' : b.bmi.toFixed(1), '')}${tile('Posture score', a.posture.score, '/100')}${tile('Metabolic age', c.metabolic_age == null ? '—' : c.metabolic_age, 'yrs')}</div>
      <div class="two"><div class="card"><h3>3D model</h3><div class="viewer" id="viewer"></div></div><div class="col"><div class="card"><h3>What we found</h3><ul class="checklist">${a.insights.map(t => `<li>${esc(t)}</li>`).join('')}</ul></div><div class="card flat"><h3>Key numbers</h3><div class="kv"><div>Height</div><div>${S3.height(b.height_cm)}</div><div>Weight</div><div>${S3.kg(b.weight_kg)} ${S3.unitsWt()}</div><div>Waist</div><div>${S3.cm(a.circumferences_cm.waist)} ${S3.unitsLen()}</div><div>Hips</div><div>${S3.cm(a.circumferences_cm.hips)} ${S3.unitsLen()}</div><div>Waist-to-height</div><div>${a.ratios.waist_to_height == null ? '—' : a.ratios.waist_to_height}</div><div>Resting energy (BMR)</div><div>${b.bmr_kcal || '—'} kcal</div></div></div></div></div>`;
  } else if (tab === 'measure') {
    const cm = a.circumferences_cm, hm = scan.measure.height_mm, ht = u.height_cm * 10, diff = hm ? ((hm - ht) / ht * 100) : null;
    const rows = [['Neck', 'neck', 'low'], ['Chest', 'chest'], ['Waist', 'waist'], ['Hips', 'hips'], ['Thigh (left)', 'thigh_left'], ['Thigh (right)', 'thigh_right'], ['Calf (left)', 'calf_left'], ['Calf (right)', 'calf_right']];
    body = `<div class="two"><div class="card"><h3>Circumferences</h3><table class="t"><thead><tr><th>Site</th><th class="r">Measured (${S3.unitsLen()})</th><th class="r">Your tape (${S3.unitsLen()})</th></tr></thead><tbody>${rows.map(r => `<tr><td>${r[0]} ${r[2] ? '<span class="tag low">low confidence</span>' : ''}</td><td class="r"><b>${S3.cm(cm[r[1]])}</b></td><td class="r"><input type="number" step="0.1" data-tape="${r[1]}" style="width:100px;text-align:right" value="${scan.tape && scan.tape[r[1]] ? scan.tape[r[1]] : ''}" placeholder="optional"></td></tr>`).join('')}</tbody></table><div class="row" style="margin-top:12px"><button class="btn" id="applytape">Calibrate to my tape measurements</button><span class="muted small">Enter any you measured; each site is corrected for future scans.</span></div></div>
      <div class="col"><div class="card"><h3>Scale check</h3><div class="kv"><div>Measured height</div><div>${hm ? S3.height(hm / 10) : '—'}</div><div>Your height</div><div>${S3.height(u.height_cm)}</div><div>Difference</div><div>${diff == null ? '—' : (diff > 0 ? '+' : '') + diff.toFixed(1) + '%'}</div></div>${diff != null && Math.abs(diff) > 2.5 ? '<p class="small muted">A difference this large usually means the scanner’s scale needs calibrating once.</p><button class="btn secondary" id="calscale">Calibrate scanner scale to my height</button>' : '<p class="small muted">Scale looks consistent with your entered height.</p>'}</div><div class="card flat"><h3>About these numbers</h3><p class="small muted" style="line-height:1.55;margin:0">Measurements are taken from the surface of your body <b>including clothing</b>, so loose clothes read larger. Use the same clothing each time to track change reliably, and calibrate with a tape measure for the best absolute accuracy.</p></div></div></div>`;
  } else if (tab === 'comp') {
    body = `<div class="two"><div class="card"><h3>Body composition (estimates)</h3><div class="kv"><div>Body fat</div><div>${c.body_fat_pct == null ? '—' : c.body_fat_pct + ' %'}</div><div>Fat mass</div><div>${S3.kg(c.fat_mass_kg)} ${S3.unitsWt()}</div><div>Lean mass</div><div>${S3.kg(c.lean_mass_kg)} ${S3.unitsWt()}</div><div>Metabolic age</div><div>${c.metabolic_age == null ? '—' : c.metabolic_age + ' yrs'}</div><div>Visceral fat index</div><div>${c.visceral_index == null ? '—' : c.visceral_index + ' / 20'}</div><div>Shape score</div><div>${sc == null ? '—' : sc + ' / 100'}</div><div>BMI</div><div>${b.bmi == null ? '—' : b.bmi}</div><div>BMR</div><div>${b.bmr_kcal || '—'} kcal/day</div><div>Waist-to-hip</div><div>${a.ratios.waist_to_hip == null ? '—' : a.ratios.waist_to_hip}</div><div>Waist-to-height</div><div>${a.ratios.waist_to_height == null ? '—' : a.ratios.waist_to_height}</div></div></div>
      <div class="card flat"><h3>How these are calculated</h3><p class="small" style="line-height:1.6;color:var(--ink-2)"><b>Body fat:</b> ${esc(c.body_fat_method || '—')}. Uses the U.S. Navy circumference formula (neck, waist, hips, height) and a BMI/age/sex formula (Deurenberg).<br><b>BMR:</b> Mifflin–St Jeor. <b>Metabolic age:</b> the age whose average resting energy matches yours given your lean mass. <b>Visceral index:</b> from waist-to-height ratio. <b>Shape score:</b> from waist-to-height and waist-to-hip ratios.</p><p class="disc">These are screening estimates, not medical measurements. Confidence is <b>${esc(c.confidence)}</b> until you calibrate with tape measurements. Talk to a clinician about health decisions.</p></div></div>`;
  } else {
    const p = a.posture, m = p.measures, bal = a.balance;
    const mrows = [['Head forward of feet', m.head_forward_mm, 'mm'], ['Head sideways shift', m.head_lateral_mm, 'mm'], ['Shoulders sideways shift', m.shoulder_shift_mm, 'mm'], ['Hips sideways shift', m.hip_shift_mm, 'mm'], ['Shoulder tilt', m.shoulder_tilt_deg, '°']];
    const colr = (v) => { const d = Math.abs(v - 25); return d < 4 ? '#2BA36B' : d < 9 ? '#E8A317' : '#E5484D'; };
    body = `<div class="two"><div class="card"><h3>Posture <span class="tag ${p.score >= 80 ? 'med' : 'low'}" style="margin-left:6px">${p.score}/100</span></h3>${p.flags.length ? `<div class="col gap-s">${p.flags.map(f => `<div class="flag"><div><b>${esc(f.label)}</b> · ${Math.abs(f.value)} ${esc(f.unit)}<div class="small muted">${esc(f.tip)}</div></div></div>`).join('')}</div>` : '<div class="ok">No major posture flags in this scan.</div>'}<table class="t" style="margin-top:12px"><tbody>${mrows.map(r => `<tr><td>${r[0]}</td><td class="r">${r[1] == null ? '—' : (r[1] > 0 ? '+' : '') + r[1] + ' ' + r[2]}</td></tr>`).join('')}</tbody></table><p class="disc">Positive head-forward means the head sits ahead of the feet toward the pole. Sideways values are measured toward your left. Posture is read from a single standing scan.</p></div>
      <div class="card"><h3>Weight balance</h3>${bal ? `<div class="panels">${bal.panels_pct.map((v, i) => `<div style="background:${colr(v)}">${v}%<div class="small" style="opacity:.85;font-weight:500">panel ${i + 1}</div></div>`).join('')}</div><p class="small muted" style="margin-top:12px">Total on the platform: ${S3.kg(bal.total * 0.45359237)} ${S3.unitsWt()}. An even split is 25% per panel.</p>` : '<p class="muted">No weight data for this scan.</p>'}</div></div>`;
  }
  S3.shell('history', `<div class="page-head"><div><h1>Scan results</h1><p>${S3.fmtDate(scan.created, true)} · ${scan.source === 'scanner' ? 'ProScanner' : scan.source === 'demo' ? 'Demo scan' : 'Simulated scan'}</p></div><div class="row"><button class="btn secondary" id="back">All scans</button><button class="btn danger" id="del">Delete</button></div></div><div class="tabs">${tabs.map(t => `<button data-t="${t[0]}" class="${tab === t[0] ? 'on' : ''}">${t[1]}</button>`).join('')}</div>${scan.weight_kg ? '' : `<form class="card flat row" id="wtf" style="margin-bottom:14px;gap:12px;flex-wrap:wrap"><div class="grow"><b>Add your weight</b><div class="small muted">The platform did not report a weight for this scan. Enter it to unlock BMI, body fat, lean mass and calories.</div></div><input type="number" step="0.1" name="w" placeholder="${u.units === 'imperial' ? 'lb' : 'kg'}" style="width:110px" required><button class="btn" type="submit">Save</button></form>`}${body}`);
  if ($('#wtf')) $('#wtf').onsubmit = async (e) => { e.preventDefault(); const w = parseFloat(new FormData(e.target).get('w')); try { await S3.api('scans:setWeight', id, u.units === 'imperial' ? w / 2.20462 : w); S3.toast('Weight saved — results updated.'); S3.viewResults(id, tab); } catch (err) { S3.toast(err.message); } };
  $('#back').onclick = () => S3.go('history'); $('#del').onclick = async () => { if (confirm('Delete this scan permanently?')) { await S3.api('scans:delete', id); S3.go('history'); } };
  $$('[data-t]').forEach(t => t.onclick = () => S3.viewResults(id, t.dataset.t));
  if (tab === 'overview' && view && view.length) activeViewer = new S3.Viewer($('#viewer'), new Float32Array(view));
  if ($('#applytape')) $('#applytape').onclick = async () => { const tape = {}; $$('[data-tape]').forEach(i => { const v = parseFloat(i.value); if (v > 0) tape[i.dataset.tape] = imperialToCm(v); }); if (!Object.keys(tape).length) return S3.toast('Enter at least one tape measurement.'); try { const r = await S3.api('scans:tape', id, tape); S3.state.user = await S3.api('user:update', {}); S3.toast('Calibration saved — results updated.'); S3.viewResults(id, 'measure'); } catch (e) { S3.toast(e.message); } };
  if ($('#calscale')) $('#calscale').onclick = async () => { if (!confirm('This adjusts the scanner’s scale for ALL future scans (use it once, with an accurate height). Continue?')) return; try { const r = await S3.api('scanner:calibrateScale', id); S3.toast(`Scale calibrated (×${r.factor.toFixed(3)}). Reprocessing…`); if (scan.hasRaw) { await S3.api('scans:reprocess', id); } S3.viewResults(id, 'measure'); } catch (e) { S3.toast(e.message); } };
};
const imperialToCm = (v) => (S3.state.user.units === 'imperial' ? v * 2.54 : v);

// ---------------- history & compare ----------------
S3.viewHistory = async () => {
  killViewer(); const scans = (await S3.api('scans:list')).slice().reverse(); const picked = S3.state.picked || (S3.state.picked = []); for (let i = picked.length - 1; i >= 0; i--) if (!scans.some(s => s.id === picked[i])) picked.splice(i, 1);   // never keep a selection that is not in this account
  const rows = scans.map(s => `<tr class="click" data-open="${s.id}"><td><input type="checkbox" data-pick="${s.id}" ${picked.includes(s.id) ? 'checked' : ''}></td><td>${S3.fmtDate(s.created, true)}</td><td>${s.source === 'scanner' ? 'ProScanner' : s.source === 'demo' ? 'Demo' : 'Simulated'}</td><td class="r">${S3.kg(s.weight_kg)} ${S3.unitsWt()}</td><td class="r">${fmt(s.body_fat_pct, 1)}%</td><td class="r">${S3.cm(s.waist_cm)} ${S3.unitsLen()}</td><td class="r">${s.shape_score == null ? '—' : s.shape_score}</td><td class="r">${s.posture_score == null ? '—' : s.posture_score}</td><td class="r"><button class="btn danger" data-del="${s.id}" style="padding:6px 12px">Delete</button></td></tr>`).join('');
  S3.shell('history', `<div class="page-head"><div><h1>History</h1><p>Every scan is saved to your account on this computer.</p></div><div class="row"><button class="btn secondary" id="cmp" ${picked.length === 2 ? '' : 'disabled'}>Compare selected (${picked.length}/2)</button><button class="btn" data-go="scan">New scan</button></div></div>${scans.length ? `<div class="card"><table class="t"><thead><tr><th></th><th>Date</th><th>Source</th><th class="r">Weight</th><th class="r">Body fat</th><th class="r">Waist</th><th class="r">Shape</th><th class="r">Posture</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>` : '<div class="card empty"><div class="big">No scans yet</div>Your scans will appear here.</div>'}`);
  $$('[data-go]').forEach(b => b.onclick = () => S3.go(b.dataset.go));
  $$('[data-open]').forEach(r => r.onclick = (e) => { if (e.target.closest('input,button')) return; S3.go('results', r.dataset.open); });
  $$('[data-del]').forEach(b => b.onclick = async (e) => { e.stopPropagation(); if (!confirm('Delete this scan permanently?')) return; try { await S3.api('scans:delete', b.dataset.del); const k = picked.indexOf(b.dataset.del); if (k >= 0) picked.splice(k, 1); S3.toast('Scan deleted.'); S3.viewHistory(); } catch (err) { S3.toast(err.message); } });
  $$('[data-pick]').forEach(cb => cb.onchange = () => { const id = cb.dataset.pick; if (cb.checked) { picked.push(id); if (picked.length > 2) picked.shift(); } else picked.splice(picked.indexOf(id), 1); S3.viewHistory(); });
  if ($('#cmp')) $('#cmp').onclick = () => S3.viewCompare(picked[0], picked[1]);
};
S3.viewCompare = async (ia, ib) => {
  killViewer(); let A = await S3.api('scans:get', ia), B = await S3.api('scans:get', ib); if (A.scan.created > B.scan.created) [A, B] = [B, A];
  const rows = METRICS.map(m => { const sa = summaryOf(A.scan), sb = summaryOf(B.scan); const va = metricVal(m, sa), vb = metricVal(m, sb); return `<tr><td>${m.label}</td><td class="r">${fmt(va, m.dec)} ${esc(m.unit())}</td><td class="r">${fmt(vb, m.dec)} ${esc(m.unit())}</td><td class="r">${deltaHtml(m, vb, va)}</td></tr>`; }).join('');
  S3.shell('history', `<div class="page-head"><div><h1>Compare scans</h1><p>${S3.fmtDate(A.scan.created)} → ${S3.fmtDate(B.scan.created)}</p></div><button class="btn secondary" id="back">Back</button></div><div class="two"><div class="card"><table class="t"><thead><tr><th>Metric</th><th class="r">${S3.fmtDate(A.scan.created)}</th><th class="r">${S3.fmtDate(B.scan.created)}</th><th class="r">Change</th></tr></thead><tbody>${rows}</tbody></table></div><div class="col"><div class="card"><h3>${S3.fmtDate(A.scan.created)}</h3><div class="viewer" id="va" style="height:300px"></div></div><div class="card"><h3>${S3.fmtDate(B.scan.created)}</h3><div class="viewer" id="vb" style="height:300px"></div></div></div></div>`);
  $('#back').onclick = () => S3.viewHistory();
  const v1 = new S3.Viewer($('#va'), new Float32Array(A.view || [])), v2 = new S3.Viewer($('#vb'), new Float32Array(B.view || [])); activeViewer = { destroy() { v1.destroy(); v2.destroy(); } };
};
function summaryOf(s) { const a = s.analysis; return { weight_kg: s.weight_kg, bmi: a.body.bmi, body_fat_pct: a.composition.body_fat_pct, lean_mass_kg: a.composition.lean_mass_kg, shape_score: a.composition.shape_score, posture_score: a.posture.score, waist_cm: a.circumferences_cm.waist, hips_cm: a.circumferences_cm.hips, chest_cm: a.circumferences_cm.chest, metabolic_age: a.composition.metabolic_age }; }


// ---------------- nutrition ----------------
S3.viewNutrition = async (range) => {
  killViewer(); range = range || S3.state.nutRange || 90; S3.state.nutRange = range;
  const d = await S3.api('nutrition:progress', range); const u = S3.state.user;
  if (!d.hasData) {
    S3.shell('nutrition', `<div class="page-head"><div><h1>Nutrition</h1><p>See what you ate next to how your body changed.</p></div></div><div class="card empty"><div class="big">No nutrition data yet</div><p>Connect MyFitnessPal or MyNetDiary in Profile (or import a CSV) to bring in your calories, macros and foods.</p><div class="row" style="justify-content:center"><button class="btn big" data-go="profile">Go to Profile</button></div></div>`);
    $$('[data-go]').forEach(b => b.onclick = () => S3.go(b.dataset.go)); return;
  }
  const w = d.windows.w30 || d.windows.w7 || d.windows.w90; const num = (v, dec = 0) => (v == null ? '—' : Number(v).toFixed(dec));
  const tile = (l, v, un, sub) => `<div class="tile" style="cursor:default"><div class="lbl">${l}</div><div class="val">${v}<small>${un}</small></div>${sub ? `<div class="small muted">${sub}</div>` : ''}</div>`;
  const rangeTabs = [30, 90, 180, 365].map(n => `<button data-range="${n}" class="${range === n ? 'on' : ''}">${n === 365 ? '1 year' : n + ' days'}</button>`).join('');
  const sign = (v, un, dec = 1) => (v == null ? '—' : (v > 0 ? '+' : '') + v.toFixed(dec) + ' ' + un);
  const wf = (v) => (u.units === 'imperial' ? v * 2.20462 : v); const wtGroups = (() => { const g = {}; d.weights.forEach(p => { const k = S3.SRC[p.src] ? p.src : 'import'; (g[k] = g[k] || []).push({ t: p.t, v: wf(p.v) }); }); const out = Object.keys(g).map(k => ({ name: S3.SRC[k].name, color: S3.SRC[k].color, kind: 'app', pts: g[k] })); if (d.scanWeights.length) out.unshift({ name: 'Fit3D scan', color: S3.SRC.scan.color, kind: 'scan', pts: d.scanWeights.map(p => ({ t: p.t, v: wf(p.v) })) }); return out; })();
  const wtSeries = d.weights.concat(d.scanWeights).sort((a, b) => (a.t < b.t ? -1 : 1)).map(p => ({ t: p.t, v: p.v == null ? null : (u.units === 'imperial' ? p.v * 2.20462 : p.v) }));
  const between = d.between.length ? `<div class="card" style="margin-top:16px"><h3>Between your scans</h3><p class="muted small" style="margin:0 0 8px">What you ate on average between each pair of scans, next to how you changed. The maintenance estimate needs weights from both scans and at least 60% of days logged.</p><div style="overflow:auto"><table class="t"><thead><tr><th>Period</th><th class="r">Days logged</th><th class="r">Avg intake</th><th class="r">Protein</th><th class="r">Weight</th><th class="r">Body fat</th><th class="r">Waist</th><th class="r">Est. balance</th><th class="r">Est. maintenance</th></tr></thead><tbody>${d.between.slice().reverse().map(r => `<tr><td>${S3.fmtDate(r.from + 'T12:00:00')} → ${S3.fmtDate(r.to + 'T12:00:00')} <span class="muted small">(${r.days} d)</span></td><td class="r">${r.logged}/${r.days}</td><td class="r">${r.kcal == null ? '—' : r.kcal.toLocaleString() + ' kcal'}</td><td class="r">${r.protein == null ? '—' : r.protein + ' g'}</td><td class="r">${r.dWeight == null ? '—' : (u.units === 'imperial' ? sign(r.dWeight * 2.20462, 'lb') : sign(r.dWeight, 'kg'))}</td><td class="r">${sign(r.dBodyFat, '%')}</td><td class="r">${r.dWaist == null ? '—' : (u.units === 'imperial' ? sign(r.dWaist / 2.54, 'in') : sign(r.dWaist, 'cm'))}</td><td class="r">${r.balance == null ? '—' : sign(r.balance, 'kcal/day', 0)}</td><td class="r">${r.maintenance == null ? '—' : r.maintenance.toLocaleString() + ' kcal'}</td></tr>`).join('')}</tbody></table></div></div>` : `<div class="card flat" style="margin-top:16px"><b>Between your scans</b><div class="small muted">After your second scan, this table compares what you ate with how your weight, body fat and waist changed.</div></div>`;
  const topList = (arr, key, un) => arr.map(f => `<tr><td>${esc(f.name)}</td><td class="r">${f.times}×</td><td class="r">${f[key].toLocaleString()} ${un}</td></tr>`).join('');
  const days = d.recentDays.map(r => `<details class="foodday" data-date="${r.date}"><summary><span class="grow">${S3.fmtDate(r.date + 'T12:00:00')}</span><span class="muted small">${Math.round(r.totals.kcal).toLocaleString()} kcal · P ${Math.round(r.totals.protein || 0)} · C ${Math.round(r.totals.carbs || 0)} · F ${Math.round(r.totals.fat || 0)}</span></summary><div class="foodlist small muted">${r.count ? 'Loading…' : 'No individual foods were saved for this day.'}</div></details>`).join('');
  S3.shell('nutrition', `<div class="page-head"><div><h1>Nutrition</h1><p>What you ate, next to how your body changed.</p></div><div class="tabs" style="margin:0">${rangeTabs}</div></div>
    <div class="tiles">${tile('Avg calories (30 d)', w ? w.kcal.toLocaleString() : '—', 'kcal', w ? w.n + ' logged days' : '')}${tile('Protein', w ? w.protein : '—', 'g', w && w.proteinPerKg ? S3.perWt(w.proteinPerKg) : '')}${tile('Carbs', w ? w.carbs : '—', 'g', '')}${tile('Fat', w ? w.fat : '—', 'g', '')}</div>
    <div class="two"><div class="card chart-card"><div class="row" style="margin-bottom:8px"><h3 class="grow" style="margin:0">Calories (7-day average)</h3><span class="muted small">kcal</span></div>${S3.lineChart(d.kcal7, { unit: 'kcal', dec: 0, w: S3.halfW(true), h: S3.halfH() })}</div>
    <div class="card chart-card"><div class="row" style="margin-bottom:8px"><h3 class="grow" style="margin:0">Weight</h3><span class="muted small">${u.units === 'imperial' ? 'lb' : 'kg'}</span></div>${wtSeries.length ? S3.multiChart(wtGroups, { unit: u.units === 'imperial' ? 'lb' : 'kg', dec: 1, w: S3.halfW(), h: S3.halfH(), from: Date.now() - d.range * 86400000, to: Date.now() }) + '<p class="small muted" style="margin:4px 0 0">' + wtGroups.map(g => '<span style="color:' + g.color + '">&#9679;</span> ' + esc(g.name)).join(' &nbsp; ') + '</p>' : '<div class="empty"><div class="big">No weights yet</div>Weigh-ins come from your scans and from imported weight logs.</div>'}</div></div>
    ${d.scanBodyFat.length > 1 ? `<div class="card chart-card" style="margin-top:16px"><div class="row" style="margin-bottom:8px"><h3 class="grow" style="margin:0">Body fat at each scan</h3><span class="muted small">%</span></div>${S3.lineChart(d.scanBodyFat, { unit: '%', dec: 1, color: '#10B981' })}</div>` : ''}
    ${between}
    ${S3.roiHtml ? S3.roiHtml(d.roi) : ''}
    <div class="two" style="margin-top:16px"><div class="card"><h3>Your most-eaten foods (30 days)</h3>${d.top.byFrequency.length ? `<table class="t"><thead><tr><th>Food</th><th class="r">Logged</th><th class="r">Calories</th></tr></thead><tbody>${topList(d.top.byFrequency, 'kcal', 'kcal')}</tbody></table>` : '<p class="muted small">Food-level data appears after a sync or a food-log import.</p>'}</div>
    <div class="card"><h3>Biggest protein sources (30 days)</h3>${d.top.byProtein.length ? `<table class="t"><thead><tr><th>Food</th><th class="r">Logged</th><th class="r">Protein</th></tr></thead><tbody>${topList(d.top.byProtein, 'protein', 'g')}</tbody></table>` : '<p class="muted small">Food-level data appears after a sync or a food-log import.</p>'}</div></div>
    <div class="card" style="margin-top:16px"><h3>Recent days</h3><p class="muted small" style="margin:0 0 6px">Tap a day to see what you ate.</p>${days}</div>`);
  $$('[data-range]').forEach(b => b.onclick = () => S3.viewNutrition(+b.dataset.range));
  $$('.foodday').forEach(el => el.addEventListener('toggle', async () => {
    if (!el.open || el.dataset.loaded) return; el.dataset.loaded = '1'; const date = el.dataset.date; const box = el.querySelector('.foodlist');
    try { const f = await S3.api('nutrition:foods', date, date); const items = f[date] || []; if (!items.length) return; let meal = '';
      box.innerHTML = '<table class="t">' + items.map(it => { const hd = it.meal !== meal ? `<tr><td colspan="5" style="padding-top:10px"><b>${esc(it.meal || 'Meal')}</b></td></tr>` : ''; meal = it.meal; return hd + `<tr><td>${esc(it.name)}</td><td class="r">${Math.round(it.kcal)} kcal</td><td class="r">P ${Math.round(it.protein || 0)}</td><td class="r">C ${Math.round(it.carbs || 0)}</td><td class="r">F ${Math.round(it.fat || 0)}</td></tr>`; }).join('') + '</table>';
    } catch (e) { box.textContent = e.message; }
  }));
};

// ---------------- profile ----------------
S3.viewProfile = async () => {
  killViewer(); const u = S3.state.user, info = await S3.api('app:info'), sc = info.scanner; const hcm = u.units === 'imperial' ? (u.height_cm / 2.54).toFixed(1) : u.height_cm;
  S3.shell('profile', `<div class="page-head"><div><h1>Profile</h1><p>Your details are used for body-composition calculations.</p></div></div>
  <div class="pcols"><div class="pcol">  <form class="card col" id="pf"><h3>Your details</h3><div class="grid2"><label class="f">Full name<input type="text" name="name" autocapitalize="words" value="${esc(u.name)}"></label><label class="f">Email<input type="email" name="email" value="${esc(u.email)}"></label></div><div class="grid2"><label class="f">Sex<select name="sex"><option value="male" ${u.sex === 'male' ? 'selected' : ''}>Male</option><option value="female" ${u.sex === 'female' ? 'selected' : ''}>Female</option></select></label><label class="f">Date of birth<input type="date" name="dob" value="${esc(u.dob)}"></label></div><div class="grid2"><label class="f">Height (${u.units === 'imperial' ? 'in' : 'cm'})<input type="number" step="0.1" name="height" value="${hcm}"></label><label class="f">Units<select name="units"><option value="metric" ${u.units === 'metric' ? 'selected' : ''}>Metric (cm, kg)</option><option value="imperial" ${u.units === 'imperial' ? 'selected' : ''}>Imperial (in, lb)</option></select></label></div><label class="f">Current weight (${u.units === 'imperial' ? 'lb' : 'kg'}), used when the platform does not report one<input type="number" step="0.1" name="weight" value="${u.weight_kg ? (u.units === 'imperial' ? (u.weight_kg * 2.20462).toFixed(1) : u.weight_kg) : ''}"></label><label class="f">Goal<input type="text" name="goal" value="${esc(u.goal)}"></label><div class="row"><button class="btn" type="submit">Save changes</button><span id="pmsg" class="muted small"></span></div></form>
  <div class="card col" id="calibcard"></div>
  <div class="card col"><h3>Preferences</h3><label class="row"><input type="checkbox" id="mute" ${u.muted ? 'checked' : ''}> <span>Mute scan sounds</span></label><div class="row" style="gap:10px"><span>Units</span><div class="seg" id="unitseg"><button type="button" data-u="imperial" class="${u.units === 'imperial' ? 'on' : ''}">Imperial (lb, in)</button><button type="button" data-u="metric" class="${u.units !== 'imperial' ? 'on' : ''}">Metric (kg, cm)</button></div></div><label class="row"><input type="checkbox" id="skiptut" ${u.skipTutorial ? 'checked' : ''}> <span>Skip the step-by-step tutorial before scans</span></label></div>
  <form class="card col" id="pw"><h3>Change PIN</h3><div class="f"><span>New PIN (4 to 8 digits)</span>${S3.pinPad('pw')}</div><div class="row"><button class="btn secondary" type="submit">Update PIN</button><span id="pwmsg" class="muted small"></span></div></form>
  <div class="card col"><h3>Delete account</h3><p class="muted small" style="margin:0">Permanently deletes your profile, all your scans (including raw frames) and imported nutrition data from this computer. This cannot be undone.</p><form id="delf" class="col" style="align-items:center">${S3.pinPad('pin')}<button class="btn danger" type="submit">Delete my account</button></form><span id="delmsg" class="small" style="color:#E5484D"></span></div></div><div class="pcol">  <div class="card col" id="nutprof"><h3>Nutrition apps</h3>
    <div class="col" style="gap:8px;padding:12px;border-radius:14px;background:#FFF7EF"><div class="row"><div class="grow"><b>MyFitnessPal</b><div id="mfpinfo" class="small muted">Checking…</div></div><button class="btn" id="mfpconnect">Connect</button><button class="btn secondary" id="mfpsync" style="display:none">Sync now</button><button class="btn ghost" id="mfpoff" style="display:none">Disconnect</button></div><div class="bar" id="mfpbar" style="display:none"><b style="width:0%"></b></div><div class="small muted">A Microsoft Edge window opens so you can sign in to MyFitnessPal the normal way (Google sign-in and 2-step login work too). Your password is never seen or saved by S*it3D, and your food diary then syncs automatically each time you sign in. This is an unofficial connection (MyFitnessPal has no public API for individuals), so it may need re-connecting if MyFitnessPal changes its site.</div></div>
    <div class="col" style="gap:8px;padding:12px;border-radius:14px;background:#FFF7EF"><div class="row"><div class="grow"><b>MyNetDiary</b><div id="mndinfo" class="small muted">Checking…</div></div><button class="btn" id="mndconnect">Connect</button><button class="btn secondary" id="mndsync" style="display:none">Sync now</button><button class="btn ghost" id="mndoff" style="display:none">Disconnect</button></div><div class="bar" id="mndbar" style="display:none"><b style="width:0%"></b></div><div class="small muted">A Microsoft Edge window opens so you can sign in to MyNetDiary the normal way (Google sign-in and 2-step login work too). Your password is never seen or saved by S*it3D, and your food diary then syncs automatically each time you sign in. Also unofficial, so it may need re-connecting if MyNetDiary changes its site.</div></div>
    <div class="col" style="gap:4px;padding:12px;border-radius:14px;background:#FFF7EF"><b>Cronometer</b><div class="small muted">Cronometer has no public API and no safe sign-in method for apps, so live sync is not available. Use the CSV import below (Cronometer, then More, Account, Export Data).</div></div>
    <div id="nutinfo" class="small"></div><div class="row"><button class="btn secondary" id="nutimp">Import CSV files…</button><button class="btn ghost" id="nutclr" style="display:none">Remove nutrition data</button></div><details class="small"><summary>How to export a CSV</summary><ul class="checklist"><li><b>MyFitnessPal:</b> Settings, Diary Settings, Export Data (Premium). Unzip, then import <i>Nutrition-Summary</i> and <i>Measurement-Summary</i> (weight).</li><li><b>Cronometer:</b> More, Account, Export Data, Daily Nutrition.</li><li><b>Lose It!:</b> Settings, Export Data (website).</li></ul></details></div>
  <div class="card col" id="aiprof"><h3>AI coach</h3><p class="muted small" style="margin:0">Gives suggestions on your scans, nutrition and food choices, and can talk with you. It uses Google Gemini with <b>your own free key</b> (create one at aistudio.google.com).</p><div id="aiinfo" class="small"></div>
    <form id="aif" class="col" style="gap:8px"><input type="password" name="key" placeholder="Paste your Google AI key" autocomplete="off" autocapitalize="none" spellcheck="false"><label class="row small" style="gap:8px;align-items:flex-start"><input type="checkbox" name="consent" style="margin-top:3px"><span>I understand that only an <b>anonymous summary</b> (age range, sex, height, scan results, nutrition totals and food names, no name, email or birthday) is sent to Google, and that on the free tier Google may use it to improve its products. The coach is not medical advice.</span></label><div class="row"><button class="btn" type="submit">Save key</button><button class="btn ghost" type="button" id="aioff" style="display:none">Remove key</button><span id="aimsg" class="small muted"></span></div></form>
    <label class="f" id="aivoicewrap" style="display:none">Coach voice<select id="aivoice"></select></label></div>
  <div class="card col" id="updcard"><h3>App updates</h3><div id="updinfo" class="small muted">Checking…</div><div class="row"><button class="btn" id="updcheck">Update now</button><button class="btn ghost" id="updrestart" style="display:none">Restart without checking</button></div></div>
  <div class="card col"><h3>Scanner</h3><div class="kv"><div>Scale factor</div><div>${sc.fxScale}</div><div>Sensor service folder</div><div class="small">${esc(sc.serviceDir)}</div><div>Data folder</div><div class="small">${esc(info.dataDir)}</div></div><label class="row"><input type="checkbox" id="raw" ${sc.keepRaw ? 'checked' : ''}> <span>Keep raw depth frames (lets scans be re-processed later; ~25 MB each)</span></label></div></div></div>`);
  $('#pf').onsubmit = async (e) => { e.preventDefault(); const f = new FormData(e.target), imp = f.get('units') === 'imperial', h = parseFloat(f.get('height')); try { S3.state.user = await S3.api('user:update', { name: f.get('name'), email: f.get('email'), weight_kg: f.get('weight') ? Math.round(parseFloat(f.get('weight')) / (imp ? 2.20462 : 1) * 10) / 10 : null, sex: f.get('sex'), dob: f.get('dob'), units: f.get('units'), goal: f.get('goal'), height_cm: imp ? h * 2.54 : h }); $('#pmsg').textContent = 'Saved.'; S3.viewProfile(); } catch (err) { $('#pmsg').textContent = err.message; } };
  $('#pw').onsubmit = async (e) => { e.preventDefault(); try { await S3.api('user:update', { newPassword: new FormData(e.target).get('pw') }); $('#pwmsg').textContent = 'PIN updated.'; e.target.reset(); S3.pinReset(e.target); } catch (err) { $('#pwmsg').textContent = err.message; } };
  $('#mute').onchange = async (e) => { S3.state.user = await S3.api('user:update', { muted: e.target.checked }); }; Array.from(document.querySelectorAll('#unitseg button')).forEach(b => b.onclick = async () => { try { S3.state.user = await S3.api('user:update', { units: b.dataset.u }); S3.toast('Units changed to ' + (b.dataset.u === 'imperial' ? 'pounds and inches' : 'kilograms and centimetres') + '.'); S3.go('profile'); } catch (e) { S3.toast(e.message); } });
  $('#skiptut').onchange = async (e) => { S3.state.user = await S3.api('user:update', { skipTutorial: e.target.checked }); };
  $('#raw').onchange = async (e) => { await S3.api('scanner:config', { keepRaw: e.target.checked }); };
  const updShow = (st) => { const el = $('#updinfo'); if (!el) return; const a = st.available; el.innerHTML = `Version <b>${esc(st.current || '')}</b>. ` + (!st.enabled ? 'Automatic updates are not set up on this computer yet.' : a ? `Version <b>${esc(a.version)}</b> is downloaded and ready.${a.notes ? ' ' + esc(a.notes) : ''}` : st.error ? `Last check failed: ${esc(st.error)}` : st.lastCheck ? 'You are up to date.' : 'Updates are checked each time the app starts.'); $('#updrestart').style.display = a ? '' : 'none'; $('#updcheck').style.display = st.enabled ? '' : 'none'; };
  S3.api('update:status').then(updShow).catch(() => {});
  $('#updcheck').onclick = async () => { const b = $('#updcheck'); b.disabled = true; $('#updinfo').textContent = 'Checking for updates…'; try { const st = await S3.api('update:check'); updShow(st); if (st.available) { $('#updinfo').textContent = 'Version ' + st.available.version + ' downloaded. Restarting…'; setTimeout(() => S3.api('update:restart').catch((e) => { S3.toast(e.message); b.disabled = false; }), 900); return; } } catch (e) { $('#updinfo').textContent = e.message; } b.disabled = false; };
  $('#updrestart').onclick = async () => { try { await S3.api('update:restart'); } catch (e) { S3.toast(e.message); } };
  const nutRefresh = async () => { const n = await S3.api('nutrition:get'); const el = $('#nutinfo'); if (!el) return; const sm = n.summary; el.innerHTML = sm ? `Imported <b>${sm.daysLogged}</b> days of food logs (${esc(sm.first)} to ${esc(sm.last)})${n.weightLogs ? ` and <b>${n.weightLogs}</b> weigh-ins` : ''}.` : (n.weightLogs ? `Imported <b>${n.weightLogs}</b> weigh-ins.` : 'Nothing imported yet.'); $('#nutclr').style.display = (sm || n.weightLogs) ? '' : 'none'; };
  nutRefresh(); if (S3.calibSummaryCard) S3.calibSummaryCard();
  const bindSync = (k, name) => {
    const el = (x) => $('#' + k + x);
    const show = (st) => { const info = el('info'); if (!info) return; const on = !!st.connected; info.textContent = st.running ? 'Syncing…' : on ? ('Connected' + (st.lastSync ? ' · last sync ' + S3.fmtDate(st.lastSync, true) : '') + (st.weightCount ? ' · ' + st.weightCount + ' weigh-ins' : ' · no weigh-ins found yet') + (st.error ? ' · ' + st.error : '')) : (st.error || 'Not connected'); el('connect').style.display = on ? 'none' : ''; el('sync').style.display = on ? '' : 'none'; el('off').style.display = on ? '' : 'none'; el('sync').disabled = !!st.running; };
    const refresh = async () => { try { show(await S3.api('sync:status', k)); await nutRefresh(); } catch (e) { /* ignore */ } };
    refresh();
    S3.progressHandlers = S3.progressHandlers || {}; S3.progressHandlers[k] = (p) => { const bar = el('bar'); if (!bar) return; bar.style.display = p.running ? '' : 'none'; if (bar.firstChild) bar.firstChild.style.width = Math.round((p.p || 0) * 100) + '%'; if (!p.running) refresh(); else el('info').textContent = 'Syncing ' + (p.day || '') + '…'; };
    el('connect').onclick = async () => { el('connect').disabled = true; el('info').textContent = 'Waiting for you to log in…'; try { const r = await S3.api('sync:connect', k); S3.toast(r.connected ? name + ' connected. First sync is running.' : 'Login window closed.'); } catch (e) { S3.toast(e.message); } el('connect').disabled = false; refresh(); };
    el('sync').onclick = async () => { try { await S3.api('sync:run', k); S3.toast('Synced.'); } catch (e) { S3.toast(e.message); } refresh(); };
    el('off').onclick = async () => { if (!confirm('Disconnect ' + name + '? Already-synced days stay in your dashboard.')) return; await S3.api('sync:disconnect', k); refresh(); };
  };
  const aiShow = async () => { try { const a = await S3.api('ai:status'); $('#aiinfo').textContent = a.enabled ? 'Coach is on. Open it with the Coach button at the bottom right.' : 'Coach is off.'; $('#aioff').style.display = a.enabled ? '' : 'none'; $('#aivoicewrap').style.display = a.enabled ? '' : 'none'; $('#aivoice').innerHTML = (a.voices || []).map(v => `<option ${v === a.voice ? 'selected' : ''}>${v}</option>`).join(''); } catch (e) { /* ignore */ } };
  aiShow();
  $('#aif').onsubmit = async (e) => { e.preventDefault(); const f = new FormData(e.target); try { await S3.api('ai:setKey', f.get('key'), !!f.get('consent')); e.target.reset(); $('#aimsg').textContent = 'Saved.'; S3.coachRefresh && S3.coachRefresh(); } catch (err) { $('#aimsg').textContent = err.message; } aiShow(); };
  $('#aioff').onclick = async () => { if (!confirm('Remove your AI key from this computer?')) return; await S3.api('ai:clear'); $('#aimsg').textContent = ''; S3.coachRefresh && S3.coachRefresh(); aiShow(); };
  $('#aivoice').onchange = async (e) => { try { await S3.api('ai:setVoice', e.target.value); } catch (err) { S3.toast(err.message); } };
  bindSync('mfp', 'MyFitnessPal'); bindSync('mnd', 'MyNetDiary');
  $('#nutimp').onclick = async () => { try { const r = await S3.api('nutrition:import'); if (r.canceled) return; const bad = r.results.filter(x => !x.ok); S3.toast(bad.length ? bad.map(x => x.file + ': ' + x.error).join(' | ') : 'Imported ' + r.results.length + ' file' + (r.results.length > 1 ? 's' : '') + '.'); await nutRefresh(); } catch (e) { S3.toast(e.message); } };
  $('#nutclr').onclick = async () => { if (!confirm('Remove all imported nutrition and weight data?')) return; await S3.api('nutrition:clear'); await nutRefresh(); };
  $('#delf').onsubmit = async (e) => { e.preventDefault(); if (!confirm('Delete your account and ALL of your scans permanently?')) return; try { await S3.api('auth:deleteAccount', new FormData(e.target).get('pin')); S3.state.user = null; S3.state.authUsers = null; S3.state.info = await S3.api('app:info'); S3.viewAuth('login'); } catch (err) { $('#delmsg').textContent = err.message; } };
};

})();
