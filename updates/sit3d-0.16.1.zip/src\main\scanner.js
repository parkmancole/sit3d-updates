'use strict';
// Scanner controller: turntable (USB HID, node-hid) + depth capture (32-bit PowerShell child, Capture-Depth.ps1). Emits 'phase' events.
// Phases: starting -> sensors -> board -> homing? -> armed -> countdown -> scanning -> finishing -> saving -> done | error
const { EventEmitter } = require('events');
const fs = require('fs'), path = require('path'), cp = require('child_process');

let HID = null; try { HID = require('node-hid'); } catch (e) { HID = null; }
const VID = 5824, PID = 1158, UPAGE = 65451, USAGE = 512;
const ALLOWED = new Set(['tt_statusReady', 'tt_calib', 'tt_cameraReady', 'tt_resetCameraReady']);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

class Scanner extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.opts = Object.assign({ serviceDir: 'C:\\Apps\\ProScanner\\Service', postrollMs: 3000, simulate: false }, opts);
    this.dev = null; this.capture = null; this.cancelled = false; this.busy = false;
  }
  phase(phase, extra = {}) { this.emit('phase', Object.assign({ phase, t: Date.now() }, extra)); }
  hardwareAvailable() {
    if (!HID) return { ok: false, why: 'USB library not available' };
    try { const d = HID.devices().find(x => x.vendorId === VID && x.productId === PID && x.usagePage === UPAGE && x.usage === USAGE); return d ? { ok: true, path: d.path } : { ok: false, why: 'Turntable not found (is the scanner plugged in and powered?)' }; }
    catch (e) { return { ok: false, why: String(e.message || e) }; }
  }
  openBoard() {
    const a = this.hardwareAvailable(); if (!a.ok) throw new Error(a.why);
    this.dev = new HID.HID(a.path); this.dev.on('data', (buf) => this._rx(buf)); this.dev.on('error', (e) => this.phase('log', { message: 'USB error: ' + e }));
  }
  closeBoard() { try { if (this.dev) this.dev.close(); } catch (e) { /* ignore */ } this.dev = null; }
  send(cmd) {
    if (!ALLOWED.has(cmd)) throw new Error('command not allowed: ' + cmd);
    const a = [0]; for (const c of cmd) a.push(c.charCodeAt(0)); while (a.length < 64) a.push(0);
    this.dev.write(a);
  }
  _rx(buf) {
    let s = ''; for (const b of buf) if (b > 39 && b < 127) s += String.fromCharCode(b);
    this.emit('rx', s); if (this._onRx) this._onRx(s);
    if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) this.emit('live', v); }   // also while armed / scanning
  }
  // Passive scale monitor for the scan screen: opens the board, sends only the harmless tt_statusReady, and forwards every weight= message the board reports.
  // (The firmware decides when it reports weight; if it stays silent while idle the screen simply shows no reading.)
  monitor(onLive) {
    if (this.opts.simulate || this.busy) return () => {};
    this.openBoard(); let n = 0; const t0 = Date.now();
    this._onRx = (s) => { if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) { n++; onLive(v); } } };
    const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 3000);
    return () => { clearInterval(poll); this._onRx = null; this.closeBoard(); return { seen: n, seconds: Math.round((Date.now() - t0) / 1000) }; };
  }
  cancel() { this.cancelled = true; if (this._abort) this._abort(new Error('Scan cancelled.')); }

  async rehome() {
    if (this.opts.simulate) { this.phase('homing', { message: 'Re-homing the turntable (simulated).' }); await sleep(2500); this.phase('idle'); return; }
    this.openBoard();
    try {
      this.phase('homing', { message: 'The platform is turning back to its start position. Stay clear of it.' });
      await new Promise((resolve, reject) => {
        const to = setTimeout(() => reject(new Error('Homing timed out.')), 80000); let sent = false;
        this._onRx = (s) => { if (s.startsWith('tt_statusReady:true')) { clearTimeout(to); resolve(); } else if (s.startsWith('tt_statusReady:false') && !sent) { sent = true; this.send('tt_calib'); } };
        const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 2000); this._abort = reject;
        this.once('__stop', () => clearInterval(poll)); to.unref && 0; setTimeout(() => clearInterval(poll), 80000);
      });
      this.phase('idle');
    } finally { this._onRx = null; this.closeBoard(); }
  }

  /** Run one scan. Resolves {workDir, scanDir, scanDurationS, startOffsetS, loads} */
  async runScan(workDir) {
    if (this.busy) throw new Error('A scan is already running.'); this.busy = true; this.cancelled = false;
    try { return this.opts.simulate ? await this._simulate(workDir) : await this._real(workDir); }
    finally { this.busy = false; this.closeBoard(); this._onRx = null; this._abort = null; }
  }

  async _simulate(workDir) {
    const wait = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(100); } };
    this.phase('starting', { message: 'Checking the scanner (simulation)…' }); await wait(800);
    this.phase('sensors', { message: 'Depth sensors ready.' }); await wait(1200);
    this.phase('board', { message: 'Turntable ready.' }); await wait(800);
    this.phase('armed', { message: 'Simulation: the scan starts automatically in 12 seconds. With the real scanner, it waits until you hold both buttons.' });
    for (let i = 0; i < 24; i++) { const t = 158.1 + Math.sin(i) * 0.15; this.emit('live', [31.3, 34.6, 45.2, 47.1, t, 0.09]); await wait(500); }
    for (let n = 4; n >= 1; n--) { this.phase('countdown', { n, message: 'Hold still…' }); await wait(1000); }
    this.phase('scanning', { startedAt: Date.now(), expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' });
    const t0 = Date.now(); while (Date.now() - t0 < 38000) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(250); }
    this.phase('finishing', { message: 'Scan complete. You can let go and step off.' }); await wait(2500);
    this.phase('saving', { message: 'Saving frames…' }); await wait(1200);
    return { simulated: true, workDir, loads: [31.3, 34.6, 45.2, 47.1, 158.1, 0.091], scanDurationS: 37.9 };
  }

  async _real(workDir) {
    fs.mkdirSync(workDir, { recursive: true });
    const sig = path.join(workDir, '_signals'); fs.mkdirSync(sig, { recursive: true });
    for (const f of ['START', 'STOP']) { try { fs.unlinkSync(path.join(sig, f)); } catch (e) { /* none */ } }
    const capPs1 = this.opts.capturePs1, ps32 = path.join(process.env.SystemRoot || 'C:\\Windows', 'SysWOW64', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const name = 'scan', capLog = path.join(workDir, `capture_${name}.log`), pkg = path.join(workDir, `pkg-${name}-raw`);
    this.phase('starting', { message: 'Checking the scanner…' });
    this.openBoard();
    // capture process
    this.capture = cp.spawn(ps32, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', capPs1, '-Mode', 'Signal', '-ServiceDir', this.opts.serviceDir, '-OutDir', workDir, '-Name', name], { windowsHide: true });
    let capExit = null; const capDone = new Promise(res => this.capture.on('exit', (c) => { capExit = c; res(c); }));
    const abortP = new Promise((_, rej) => { this._abort = rej; });
    const guard = (p) => Promise.race([p, abortP]);
    const t0 = Date.now(); let ready = false;
    while (Date.now() - t0 < 45000 && !ready) {
      if (capExit !== null) throw new Error('The depth sensors could not be started. Check that all three sensors are plugged in.');
      try { ready = fs.readFileSync(capLog, 'utf8').includes('READY: streaming'); } catch (e) { /* not yet */ }
      if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(300);
    }
    if (!ready) throw new Error('The depth sensors did not become ready in time.');
    this.phase('sensors', { message: 'Depth sensors ready.' });

    const rxLog = []; const ev = { scanStart: null, scanComplete: null }; let loads = null, armed = false, homingSent = false, earlyStop = false;
    const waitFor = (pred, ms, what) => new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error(what)), ms); const prev = this._onRx;
      this._onRx = (s) => { if (prev) prev(s); const v = pred(s); if (v) { clearTimeout(to); this._onRx = prev; resolve(v); } };
    });
    const writeSignal = (n) => fs.writeFileSync(path.join(sig, n), new Date().toISOString());
    // state machine on board messages
    const done = new Promise((resolve, reject) => {
      this._onRx = (s) => {
        if (rxLog.length < 300) rxLog.push(s.slice(0, 80));
        if (s.startsWith('tt_statusReady:true') && !armed) { armed = true; this.phase('board', { message: 'Turntable ready.' }); this.send('tt_cameraReady'); this.phase('armed', { message: 'Step onto the platform, stand on the footprints facing the pole, and hold both handle buttons.' }); }
        else if (s.startsWith('tt_statusReady:false') && !armed && !homingSent) { homingSent = true; this.phase('homing', { message: 'The platform is turning to its start position. Please stay OFF the platform until it stops.' }); this.send('tt_calib'); }
        else if (s === 'tt_prepScanStart') this.phase('countdown', { n: 4, message: 'Hold still…' });
        else if (s === 'tt_noScanStart') { this.phase('armed', { message: 'Hold BOTH buttons to begin.' }); }
        else if (s === 'tt_scanStart') { ev.scanStart = Date.now(); writeSignal('START'); this.phase('scanning', { startedAt: ev.scanStart, expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' }); }
        else if (s === 'tt_scanComplete') { ev.scanComplete = Date.now(); this.phase('finishing', { message: 'Scan complete. Keep holding until the platform stops, then step off.' }); setTimeout(() => writeSignal('STOP'), this.opts.postrollMs); setTimeout(() => resolve(), 9500); }
        else if (s === 'tt_scanEarlyStop') { earlyStop = true; writeSignal('STOP'); setTimeout(() => reject(new Error('You let go of a button before the scan finished. Please try again and hold both buttons until the platform stops.')), 800); }
        else if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter(x => !isNaN(x)); if (v.length >= 5) loads = v; }
      };
    });
    this.send('tt_statusReady');
    const poll = setInterval(() => { try { if (!armed) this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 2000);
    const armTimeout = setTimeout(() => { if (!ev.scanStart && !this.cancelled) this._abort(new Error('No scan was started within 3 minutes.')); }, 180000);
    try { await guard(done); } finally { clearInterval(poll); clearTimeout(armTimeout); }
    try { this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ }
    this.phase('saving', { message: 'Saving frames…' });
    await guard(Promise.race([capDone, sleep(150000).then(() => { throw new Error('Saving the depth frames took too long.'); })]));
    if (capExit !== 0 && !fs.existsSync(path.join(pkg, 'capture_meta.json'))) throw new Error('The depth capture failed.');
    // the board reports the load-cell weight a few seconds after the scan; keep listening a little longer if it has not arrived yet
    for (let i = 0; i < 30 && !loads; i++) await sleep(200);
    const meta = JSON.parse(fs.readFileSync(path.join(pkg, 'capture_meta.json'), 'utf8'));
    return { workDir, scanDir: pkg, scanDurationS: (ev.scanComplete - ev.scanStart) / 1000, startOffsetS: (Date.parse(meta.start_utc) - ev.scanStart) / 1000, loads, earlyStop, rx: rxLog.filter(x => !x.startsWith('tare=') && !x.startsWith('tt_statusReady')) };
  }
  killCapture() { try { if (this.capture) this.capture.kill(); } catch (e) { /* ignore */ } }
}
module.exports = { Scanner };
