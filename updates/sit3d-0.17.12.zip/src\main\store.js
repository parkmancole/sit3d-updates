'use strict';
// Local storage for S*it3D: accounts (scrypt-hashed passwords) and per-user scans. No network, no admin rights.
const fs = require('fs'), path = require('path'), crypto = require('crypto');

let ROOT = null;
function rmrf(p) { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } }

function init(rootDir) { ROOT = rootDir; fs.mkdirSync(path.join(ROOT, 'users'), { recursive: true }); return ROOT; }
const usersFile = () => path.join(ROOT, 'users.json');
const userDir = (id) => path.join(ROOT, 'users', id);
const scansDir = (id) => path.join(userDir(id), 'scans');

function readJson(f, dflt) { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return dflt; } }
function writeJson(f, v) { const tmp = f + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(v)); fs.renameSync(tmp, f); }

const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64, { N: 16384, r: 8, p: 1 });
const norm = (s) => String(s || '').trim().toLowerCase();

function loadUsers() { return readJson(usersFile(), { users: [] }).users; }
function saveUsers(users) { writeJson(usersFile(), { users }); }
const publicUser = (u) => { if (!u) return null; const { pw, ...rest } = u; return rest; };

function ageFromDob(dob) { const d = new Date(dob); if (isNaN(d)) return null; const n = new Date(); let a = n.getFullYear() - d.getFullYear(); const m = n.getMonth() - d.getMonth(); if (m < 0 || (m === 0 && n.getDate() < d.getDate())) a--; return a; }

function signup(f) {
  const users = loadUsers();
  let username = norm(f.username || '');
  if (!username) { const base = String(f.name || '').toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 18) || 'user'; username = base; for (let i = 2; users.some(u => u.username === username); i++) username = base + i; }   // auto-generated; people sign in by tapping their name
  if (!/^[a-z0-9_.-]{3,24}$/.test(username)) throw new Error('Username must be 3-24 characters (letters, numbers, . _ -).');
  if (!/^\d{4,8}$/.test(String(f.password || ''))) throw new Error('PIN must be 4 to 8 digits (numbers only).');
  if (!f.name || !String(f.name).trim()) throw new Error('Please enter your name.');
  if (!['male', 'female'].includes(f.sex)) throw new Error('Please choose male or female (used by the body-composition formulas).');
  const age = ageFromDob(f.dob); if (age == null || age < 13 || age > 110) throw new Error('Please enter a valid date of birth (age 13 or older).');
  const h = Number(f.height_cm); if (!(h >= 100 && h <= 230)) throw new Error('Height must be between 100 and 230 cm.');
  if (users.some(u => u.username === username)) throw new Error('That username is already taken.');
  const salt = crypto.randomBytes(16);
  const u = {
    id: 'u_' + crypto.randomBytes(6).toString('hex'), username, name: String(f.name).trim(), email: String(f.email || '').trim(),
    sex: f.sex, dob: f.dob, height_cm: Math.round(h * 10) / 10, units: f.units === 'imperial' ? 'imperial' : 'metric',
    goal: String(f.goal || '').trim(), created: new Date().toISOString(), calib: {}, pw: { salt: salt.toString('hex'), hash: hashPw(f.password, salt).toString('hex') },
  };
  users.push(u); saveUsers(users); fs.mkdirSync(scansDir(u.id), { recursive: true });
  return publicUser(u);
}
function listUsers() { return loadUsers().map(u => ({ id: u.id, name: u.name })); }
function login(username, password) {
  const users = loadUsers(); const u = users.find(x => x.id === username || x.username === norm(username));
  const salt = u ? Buffer.from(u.pw.salt, 'hex') : crypto.randomBytes(16);   // constant-ish time for unknown users
  const h = hashPw(String(password || ''), salt);
  if (!u || !crypto.timingSafeEqual(h, Buffer.from(u.pw.hash, 'hex'))) throw new Error('Wrong username or PIN.');
  return publicUser(u);
}
function getUser(id) { return publicUser(loadUsers().find(u => u.id === id)); }
function updateUser(id, patch) {
  const users = loadUsers(); const u = users.find(x => x.id === id); if (!u) throw new Error('No such user.');
  for (const k of ['name', 'email', 'sex', 'dob', 'height_cm', 'units', 'goal', 'muted', 'skipTutorial', 'weight_kg']) if (patch[k] !== undefined) u[k] = patch[k];
  if (patch.calib) u.calib = patch.calib;
  if (patch.calibSamples) u.calibSamples = patch.calibSamples;
  if (patch.newPassword) { if (!/^\d{4,8}$/.test(String(patch.newPassword))) throw new Error('PIN must be 4 to 8 digits (numbers only).'); const salt = crypto.randomBytes(16); u.pw = { salt: salt.toString('hex'), hash: hashPw(patch.newPassword, salt).toString('hex') }; }
  saveUsers(users); return publicUser(u);
}
function userCount() { return loadUsers().length; }

// ---- scans ----
function newScanId() { const d = new Date(); const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`; }
function scanPath(userId, scanId) { return path.join(scansDir(userId), scanId); }
function saveScan(userId, scan, viewPts) {
  const dir = scanPath(userId, scan.id); fs.mkdirSync(dir, { recursive: true });
  writeJson(path.join(dir, 'scan.json'), scan);
  if (viewPts) fs.writeFileSync(path.join(dir, 'view.bin'), Buffer.from(viewPts.buffer, viewPts.byteOffset, viewPts.byteLength));
  return dir;
}
function listScans(userId) {
  const dir = scansDir(userId); if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).map(id => readJson(path.join(dir, id, 'scan.json'), null)).filter(Boolean).sort((a, b) => a.created.localeCompare(b.created));
}
function getScan(userId, scanId) {
  const dir = scanPath(userId, scanId), scan = readJson(path.join(dir, 'scan.json'), null); if (!scan) return null;
  let view = null; try { const b = fs.readFileSync(path.join(dir, 'view.bin')); view = Array.from(new Int16Array(b.buffer, b.byteOffset, b.length / 2)); } catch (e) { /* none */ }
  return { scan, view };
}
function deleteScan(userId, scanId) { rmrf(scanPath(userId, scanId)); }
function updateScan(userId, scanId, patch) { const f = path.join(scanPath(userId, scanId), 'scan.json'); const s = readJson(f, null); if (!s) throw new Error('No such scan.'); Object.assign(s, patch); writeJson(f, s); return s; }


// ---- nutrition (imported from CSV exports) + account deletion ----
const nutFile = (id) => path.join(userDir(id), 'nutrition.json');
function mergeWeights(id, weights, src) { const n = getNutrition(id); n.weightSrc = n.weightSrc || {}; let c = 0; for (const d of Object.keys(weights || {})) { n.weights[d] = weights[d]; n.weightSrc[d] = src; c++; } writeJson(nutFile(id), n); return c; }
// Anything implausible (a typo'd 99,999 kcal day, a 9,999 kg weigh-in, text where a number belongs) is ignored on read so it can never wreck averages and charts.
function cleanNutrition(n) {
  const num = (v) => typeof v === 'number' && isFinite(v);
  for (const d of Object.keys(n.days || {})) { const x = n.days[d]; if (!x || !num(x.kcal) || x.kcal < 0 || x.kcal > 8000) { delete n.days[d]; continue; } for (const k of ['protein', 'carbs', 'fat', 'fiber', 'sodium', 'sugar']) if (x[k] != null && (!num(x[k]) || x[k] < 0 || x[k] > (k === 'sodium' ? 30000 : 1500))) x[k] = 0; }
  for (const d of Object.keys(n.weights || {})) { const v = n.weights[d]; if (!num(v) || v < 25 || v > 320) { delete n.weights[d]; if (n.weightSrc) delete n.weightSrc[d]; } }
  return n;
}
function getNutrition(id) { return cleanNutrition(readJson(nutFile(id), { days: {}, weights: {}, imports: [] })); }
function mergeNutrition(id, parsed, name) {
  const n = getNutrition(id); Object.assign(n.days, parsed.days || {}); Object.assign(n.weights, parsed.weights || {});
  n.imports.push({ name: String(name || 'import'), kind: parsed.kind, when: new Date().toISOString(), days: Object.keys(parsed.days || {}).length, weights: Object.keys(parsed.weights || {}).length });
  fs.mkdirSync(userDir(id), { recursive: true }); writeJson(nutFile(id), n); return n;
}
const foodsFile = (id) => path.join(userDir(id), 'foods.json');
function getFoods(id) { return readJson(foodsFile(id), { byDate: {} }); }
function mergeFoods(id, byDate) { if (!byDate || !Object.keys(byDate).length) return; const f = getFoods(id); for (const d of Object.keys(byDate)) f.byDate[d] = byDate[d]; fs.mkdirSync(userDir(id), { recursive: true }); writeJson(foodsFile(id), f); }
function mergeDays(id, days) { const n = getNutrition(id); Object.assign(n.days, days || {}); fs.mkdirSync(userDir(id), { recursive: true }); writeJson(nutFile(id), n); return n; }
function setSync(id, key, patch) { const n = getNutrition(id); n.sync = n.sync || {}; n.sync[key] = Object.assign({}, n.sync[key] || {}, patch); fs.mkdirSync(userDir(id), { recursive: true }); writeJson(nutFile(id), n); return n.sync[key]; }
function getSync(id, key) { const n = getNutrition(id); return (n.sync && n.sync[key]) || {}; }
function clearNutrition(id) { try { fs.unlinkSync(nutFile(id)); } catch (e) { /* none */ } try { fs.unlinkSync(foodsFile(id)); } catch (e) { /* none */ } }
function deleteUser(id) { saveUsers(loadUsers().filter(u => u.id !== id)); rmrf(userDir(id)); }

module.exports = { init, signup, login, listUsers, getFoods, mergeFoods, mergeDays, setSync, getSync, getNutrition, mergeWeights, mergeNutrition, clearNutrition, deleteUser, getUser, updateUser, userCount, ageFromDob, newScanId, scanPath, saveScan, listScans, getScan, deleteScan, updateScan };
