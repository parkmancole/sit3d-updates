'use strict';
const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const path = require('path'), fs = require('fs'), cp = require('child_process');
const store = require('./store.js');
function rmrf(p) { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } }

const { Scanner } = require('./scanner.js');
const { analyse } = require('../pipeline/analysis.js');
const nutrition = require('./nutrition.js');
const { Updater } = require('./updater.js');
const mfp = require('./mfp.js');
const NP = require('../pipeline/nutrition_progress.js');
const coach = require('./coach.js');
const mnd = require('./mynetdiary.js');
const PROVIDERS = { mfp: { mod: mfp, name: 'MyFitnessPal', backDays: 1100, ranged: true }, mnd: { mod: mnd, name: 'MyNetDiary', backDays: 400 } };
const profDir = (k, userId) => path.join(DATA, 'browser', k + '-' + userId);
const CAL = require('../pipeline/calibrate.js');
const prov = (k) => { const p = PROVIDERS[k]; if (!p) throw new Error('Unknown nutrition app.'); return p; };

if (process.env.SIT3D_SHOTS) app.commandLine.appendSwitch('mute-audio');   // the developer self-test must never make noise on the user's PC
app.setName('sit3d');
app.setPath('userData', path.join(app.getPath('appData'), process.env.SIT3D_DATA_NAME || 'sit3d'));   // '*' is not allowed in Windows folder names
const DATA = process.env.SIT3D_DATA || app.getPath('userData');
const APP_ROOT = path.join(__dirname, '..', '..');
const LBS = 0.45359237;
const APP_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(APP_ROOT, 'package.json'), 'utf8').split(String.fromCharCode(0xFEFF)).join('')).version; } catch (e) { return '0.0.0'; } })();
let updater = null;
function logLine(msg) { try { const d = path.join(DATA, 'logs'); fs.mkdirSync(d, { recursive: true }); const f = path.join(d, 'sit3d.log'); try { if (fs.statSync(f).size > 1500000) fs.renameSync(f, f + '.old'); } catch (e) { /* none */ } fs.appendFileSync(f, new Date().toISOString() + ' ' + msg + '\n'); } catch (e) { /* never break the app for logging */ } }
let win = null, session = { userId: null }, scanner = null, scannerCfg = null;

const scannerFile = () => path.join(DATA, 'scanner.json');
function loadScannerCfg() { try { return JSON.parse(fs.readFileSync(scannerFile(), 'utf8')); } catch (e) { return { fxScale: 1, serviceDir: 'C:\\Apps\\ProScanner\\Service', keepRaw: true, simulate: false }; } }
function saveScannerCfg() { fs.writeFileSync(scannerFile(), JSON.stringify(scannerCfg, null, 1)); }
const send = (ch, payload) => { if (win && !win.isDestroyed()) win.webContents.send(ch, payload); };
const me = () => { if (!session.userId) throw new Error('Please sign in.'); const u = store.getUser(session.userId); if (!u) throw new Error('Session expired.'); return u; };
const wrap = (fn) => async (ev, ...a) => { try { return { ok: true, data: await fn(...a) }; } catch (e) { logLine('ERROR ' + String(e && e.stack || e).split('\n').slice(0, 4).join(' | ')); return { ok: false, error: String(e && e.message || e) }; } };

function summary(s) {
  const a = s.analysis || {};
  return { id: s.id, created: s.created, source: s.source, weight_kg: s.weight_kg, bmi: a.body && a.body.bmi, body_fat_pct: a.composition && a.composition.body_fat_pct, lean_mass_kg: a.composition && a.composition.lean_mass_kg, shape_score: a.composition && a.composition.shape_score, posture_score: a.posture && a.posture.score, waist_cm: a.circumferences_cm && a.circumferences_cm.waist, hips_cm: a.circumferences_cm && a.circumferences_cm.hips, chest_cm: a.circumferences_cm && a.circumferences_cm.chest, neck_cm: a.circumferences_cm && a.circumferences_cm.neck, thigh_cm: a.circumferences_cm && a.circumferences_cm.thigh_left, calf_cm: a.circumferences_cm && a.circumferences_cm.calf_left, metabolic_age: a.composition && a.composition.metabolic_age, visceral: a.composition && a.composition.visceral_index, height_cm: a.body && a.body.height_cm };
}

// ---- processing ----
function runWorker(spec, onProgress) {
  return new Promise((resolve, reject) => {
    const specFile = path.join(spec.outDir, 'spec.json'); fs.mkdirSync(spec.outDir, { recursive: true }); fs.writeFileSync(specFile, JSON.stringify(spec));
    const child = cp.spawn(process.execPath, [path.join(APP_ROOT, 'src', 'pipeline', 'run.js'), specFile], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), windowsHide: true });
    let buf = '', err = '';
    child.stdout.on('data', (d) => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (line.startsWith('PROGRESS ')) { try { onProgress(JSON.parse(line.slice(9))); } catch (e) { /* ignore */ } } else if (line.startsWith('ERROR ')) err = line.slice(6); } });
    child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (code) => { if (code !== 0) return reject(new Error('Processing failed: ' + err.slice(0, 400))); try { resolve({ pipeline: JSON.parse(fs.readFileSync(path.join(spec.outDir, 'pipeline.json'), 'utf8')), viewFile: path.join(spec.outDir, 'view.bin') }); } catch (e) { reject(e); } });
  });
}
// The platform weight of a scan: the standing weight read BEFORE the hands went on the handles when there is one (gripping adds ~3 lb), else the post-scan reading.
const rawPlatformKg = (sc) => { if (!sc || sc.weight_source === 'entered') return null; const P = sc.preLoads, L = sc.loads; return P && P[4] ? { kg: P[4] * LBS, pre: true } : (L && L[4] ? { kg: L[4] * LBS, pre: false } : null); };
const applyW = (kg, calib) => { const w = calib && calib.weight; return w ? w.a * kg + w.b : kg; };   // platform weight calibration (fitted against a trusted reference weight)
function buildScan(user, id, source, pipelineRes, extra) {
  const loads = extra.loads || null;
  let near = null; try { near = nutrition.nearestWeight(store.getNutrition(user.id).weights, extra.created || new Date().toISOString(), 4); } catch (e) { /* none */ }
  const preLoads = extra.preLoads || null;
  const weightKg = preLoads && preLoads[4] ? applyW(preLoads[4] * LBS, user.calib) : loads && loads[4] ? applyW(loads[4] * LBS, user.calib) : (extra.weight_kg || near || user.weight_kg || null);
  const measure = pipelineRes.pipeline.measure;
  const u = Object.assign({}, user, { age: store.ageFromDob(user.dob), weight_kg: weightKg });
  const analysis = analyse(u, { measure, loads }, user.calib || {});
  return { id, userId: user.id, created: extra.created || new Date().toISOString(), source, timing: extra.timing || null, loads, preLoads, weight_source: preLoads ? 'standing' : undefined, weight_kg: weightKg ? Math.round(weightKg * 10) / 10 : null, measure, analysis, info: pipelineRes.pipeline.info, tape: extra.tape || null, hasRaw: !!extra.hasRaw };
}
async function processAndSave(user, spec, extra, source) {
  const id = store.newScanId(); const tmp = path.join(DATA, 'tmp', id); spec.outDir = tmp;
  logLine('processing ' + spec.mode + ' scan ' + id); const res = await runWorker(spec, (p) => send('scan:progress', p));
  const scan = buildScan(user, id, source, res, extra); logLine('processed ' + id + ' height_mm=' + scan.measure.height_mm + ' waist_mm=' + (scan.measure.circumference_mm || {}).waist + ' fov=' + JSON.stringify(res.pipeline.info && res.pipeline.info.fov));
  const viewBuf = fs.readFileSync(res.viewFile); const view = new Int16Array(viewBuf.buffer, viewBuf.byteOffset, viewBuf.length / 2);
  const dir = store.saveScan(user.id, scan, view);
  if (extra.rawDir && scannerCfg.keepRaw) { try { fs.renameSync(extra.rawDir, path.join(dir, 'raw')); scan.hasRaw = true; store.updateScan(user.id, id, { hasRaw: true }); } catch (e) { /* keep going */ } }
  rmrf(tmp);
  return scan;
}

function ipc() {
  ipcMain.handle('app:info', wrap(async () => ({ version: APP_VERSION, appRoot: APP_ROOT, dataDir: DATA, hardware: Scanner.prototype.hardwareAvailable.call({}), users: store.userCount(), scanner: scannerCfg, user: session.userId ? store.getUser(session.userId) : null })));
  ipcMain.handle('auth:signup', wrap(async (f) => { const u = store.signup(f); session.userId = u.id; return u; }));
  ipcMain.handle('auth:login', wrap(async (n, p) => { const u = store.login(n, p); session.userId = u.id; autoSyncSoon(u.id); return u; }));
  ipcMain.handle('update:status', wrap(async () => updater ? updater.status() : { enabled: false, current: APP_VERSION }));
  ipcMain.handle('update:check', wrap(async () => { if (!updater) throw new Error('Updates are not available.'); await updater.check(); return updater.status(); }));
  ipcMain.handle('update:restart', wrap(async () => { if (scanner && scanner.busy) throw new Error('A scan is running. Restart after it finishes.'); app.relaunch(); app.exit(0); return true; }));
  // ---- live nutrition-app sync (MyFitnessPal, MyNetDiary; unofficial, see mfp.js / mynetdiary.js) ----
  ipcMain.handle('sync:status', wrap(async (k) => { const u = me(); return Object.assign({ running: syncRunning.has(u.id + k) }, store.getSync(u.id, k)); }));
  ipcMain.handle('sync:connect', wrap(async (k) => {
    const u = me(); const P = prov(k); const ok = await P.mod.connect(win, u.id, logLine, profDir(k, u.id));
    if (!ok) return { connected: false };
    store.setSync(u.id, k, { connected: true, since: new Date().toISOString(), error: null, needLogin: false }); logLine(k + ' connected'); setTimeout(() => runSync(k, u.id, null).catch(() => {}), 500); return { connected: true };
  }));
  ipcMain.handle('sync:run', wrap(async (k, days) => { const u = me(); await runSync(k, u.id, days || null); return store.getSync(u.id, k); }));
  ipcMain.handle('sync:disconnect', wrap(async (k) => { const u = me(); await prov(k).mod.disconnect(u.id, profDir(k, u.id)); store.setSync(u.id, k, { connected: false, error: null }); logLine(k + ' disconnected'); return true; }));
  // ---- AI coach (Google Gemini, bring-your-own free key; anonymous summaries only) ----
  const coachPacket = (u) => { const n = store.getNutrition(u.id); const scans = store.listScans(u.id).map(summary); const prog = nutritionProgress(u, 90); const age = store.ageFromDob(u.dob); return coach.buildPacket({ sex: u.sex, age, height_cm: u.height_cm, goal: u.goal, units: u.units }, scans, prog, n.days, mfp.localIso(new Date())); };
  const coachFile = (u) => path.join(DATA, 'ai', u.id + '_last.json');
  ipcMain.handle('ai:status', wrap(async () => { const u = me(); let last = null; try { last = JSON.parse(fs.readFileSync(coachFile(u), 'utf8')); } catch (e) { /* none */ } return Object.assign(coach.status(DATA, u.id), { last }); }));
  ipcMain.handle('ai:setKey', wrap(async (key, consent) => { const u = me(); const s = coach.setKey(DATA, u.id, key, consent); logLine('ai key saved'); return s; }));
  ipcMain.handle('ai:clear', wrap(async () => { const u = me(); coach.clear(DATA, u.id); try { fs.unlinkSync(coachFile(u)); } catch (e) { /* none */ } logLine('ai key removed'); return true; }));
  ipcMain.handle('ai:setVoice', wrap(async (v) => { const u = me(); return coach.setVoice(DATA, u.id, v); }));
  ipcMain.handle('ai:coach', wrap(async (question) => {
    const u = me(); const key = coach.getKey(DATA, u.id); const text = await coach.coachText(key, coachPacket(u), question ? String(question).slice(0, 400) : '');
    const out = { text, at: new Date().toISOString(), question: question || null }; if (!question) { fs.mkdirSync(path.join(DATA, 'ai'), { recursive: true }); fs.writeFileSync(coachFile(u), JSON.stringify(out)); }
    logLine('ai coach ok'); return out;
  }));
  ipcMain.handle('ai:liveConfig', wrap(async () => { const u = me(); return coach.liveConfig(DATA, u.id, coachPacket(u)); }));
  ipcMain.handle('auth:users', wrap(async () => store.listUsers()));
  ipcMain.handle('auth:deleteAccount', wrap(async (pin) => { const u = me(); store.login(u.id, pin); store.deleteUser(u.id); logLine('account deleted'); session.userId = null; return true; }));
  ipcMain.handle('scans:setWeight', wrap(async (id, kg) => {
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.'); kg = Number(kg); if (!(kg >= 25 && kg <= 300)) throw new Error('Enter a weight between 25 and 300 kg (55 to 660 lb).');
    const uu = Object.assign({}, store.getUser(u.id), { age: store.ageFromDob(u.dob), weight_kg: kg });
    const analysis = analyse(uu, { measure: r.scan.measure, loads: r.scan.loads }, u.calib || {});
    store.updateScan(u.id, id, { analysis, weight_kg: Math.round(kg * 10) / 10, weight_source: 'entered' }); return store.getScan(u.id, id);
  }));
  ipcMain.handle('nutrition:get', wrap(async () => { const u = me(); const n = store.getNutrition(u.id); const sc = store.listScans(u.id); const last = sc.length ? sc[sc.length - 1].weight_kg : null; return { summary: nutrition.summarize(n, new Date().toISOString().slice(0, 10), last || u.weight_kg), imports: n.imports, weightLogs: Object.keys(n.weights).length }; }));
  ipcMain.handle('nutrition:import', wrap(async () => {
    const u = me(); const r = await dialog.showOpenDialog(win, { title: 'Choose nutrition or weight CSV exports', properties: ['openFile', 'multiSelections'], filters: [{ name: 'CSV exports', extensions: ['csv'] }] });
    if (r.canceled || !r.filePaths.length) return { canceled: true };
    const results = [];
    for (const f of r.filePaths) { try { const parsed = nutrition.parseExport(fs.readFileSync(f, 'utf8'), u.units === 'imperial' ? 'lb' : 'kg'); store.mergeNutrition(u.id, parsed, path.basename(f)); store.mergeFoods(u.id, parsed.foods); results.push({ file: path.basename(f), ok: true, kind: parsed.kind, days: Object.keys(parsed.days).length, weights: Object.keys(parsed.weights).length }); } catch (e) { results.push({ file: path.basename(f), ok: false, error: e.message }); } }
    logLine('nutrition import: ' + results.map(x => x.file + ':' + (x.ok ? 'ok' : 'fail')).join(', ')); return { results };
  }));
  ipcMain.handle('nutrition:all', wrap(async () => { const u = me(); const n = store.getNutrition(u.id); return { days: n.days, weights: n.weights }; }));
  ipcMain.handle('nutrition:foods', wrap(async (fromIso, toIso) => { const u = me(); const f = store.getFoods(u.id).byDate; const out = {}; for (const d of Object.keys(f)) if ((!fromIso || d >= fromIso) && (!toIso || d <= toIso)) out[d] = f[d]; return out; }));
  ipcMain.handle('nutrition:progress', wrap(async (rangeDays) => nutritionProgress(me(), rangeDays)));
  ipcMain.handle('nutrition:clear', wrap(async () => { store.clearNutrition(me().id); return true; }));
  ipcMain.handle('auth:logout', wrap(async () => { session.userId = null; return true; }));
  ipcMain.handle('user:update', wrap(async (patch) => store.updateUser(me().id, patch)));
  ipcMain.handle('scans:list', wrap(async () => store.listScans(me().id).map(summary)));
  ipcMain.handle('scans:get', wrap(async (id) => { const r = store.getScan(me().id, id); if (!r) throw new Error('Scan not found.'); return r; }));
  ipcMain.handle('scans:delete', wrap(async (id) => { store.deleteScan(me().id, id); return true; }));
  // ---- accuracy calibration: tape-measure samples -> a fitted correction per site, applied to EVERY scan ----
  const calSummary = (u) => {
    const samples = u.calibSamples || []; const reports = CAL.SITES.map((s) => CAL.siteReport(s, samples)); const scans = store.listScans(u.id);
    const refW = CAL.weightReport(samples), refB = CAL.refReport(samples, 'bf_ref_pct', (s) => s.bf_scan);
    return { samples: samples.map((s) => ({ id: s.id, date: s.date, scanId: s.scanId, tape: s.tape, scan: s.scan, weight_ref_kg: s.weight_ref_kg || null, platform_kg: s.platform_kg || null, bf_ref_pct: s.bf_ref_pct || null })), reports, overall: CAL.overall(reports),
      height: CAL.heightReport(samples, u.height_cm), weight: refW, bodyFat: refB, fxScale: scannerCfg.fxScale, scanCount: scans.length, calib: u.calib || {} };
  };
  const reanalyseAll = (u0) => {   // every stored scan is re-analysed with the current calibration so the whole history stays consistent
    const u = store.getUser(u0.id); let n = 0;
    for (const sm of store.listScans(u.id)) { const r = store.getScan(u.id, sm.id); if (!r || !r.scan.measure) continue; const L = r.scan.loads; const rp = rawPlatformKg(r.scan); const fromPlatform = !!rp; const kg = fromPlatform ? applyW(rp.kg, u.calib) : r.scan.weight_kg; const uu = Object.assign({}, u, { age: store.ageFromDob(u.dob), weight_kg: kg }); const patch = { analysis: analyse(uu, { measure: r.scan.measure, loads: L }, u.calib || {}) }; if (fromPlatform) patch.weight_kg = Math.round(kg * 10) / 10; store.updateScan(u.id, sm.id, patch); n++; }
    return n;
  };
  const refit = (u) => {
    const samples = u.calibSamples || []; const calib = CAL.buildCalib(samples);
    // body fat reference offset: what the (circumference-calibrated) scan says vs DEXA / calipers
    store.updateUser(u.id, { calib }); const u2 = store.getUser(u.id);
    for (const s of samples) { if (s.bf_ref_pct == null) continue; const r = store.getScan(u.id, s.scanId); if (!r || !r.scan.measure) continue; const a = analyse(Object.assign({}, u2, { age: store.ageFromDob(u2.dob), weight_kg: r.scan.weight_kg }), { measure: r.scan.measure, loads: r.scan.loads }, calib); s.bf_scan = a.composition && a.composition.body_fat_pct; }
    const diffs = samples.filter((s) => s.bf_ref_pct != null && s.bf_scan != null).map((s) => s.bf_ref_pct - s.bf_scan);
    if (diffs.length) calib.bf_offset = Math.round(CAL.median(diffs) * 10) / 10;
    store.updateUser(u.id, { calib, calibSamples: samples }); const n = reanalyseAll(u); logLine('calibration refit: ' + samples.length + ' samples, ' + n + ' scans re-analysed');
    return store.getUser(u.id);
  };
  const addSample = (u, scanId, tape, refs) => {
    const r = store.getScan(u.id, scanId); if (!r) throw new Error('Scan not found.'); const c = r.scan.measure.circumference_mm || {}; const scanCm = {}; for (const s of CAL.SITES) if (c[s]) scanCm[s] = Math.round(c[s]) / 10;
    if (r.scan.measure.height_mm) scanCm.height = Math.round(r.scan.measure.height_mm) / 10;
    const tp = {}; for (const s of CAL.SITES) { const t = Number(tape && tape[s]); if (t > 10 && t < 250 && scanCm[s]) tp[s] = Math.round(t * 10) / 10; }
    if (!Object.keys(tp).length && !(refs && (refs.bf_ref_pct || refs.weight_ref_kg))) throw new Error('Enter at least one tape measurement.');
    const old = (u.calibSamples || []).find((s) => s.scanId === scanId) || {}; const samples = (u.calibSamples || []).filter((s) => s.scanId !== scanId);   // one sample per scan: re-entering replaces it (a weight-only entry keeps the earlier tape numbers)
    const rp = rawPlatformKg(r.scan); const platform = rp ? Math.round(rp.kg * 100) / 100 : null; const standing = !!(rp && rp.pre);   // the RAW platform reading, never the calibrated one; only standing (hands-off) weigh-ins can calibrate the platform
    const wRef = refs && Number(refs.weight_ref_kg) > 20 ? Number(refs.weight_ref_kg) : (old.weight_ref_kg || null), bRef = refs && Number(refs.bf_ref_pct) > 3 && Number(refs.bf_ref_pct) < 60 ? Number(refs.bf_ref_pct) : (old.bf_ref_pct || null);
    samples.push({ id: 'c' + Date.now().toString(36), scanId, date: r.scan.created, scan: scanCm, tape: Object.keys(tp).length ? tp : (old.tape || {}), platform_kg: platform, platform_standing: standing, weight_ref_kg: wRef, bf_ref_pct: bRef });
    store.updateUser(u.id, { calibSamples: samples.slice(-60) }); store.updateScan(u.id, scanId, { tape: tp });
    return refit(store.getUser(u.id));
  };
  ipcMain.handle('calib:state', wrap(async () => calSummary(store.getUser(me().id))));
  ipcMain.handle('calib:add', wrap(async (scanId, tape, refs) => { const u = me(); const nu = addSample(store.getUser(u.id), scanId, tape, refs); return calSummary(nu); }));
  ipcMain.handle('calib:remove', wrap(async (id) => { const u = store.getUser(me().id); store.updateUser(u.id, { calibSamples: (u.calibSamples || []).filter((s) => s.id !== id) }); return calSummary(refit(store.getUser(u.id))); }));
  ipcMain.handle('calib:reset', wrap(async () => { const u = store.getUser(me().id); store.updateUser(u.id, { calibSamples: [], calib: {} }); reanalyseAll(u); return calSummary(store.getUser(u.id)); }));
  ipcMain.handle('calib:fixScale', wrap(async () => {   // camera scale from the median height error over all samples; applies to scans processed from now on
    const u = store.getUser(me().id); const h = CAL.heightReport(u.calibSamples || [], u.height_cm); if (!h) throw new Error('Add a calibration sample first (it records the scanner height).');
    const k = Math.max(0.8, Math.min(1.25, h.scaleFactor)); scannerCfg.fxScale = Math.round((scannerCfg.fxScale / k) * 10000) / 10000; saveScannerCfg(); return calSummary(u);
  }));
  ipcMain.handle('scans:tape', wrap(async (id, tape) => {   // tape measurements (cm): kept as a calibration SAMPLE (the old one-scan overwrite is gone), then everything is refit
    const u = me(); const nu = addSample(store.getUser(u.id), id, tape, null); const r = store.getScan(u.id, id); return { calib: nu.calib, analysis: r.scan.analysis };
  }));
  ipcMain.handle('scans:reprocess', wrap(async (id) => {
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.');
    const raw = path.join(store.scanPath(u.id, id), 'raw'); if (!fs.existsSync(raw)) throw new Error('This scan has no saved raw frames.');
    const t = r.scan.timing || {}; const tmp = path.join(DATA, 'tmp', id + '_re');
    const res = await runWorker({ mode: 'raw', scanDir: raw, scanDurationS: t.scanDurationS, startOffsetS: t.startOffsetS, fxScale: scannerCfg.fxScale, outDir: tmp }, (p) => send('scan:progress', p));
    const upd = buildScan(store.getUser(u.id), id, r.scan.source, res, { loads: r.scan.loads, timing: t, created: r.scan.created, tape: r.scan.tape, hasRaw: true });
    const vb = fs.readFileSync(res.viewFile); store.saveScan(u.id, upd, new Int16Array(vb.buffer, vb.byteOffset, vb.length / 2)); rmrf(tmp); return upd;
  }));
  ipcMain.handle('scan:demo', wrap(async () => { const u = me(); send('scan:progress', { p: 0, msg: 'Starting' }); return processAndSave(u, { mode: 'demo', demoFile: path.join(APP_ROOT, 'demo', 'demo_body.f32') }, { loads: [31.3, 34.6, 45.2, 47.1, 158.1, 0.091] }, 'demo'); }));
  ipcMain.handle('scan:start', wrap(async (mode) => {
    const u = me(); if (scanner && scanner.busy) throw new Error('A scan is already running.');
    scanner = new Scanner({ serviceDir: scannerCfg.serviceDir, capturePs1: path.join(APP_ROOT, 'hardware', 'Capture-Depth.ps1'), simulate: mode === 'simulate' });
    if (monStop) { stopMonitor(); await new Promise((r) => setTimeout(r, 600)); }   // let Windows release the USB device before the scan opens it
    scanner.on('live', (v) => sendLive(v));
    scanner.on('phase', (p) => { logLine('phase ' + p.phase + (p.message ? ' - ' + p.message : '')); send('scan:phase', p); });
    const work = path.join(DATA, 'tmp', 'live_' + store.newScanId());
    try {
      logLine('scan:start mode=' + mode + ' user=' + u.username); const r = await scanner.runScan(work); logLine('scanner done: duration=' + r.scanDurationS + ' offset=' + r.startOffsetS + ' loads=' + JSON.stringify(r.loads) + ' rx=' + JSON.stringify(r.rx || []));
      send('scan:phase', { phase: 'processing', message: 'Building your 3D model…' });
      let scan;
      if (r.simulated) scan = await processAndSave(u, { mode: 'demo', demoFile: path.join(APP_ROOT, 'demo', 'demo_body.f32') }, { loads: r.loads, preLoads: r.preLoads, timing: { scanDurationS: r.scanDurationS } }, 'simulated');
      else scan = await processAndSave(u, { mode: 'raw', scanDir: r.scanDir, scanDurationS: r.scanDurationS, startOffsetS: r.startOffsetS, fxScale: scannerCfg.fxScale }, { loads: r.loads, preLoads: r.preLoads, timing: { scanDurationS: r.scanDurationS, startOffsetS: r.startOffsetS }, rawDir: r.scanDir }, 'scanner');
      send('scan:phase', { phase: 'done', scanId: scan.id }); return scan;
    } catch (e) { scanner.killCapture(); send('scan:phase', { phase: 'error', message: String(e.message || e) }); throw e; }
    finally { try { rmrf(work); } catch (e) { /* ignore */ } }
  }));
  // live platform weight on the scan screen (calibrated like a saved scan)
  let monStop = null, monTimer = null; let liveSeen = 0;
  const sendLive = (v) => { const u = session.userId ? store.getUser(session.userId) : null; const kg = applyW(v[4] * LBS, u && u.calib); liveSeen++; send('scan:live', { kg: Math.round(kg * 10) / 10, loads: v.slice(0, 4).map((x) => Math.round(x * LBS * 10) / 10) }); };
  const stopMonitor = () => { clearTimeout(monTimer); if (monStop) { try { const r = monStop(); logLine('weight monitor stopped: ' + JSON.stringify(r)); } catch (e) { /* ignore */ } monStop = null; } };
  ipcMain.handle('scanner:monitor', wrap(async (on) => {
    stopMonitor(); if (!on) return true;
    if (scanner && scanner.busy) return false; if (!Scanner.prototype.hardwareAvailable.call({}).ok) return false;
    const m = new Scanner({ simulate: false }); try { monStop = m.monitor(sendLive); } catch (e) { logLine('weight monitor failed: ' + e.message); return false; }
    monTimer = setTimeout(stopMonitor, 15 * 60 * 1000); return true;
  }));
  ipcMain.handle('scan:cancel', wrap(async () => { if (scanner) scanner.cancel(); return true; }));
  ipcMain.handle('scanner:rehome', wrap(async () => { stopMonitor(); const s = new Scanner({ simulate: scannerCfg.simulate }); s.on('phase', (p) => send('scan:phase', p)); await s.rehome(); return true; }));
  ipcMain.handle('scanner:config', wrap(async (patch) => { Object.assign(scannerCfg, patch || {}); saveScannerCfg(); return scannerCfg; }));
  ipcMain.handle('scanner:calibrateScale', wrap(async (id) => {   // adjust focal-length scale so this scan's measured height matches the user's entered height
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.');
    const hm = r.scan.measure.height_mm, ht = u.height_cm * 10; if (!hm) throw new Error('No height measured.');
    const k = Math.max(0.8, Math.min(1.25, ht / hm)); scannerCfg.fxScale = Math.round((scannerCfg.fxScale / k) * 10000) / 10000; saveScannerCfg();
    return { fxScale: scannerCfg.fxScale, factor: k };
  }));
}

const syncRunning = new Set();
async function runSync(k, userId, backDays) {
  const P = prov(k); const key = userId + k;
  if (syncRunning.has(key)) return;
  const st = store.getSync(userId, k); if (!st.connected) return;
  syncRunning.add(key); send('sync:progress', { app: k, running: true, p: 0 });
  try {
    const today = P.mod.localIso(new Date()), A = P.mod.addDays; const target = A(today, -((backDays || P.backDays) - 1));
    // Recent days always come first (they are what matters most and are quick); older history is filled in afterwards and can resume if interrupted.
    // history depth: users who synced before the deeper history existed get the older days added once (resumable)
    const histDone = st.histDays || (st.lastDate ? (k === 'mfp' ? 120 : 30) : 0);
    if (P.ranged && st.lastDate && !st.backfillTo && histDone < P.backDays) { st.backfillTo = A(today, -(histDone - 1)); store.setSync(userId, k, { backfillTo: st.backfillTo }); }
    const needMndDeep = !P.ranged && st.lastDate && histDone < P.backDays && !backDays;
    const jobs = [];
    if (needMndDeep) jobs.push({ from: target, to: today, deep: true });
    else if (backDays || !P.ranged) jobs.push({ from: backDays ? target : (st.lastDate ? A(st.lastDate, -3) : target), to: today });
    else if (st.lastDate) { jobs.push({ from: A(st.lastDate, -3), to: today }); if (st.backfillTo && st.backfillTo > target) jobs.push({ from: target, to: A(st.backfillTo, -1), backfill: true }); }
    else { const mid = A(today, -13); jobs.push({ from: mid, to: today, first: true }); jobs.push({ from: target, to: A(mid, -1), backfill: true }); }
    const span = (j) => Math.round((new Date(j.to + 'T12:00:00') - new Date(j.from + 'T12:00:00')) / 86400000) + 1; const totalDays = jobs.reduce((a, j) => a + span(j), 0); let done = 0, read = 0;
    for (const job of jobs) {
      let curDay = null;
      const r = await P.mod.sync(userId, job.from, (p) => { curDay = p.day; send('sync:progress', { app: k, running: true, p: (done + p.p * span(job)) / totalDays, day: p.day }); },
        (days, foods) => { store.mergeDays(userId, days); store.mergeFoods(userId, foods); if (job.backfill && curDay) store.setSync(userId, k, { backfillTo: curDay }); }, profDir(k, userId), logLine, job.to, (job.backfill || job.deep || (!P.ranged && !st.lastDate)) ? { emptyStop: k === 'mfp' ? 60 : 45 } : {});
      read += r.read; done += span(job);
      if (job.first) store.setSync(userId, k, { lastDate: today, lastSync: new Date().toISOString(), backfillTo: job.from });
      if (job.backfill) store.setSync(userId, k, { backfillTo: null, histDays: P.backDays });
      if (job.deep) store.setSync(userId, k, { histDays: P.backDays });
    }
    if (P.mod.syncWeights) {   // body-weight entries from the app (kept separate from the scanner's weights)
      try { const uu = store.getUser(userId); const w = await P.mod.syncWeights(profDir(k, userId), logLine, uu && uu.units === 'imperial' ? 'lb' : 'kg', st.weightsDone ? 2 : 12); const c = store.mergeWeights(userId, w, k); if (c) { const nn = store.getNutrition(userId); store.setSync(userId, k, { weightsDone: true, weightCount: Object.keys(nn.weightSrc || {}).filter((d) => nn.weightSrc[d] === k).length }); } logLine(k + ' weights: ' + c + ' weigh-ins'); }
      catch (e) { if (e.message === 'NEED_LOGIN') throw e; logLine(k + ' weights failed: ' + e.message); }
    }
    if (!P.ranged && !st.lastDate) store.setSync(userId, k, { histDays: P.backDays });
    store.setSync(userId, k, { lastSync: new Date().toISOString(), lastDate: today, error: null, lastRead: read }); logLine(k + ' sync ok: ' + read + ' days with data (' + jobs[jobs.length - 1].from + ' to ' + today + ')');
  } catch (e) {
    const need = e.message === 'NEED_LOGIN'; const msg = need ? P.name + ' asked for a new login. Please connect again.' : e.message;
    store.setSync(userId, k, need ? { connected: false, needLogin: true, error: msg } : { error: e.message }); if (need) send('sync:needlogin', { app: k, name: P.name }); logLine(k + ' sync failed: ' + e.message);
    throw new Error(msg);
  } finally { syncRunning.delete(key); send('sync:progress', { app: k, running: false, p: 1 }); }
}
function autoSyncSoon(userId) { setTimeout(() => { for (const k of Object.keys(PROVIDERS)) { const st = store.getSync(userId, k); if (st.connected) runSync(k, userId, null).catch(() => {}); else if (st.needLogin) send('sync:needlogin', { app: k, name: PROVIDERS[k].name }); } }, 1500); }   // every sign-in: fetch only what is new (or ask to log in again)

function nutritionProgress(u, rangeDays) {
    const n = store.getNutrition(u.id); const scans = store.listScans(u.id).map(summary); const today = mfp.localIso(new Date());
    const range = Math.max(14, Math.min(400, Number(rangeDays) || 90)); const from = NP.addDays(today, -(range - 1));
    const lastW = scans.length && scans[scans.length - 1].weight_kg ? scans[scans.length - 1].weight_kg : (u.weight_kg || null);
    const wser = Object.keys(n.weights).sort().filter(d => d >= from).map(d => ({ t: d + 'T12:00:00', v: n.weights[d], src: (n.weightSrc && n.weightSrc[d]) || 'import' }));
    const foods = store.getFoods(u.id).byDate; const recentDays = Object.keys(n.days).sort().reverse().slice(0, 21).map(d => ({ date: d, totals: n.days[d], count: (foods[d] || []).length }));
    return {
      hasData: Object.keys(n.days).length > 0, range, from, today,
      windows: { w7: NP.windowSummary(n.days, today, 7, lastW), w30: NP.windowSummary(n.days, today, 30, lastW), w90: NP.windowSummary(n.days, today, 90, lastW) },
      kcal7: NP.rolling(n.days, from, today, 7), weights: wser,
      scanWeights: scans.filter(s => s.weight_kg != null && s.created.slice(0, 10) >= from).map(s => ({ t: s.created, v: s.weight_kg })),
      scanBodyFat: scans.filter(s => s.body_fat_pct != null && s.created.slice(0, 10) >= from).map(s => ({ t: s.created, v: s.body_fat_pct })),
      between: NP.betweenScans(scans, n.days), top: NP.topFoods(foods, NP.addDays(today, -30), NP.addDays(today, -1), 8), roi: NP.foodRoi(foods, NP.addDays(today, -14), NP.addDays(today, -1), 6), recentDays, sync: n.sync || {},
    };
}

function createWindow() {
  win = new BrowserWindow({ width: 1320, height: 860, minWidth: 1024, minHeight: 700, backgroundColor: '#FFF7EF', title: 'S*it3D', show: false, autoHideMenuBar: true, webPreferences: { nodeIntegration: true, contextIsolation: false, enableRemoteModule: false, spellcheck: false } });
  Menu.setApplicationMenu(null);
  win.webContents.on('console-message', (e, level, msg, line, src) => { if (level >= 2) logLine('renderer ' + msg + ' (' + path.basename(src || '') + ':' + line + ')'); });
  win.webContents.session.setPermissionRequestHandler((wc, permission, cb) => cb(permission === 'media' && wc === win.webContents));
  win.loadFile(path.join(APP_ROOT, 'src', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.once('did-finish-load', () => setTimeout(() => { try { if (global.__sit3d && global.__sit3d.markGood) global.__sit3d.markGood(); } catch (e) { /* ignore */ } }, 6000));
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11') win.setFullScreen(!win.isFullScreen()); if (i.type === 'keyDown' && i.control && i.shift && i.key === 'I') win.webContents.toggleDevTools(); });
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    store.init(DATA); scannerCfg = loadScannerCfg();
    let pkgUrl = ''; try { pkgUrl = JSON.parse(fs.readFileSync(path.join(APP_ROOT, 'package.json'), 'utf8').split(String.fromCharCode(0xFEFF)).join('')).sit3dUpdateUrl || ''; } catch (e) { /* none */ }
    const codeDir = global.__sit3d ? global.__sit3d.codeDir : path.join(process.env.LOCALAPPDATA || DATA, 'sit3d', 'code');
    updater = new Updater({ url: process.env.SIT3D_UPDATE_URL || scannerCfg.updateUrl || pkgUrl, currentVersion: APP_VERSION, codeDir, log: logLine });
    ipc(); createWindow(); updater.start((a) => send('update:ready', a)); logLine('S*it3D started, data=' + DATA + ' hid=' + JSON.stringify(Scanner.prototype.hardwareAvailable.call({})));
    if (process.env.SIT3D_SHOTS) require('./autotest.js').run({ win, DATA, send, ipcMain });
  });
  app.on('window-all-closed', () => app.quit());
}
