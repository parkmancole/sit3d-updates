'use strict';
// Scanner controller: turntable (USB HID, node-hid) + depth capture (32-bit PowerShell child, Capture-Depth.ps1). Emits 'phase' events.
// Phases: starting -> sensors -> board -> homing? -> armed -> countdown -> scanning -> finishing -> saving -> done | error
const { EventEmitter } = require('events');
const fs = require('fs'), path = require('path'), cp = require('child_process');

let HID = null; try { HID = require('node-hid'); } catch (e) { HID = null; }
const VID = 5824, PID = 1158, UPAGE = 65451, USAGE = 512;
const ALLOWED = new Set(['tt_statusReady', 'tt_calib', 'tt_cameraReady', 'tt_resetCameraReady']);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

class Scanner extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.opts = Object.assign({ serviceDir: 'C:\\Apps\\ProScanner\\Service', postrollMs: 3000, simulate: false }, opts);
    this.dev = null; this.capture = null; this.cancelled = false; this.busy = false;
  }
  phase(phase, extra = {}) { this.emit('phase', Object.assign({ phase, t: Date.now() }, extra)); }
  hardwareAvailable() {
    if (!HID) return { ok: false, why: 'USB library not available' };
    try { const d = HID.devices().find(x => x.vendorId === VID && x.productId === PID && x.usagePage === UPAGE && x.usage === USAGE); return d ? { ok: true, path: d.path } : { ok: false, why: 'Turntable not found (is the scanner plugged in and powered?)' }; }
    catch (e) { return { ok: false, why: String(e.message || e) }; }
  }
  openBoard() {
    const a = this.hardwareAvailable(); if (!a.ok) throw new Error(a.why);
    this.dev = new HID.HID(a.path); this.dev.on('data', (buf) => this._rx(buf)); this.dev.on('error', (e) => this.phase('log', { message: 'USB error: ' + e }));
  }
  closeBoard() { try { if (this.dev) this.dev.close(); } catch (e) { /* ignore */ } this.dev = null; }
  send(cmd) {
    if (!ALLOWED.has(cmd)) throw new Error('command not allowed: ' + cmd);
    const a = [0]; for (const c of cmd) a.push(c.charCodeAt(0)); while (a.length < 64) a.push(0);
    this.dev.write(a);
  }
  _rx(buf) {
    let s = ''; for (const b of buf) if (b > 39 && b < 127) s += String.fromCharCode(b);
    this.emit('rx', s); if (this._onRx) this._onRx(s);
    if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) this.emit('live', v); }   // also while armed / scanning
  }
  // Passive scale monitor for the scan screen: opens the board, sends only the harmless tt_statusReady, and forwards every weight= message the board reports.
  // (The firmware decides when it reports weight; if it stays silent while idle the screen simply shows no reading.)
  monitor(onLive) {
    if (this.opts.simulate || this.busy) return () => {};
    this.openBoard(); let n = 0; const t0 = Date.now();
    this._onRx = (s) => { if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) { n++; onLive(v); } } };
    const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 3000);
    return () => { clearInterval(poll); this._onRx = null; this.closeBoard(); return { seen: n, seconds: Math.round((Date.now() - t0) / 1000) }; };
  }
  cancel() { this.cancelled = true; if (this._abort) this._abort(new Error('Scan cancelled.')); }

  async rehome() {
    if (this.opts.simulate) { this.phase('homing', { message: 'Re-homing the turntable (simulated).' }); await sleep(2500); this.phase('idle'); return; }
    this.openBoard();
    try {
      this.phase('homing', { message: 'The platform is turning back to its start position. Stay clear of it.' });
      await new Promise((resolve, reject) => {
        const to = setTimeout(() => reject(new Error('Homing timed out.')), 80000); let sent = false;
        this._onRx = (s) => { if (s.startsWith('tt_statusReady:true')) { clearTimeout(to); resolve(); } else if (s.startsWith('tt_statusReady:false') && !sent) { sent = true; this.send('tt_calib'); } };
        const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 2000); this._abort = reject;
        this.once('__stop', () => clearInterval(poll)); to.unref && 0; setTimeout(() => clearInterval(poll), 80000);
      });
      this.phase('idle');
    } finally { this._onRx = null; this.closeBoard(); }
  }

  /** Run one scan. Resolves {workDir, scanDir, scanDurationS, startOffsetS, loads} */
  async runScan(workDir) {
    if (this.busy) throw new Error('A scan is already running.'); this.busy = true; this.cancelled = false;
    try { return this.opts.simulate ? await this._simulate(workDir) : await this._real(workDir); }
    finally { this.busy = false; this.closeBoard(); this._onRx = null; this._abort = null; }
  }

  async _simulate(workDir) {
    let simPre = null;
    const wait = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(100); } };
    this.phase('starting', { message: 'Checking the scanner (simulation)…' }); await wait(800);
    this.phase('sensors', { message: 'Depth sensors ready.' }); await wait(1200);
    this.phase('board', { message: 'Turntable ready.' }); await wait(800);
    this.phase('armed', { message: 'Stand still and keep your hands off the handles while the scale reads your weight. (Simulation: the scan starts by itself.)' });
    for (let i = 0; i < 24; i++) { const t = 156.0 + Math.sin(i) * 0.15; this.emit('live', [30.5, 33.5, 44.0, 48.0, t, 0.09]); if (i === 7) { simPre = [30.5, 33.5, 44.0, 48.0, 156.0, 0.09]; this.phase('weighed', { kg: simPre[4] * 0.45359237, message: 'Weight captured. Now hold BOTH handle buttons to begin.' }); } await wait(500); }
    for (let n = 4; n >= 1; n--) { this.phase('countdown', { n, message: 'Hold still…' }); await wait(1000); }
    this.phase('scanning', { startedAt: Date.now(), expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' });
    const t0 = Date.now(); while (Date.now() - t0 < 38000) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(250); }
    this.phase('finishing', { message: 'Scan complete. You can let go and step off.' }); await wait(2500);
    this.phase('saving', { message: 'Saving frames…' }); await wait(1200);
    return { simulated: true, workDir, loads: [31.3, 34.6, 45.2, 47.1, 158.1, 0.091], preLoads: simPre, scanDurationS: 37.9 };
  }

  async _real(workDir) {
    fs.mkdirSync(workDir, { recursive: true });
    const sig = path.join(workDir, '_signals'); fs.mkdirSync(sig, { recursive: true });
    for (const f of ['START', 'STOP']) { try { fs.unlinkSync(path.join(sig, f)); } catch (e) { /* none */ } }
    const capPs1 = this.opts.capturePs1, ps32 = path.join(process.env.SystemRoot || 'C:\\Windows', 'SysWOW64', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const name = 'scan', capLog = path.join(workDir, `capture_${name}.log`), pkg = path.join(workDir, `pkg-${name}-raw`);
    this.phase('starting', { message: 'Checking the scanner…' });
    for (let k = 0; ; k++) { try { this.openBoard(); break; } catch (e) { if (k >= 6) throw e; await sleep(400); } }   // the scale monitor on the scan screen may still be releasing the USB device
    // capture process (the depth sensors are sometimes still busy from the previous scan: if it dies before it is ready, wait and start it again)
    let capExit = null, capDone = null;
    const startCapture = () => { capExit = null; try { fs.unlinkSync(capLog); } catch (e) { /* none */ } this.capture = cp.spawn(ps32, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', capPs1, '-Mode', 'Signal', '-ServiceDir', this.opts.serviceDir, '-OutDir', workDir, '-Name', name], { windowsHide: true }); capDone = new Promise(res => this.capture.on('exit', (c) => { capExit = c; res(c); })); };
    startCapture(); let capTries = 1;
    const abortP = new Promise((_, rej) => { this._abort = rej; });
    const guard = (p) => Promise.race([p, abortP]);
    const t0 = Date.now(); let ready = false;
    while (Date.now() - t0 < 45000 && !ready) {
      if (capExit !== null) {
        let tail = ''; try { tail = fs.readFileSync(capLog, 'utf8').trim().split(String.fromCharCode(10)).slice(-3).join(' | ').slice(0, 300); } catch (e) { /* none */ }
        this.phase('log', { message: 'depth capture exited early (try ' + capTries + ', code ' + capExit + '): ' + tail });
        if (capTries >= 3) throw new Error('The depth sensors could not be started. Check that all three sensors are plugged in.' + (tail ? ' (' + tail + ')' : ''));
        capTries++; this.phase('starting', { message: 'The depth sensors are not ready yet, trying again…' }); await sleep(2500); if (this.cancelled) throw new Error('Scan cancelled.'); startCapture(); continue;
      }
      try { ready = fs.readFileSync(capLog, 'utf8').includes('READY: streaming'); } catch (e) { /* not yet */ }
      if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(300);
    }
    if (!ready) throw new Error('The depth sensors did not become ready in time.');
    this.phase('sensors', { message: 'Depth sensors ready.' });

    const rxLog = []; const ev = { scanStart: null, scanComplete: null }; let loads = null, armed = false, homingSent = false, earlyStop = false;
    // Weight is read while the person stands still with NO hands on the handles (gripping them adds ~3 lb to the load cells).
    // Readings are kept; a stable run (>=3 readings over >=1.5 s within 0.8 lb, person on the platform) is a capture. The capture used is the last one that ended >=0.7 s before the buttons were pressed.
    // The board is NOT told the camera is ready until the weight has been read, so a grip on the buttons cannot start a scan during the weigh-in.
    let pressed = false, weighing = false, weighStart = 0, cameraSent = false, chosen = null, reads = [], recent = [];
    const LB = 0.45359237;
    const armNow = (kg, msg) => { if (cameraSent) return; cameraSent = true; weighing = false; try { this.send('tt_cameraReady'); } catch (e) { /* ignore */ } this.phase('weighed', { kg, message: msg }); };
    const onWeight = (v) => {
      if (!weighing) return; const now = Date.now(); reads.push({ t: now, v }); if (reads.length > 400) reads.shift(); recent.push({ t: now, v }); recent = recent.filter((x) => now - x.t <= 7000);   // readings may arrive only about once per poll, so the window is generous
      const w = recent.filter((x) => now - x.t <= 6000); if (w.length < 3 || w[w.length - 1].t - w[0].t < 1000) return; const tot = w.map((x) => x.v[4]); if (Math.max.apply(null, tot) - Math.min.apply(null, tot) > 3 || Math.min.apply(null, tot) < 40) return;
      const avg = [0, 1, 2, 3, 4, 5].map((i) => w.reduce((a, x) => a + (x.v[i] || 0), 0) / w.length); chosen = { loads: avg, fallback: false };
      armNow(avg[4] * LB, 'Weight captured. Now hold BOTH handle buttons to begin.');
    };
    this.on('live', onWeight);
    const waitFor = (pred, ms, what) => new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error(what)), ms); const prev = this._onRx;
      this._onRx = (s) => { if (prev) prev(s); const v = pred(s); if (v) { clearTimeout(to); this._onRx = prev; resolve(v); } };
    });
    const writeSignal = (n) => fs.writeFileSync(path.join(sig, n), new Date().toISOString());
    // state machine on board messages
    const done = new Promise((resolve, reject) => {
      this._onRx = (s) => {
        if (rxLog.length < 300) rxLog.push(s.slice(0, 80));
        if (s.startsWith('tt_statusReady:true') && !armed) { armed = true; this.phase('board', { message: 'Turntable ready.' }); weighing = true; weighStart = Date.now(); this.phase('armed', { message: 'Step onto the platform, stand on the footprints facing the pole, and stand still with your hands OFF the handles while the scale reads your weight.' }); }
        else if (s.startsWith('tt_statusReady:false') && !armed && !homingSent) { homingSent = true; this.phase('homing', { message: 'The platform is turning to its start position. Please stay OFF the platform until it stops.' }); this.send('tt_calib'); }
        else if (s === 'tt_prepScanStart') { pressed = true; this.phase('countdown', { n: 4, message: 'Hold still…' }); }
        else if (s === 'tt_noScanStart') { if (cameraSent) this.phase('weighed', { kg: chosen ? chosen.loads[4] * LB : null, message: 'Hold BOTH buttons to begin.' }); }
        else if (s === 'tt_scanStart') { ev.scanStart = Date.now(); writeSignal('START'); this.phase('scanning', { startedAt: ev.scanStart, expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' }); }
        else if (s === 'tt_scanComplete') { ev.scanComplete = Date.now(); this.phase('finishing', { message: 'Scan complete. Keep holding until the platform stops, then step off.' }); setTimeout(() => writeSignal('STOP'), this.opts.postrollMs); setTimeout(() => resolve(), 9500); }
        else if (s === 'tt_scanEarlyStop') { earlyStop = true; writeSignal('STOP'); setTimeout(() => reject(new Error('You let go of a button before the scan finished. Please try again and hold both buttons until the platform stops.')), 800); }
        else if (s.startsWith('weight=') && ev.scanStart) { const v = s.slice(7).split('-').map(parseFloat).filter(x => !isNaN(x)); if (v.length >= 5) loads = v; }   // the post-scan reading (hands on the handles); the weigh-in readings are kept separately
      };
    });
    this.send('tt_statusReady');
    let tick = 0; const poll = setInterval(() => { try { tick++; if (!pressed && (armed || tick % 4 === 0)) this.send('tt_statusReady');
      if (weighing && !cameraSent && Date.now() - weighStart > 30000) {   // no steady weight in 30 s: use the last readings if there are any, else just carry on
        const e = reads.filter((x) => x.v[4] >= 40).slice(-3); if (e.length >= 2) chosen = { loads: [0, 1, 2, 3, 4, 5].map((i) => e.reduce((a, x) => a + (x.v[i] || 0), 0) / e.length), fallback: true };
        armNow(chosen ? chosen.loads[4] * LB : null, chosen ? 'Weight read. Now hold BOTH handle buttons to begin.' : 'Could not read your weight; it will be taken after the scan. Hold BOTH handle buttons to begin.'); } } catch (e) { /* ignore */ } }, 500);   // keeps the board talking (also during the weigh-in)
    const armTimeout = setTimeout(() => { if (!ev.scanStart && !this.cancelled) this._abort(new Error('No scan was started within 3 minutes.')); }, 180000);
    try { await guard(done); } finally { clearInterval(poll); clearTimeout(armTimeout); }
    try { this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ }
    this.phase('saving', { message: 'Saving frames…' });
    await guard(Promise.race([capDone, sleep(150000).then(() => { throw new Error('Saving the depth frames took too long.'); })]));
    if (capExit !== 0 && !fs.existsSync(path.join(pkg, 'capture_meta.json'))) throw new Error('The depth capture failed.');
    // the board reports the load-cell weight a few seconds after the scan; keep listening a little longer if it has not arrived yet
    for (let i = 0; i < 30 && !loads; i++) await sleep(200);
    const meta = JSON.parse(fs.readFileSync(path.join(pkg, 'capture_meta.json'), 'utf8'));
    this.removeListener('live', onWeight); const pc = chosen;
    this.phase('log', { message: 'weigh-in: ' + reads.length + ' readings while weighing, used ' + (pc ? (pc.fallback ? 'last readings' : 'stable capture') + ' ' + pc.loads[4].toFixed(1) + ' lb' : 'none (post-scan weight)') + '; totals ' + reads.slice(0, 40).map((x) => x.v[4].toFixed(1) + '@' + Math.round((x.t - (reads[0] ? reads[0].t : 0)) / 100) / 10).join(' ') });
    return { preLoads: pc ? pc.loads : null, workDir, scanDir: pkg, scanDurationS: (ev.scanComplete - ev.scanStart) / 1000, startOffsetS: (Date.parse(meta.start_utc) - ev.scanStart) / 1000, loads, earlyStop, rx: rxLog.filter(x => !x.startsWith('tare=') && !x.startsWith('tt_statusReady')) };
  }
  killCapture() { try { if (this.capture) this.capture.kill(); } catch (e) { /* ignore */ } }
}
module.exports = { Scanner };
