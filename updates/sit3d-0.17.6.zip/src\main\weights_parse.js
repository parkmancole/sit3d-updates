'use strict';
// Reads body-weight entries out of the visible text of a nutrition app's weight page: every date with a weight next to it.
// Returns { 'YYYY-MM-DD': kg }. Node 12 compatible. hintUnit ('lb' or 'kg') is used only when the page does not say which unit it shows.
const MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const z = (n) => String(n).padStart(2, '0');
function findDate(line, refYear) {
  let m = /(20\d\d)-(\d\d)-(\d\d)/.exec(line); if (m) return { iso: m[1] + '-' + m[2] + '-' + m[3], end: m.index + m[0].length };
  m = /\b(\d{1,2})\/(\d{1,2})\/(20\d\d|\d\d)\b/.exec(line); if (m) { const y = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]); return { iso: y + '-' + z(m[1]) + '-' + z(m[2]), end: m.index + m[0].length }; }
  m = /\b(\d{1,2})\s+(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?(?:,?\s+(20\d\d))?/i.exec(line); if (m) return { iso: (m[3] || refYear) + '-' + z(MONTHS[m[2].toLowerCase()]) + '-' + z(m[1]), end: m.index + m[0].length };
  m = /\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+(\d{1,2})(?!\d)(?:st|nd|rd|th)?(?:,?\s+(20\d\d))?/i.exec(line); if (m) return { iso: (m[3] || refYear) + '-' + z(MONTHS[m[1].toLowerCase()]) + '-' + z(m[2]), end: m.index + m[0].length };
  return null;
}
const todayIso = (d) => { const z2 = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z2(d.getMonth() + 1) + '-' + z2(d.getDate()); };
let refNow = new Date();
function parseWeightText(text, hintUnit, refYear, now) {
  refNow = now || new Date();
  const out = {}; refYear = refYear || new Date().getFullYear(); const lines = String(text || '').split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  for (let i = 0; i < lines.length; i++) {
    const d = findDate(lines[i], refYear); if (!d) continue;
    // the weight is on the same line after the date, or on one of the next two lines
    const chunk = [lines[i].slice(d.end), lines[i + 1] || '', lines[i + 2] || ''];
    for (let c = 0; c < chunk.length; c++) {
      if (c > 0 && findDate(chunk[c], refYear)) break;
      const m = /(\d{2,3}(?:\.\d+)?)\s*(lbs?|pounds?|kgs?|kilograms?|st)?\b/i.exec(chunk[c]); if (!m) continue;
      let v = parseFloat(m[1]); const u = m[2] ? m[2].toLowerCase() : hintUnit;
      const kg = /^lb|^pound/.test(u || '') ? v * 0.45359237 : v;
      if (kg < 25 || kg > 320 || (/^st/.test(u || ''))) continue;
      let iso = d.iso; if (iso > todayIso(refNow)) iso = (Number(iso.slice(0, 4)) - 1) + iso.slice(4);   // 'Nov 17' with no year, read in January, is last year
      out[iso] = Math.round(kg * 10) / 10; break;
    }
  }
  return out;
}
// JSON from a nutrition site: finds a list of { date, weight } style objects anywhere in it.
function parseWeightJson(json, hintUnit) {
  const out = {}; const unit = (() => { const u = JSON.stringify(json).match(/"(?:unit|units|weight_unit)"\s*:\s*"([a-zA-Z]+)"/); return u ? u[1] : hintUnit; })();
  const walk = (o) => {
    if (Array.isArray(o)) { o.forEach(walk); return; } if (!o || typeof o !== 'object') return;
    const dk = Object.keys(o).find((k) => /date|day|when/i.test(k) && typeof o[k] === 'string'); const vk = Object.keys(o).find((k) => /^(total|value|weight|kg|lbs?|amount)$/i.test(k) && Number(o[k]) > 0);
    if (dk && vk) { const dd = findDate(o[dk], new Date().getFullYear()); if (dd) { const v = Number(o[vk]); const kg = /^lb|^pound/i.test(unit || '') ? v * 0.45359237 : v; if (kg >= 25 && kg <= 320) out[dd.iso] = Math.round(kg * 10) / 10; } }
    Object.keys(o).forEach((k) => walk(o[k]));
  };
  walk(json); return out;
}
module.exports = { parseWeightText, parseWeightJson, findDate };
