'use strict';
// Derived health/fitness estimates. Published, open methods only; ALL are estimates, not medical advice.
// Inputs: user {sex:'male'|'female', age, height_cm, weight_kg}, circumferences in cm, optional tape-calibration factors.

const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const r1 = (v) => (v == null || !isFinite(v) ? null : Math.round(v * 10) / 10);
const log10 = Math.log10;

function bmi(w, hcm) { return w / Math.pow(hcm / 100, 2); }
function bmrMifflin(sex, w, hcm, age) { return 10 * w + 6.25 * hcm - 5 * age + (sex === 'male' ? 5 : -161); }
// U.S. Navy circumference method (cm)
function bodyFatNavy(sex, hcm, neck, waist, hip) {
  if (!hcm || !neck || !waist) return null;
  if (sex === 'male') { if (waist - neck <= 0) return null; return 495 / (1.0324 - 0.19077 * log10(waist - neck) + 0.15456 * log10(hcm)) - 450; }
  if (!hip || waist + hip - neck <= 0) return null;
  return 495 / (1.29579 - 0.35004 * log10(waist + hip - neck) + 0.221 * log10(hcm)) - 450;
}
// Deurenberg: BF% = 1.20*BMI + 0.23*age - 10.8*sex(1 male) - 5.4
function bodyFatDeurenberg(sex, b, age) { return 1.2 * b + 0.23 * age - 10.8 * (sex === 'male' ? 1 : 0) - 5.4; }
function absi(waistM, b, hM) { return waistM / (Math.pow(b, 2 / 3) * Math.sqrt(hM)); }

// scan: {measure: result of measureBody (mm), loads: [w1..w4,total] (lb) | null}, calib: {site: factor} (tape calibration)
function analyse(user, scan, calib = {}, opts = {}) {
  const m = scan.measure, c = m.circumference_mm;
  const adj = (site, v) => { const c = calib && calib[site]; if (c == null) return v; if (typeof c === 'number') return v * c; return (c.a == null ? 1 : c.a) * v + (c.b || 0); };   // tape calibration: gain, or gain + offset
  const cm = (site, mm) => (mm == null ? null : adj(site, mm / 10));
  const heightCm = user.height_cm || (m.height_mm / 10);
  const weightKg = user.weight_kg_scale != null ? user.weight_kg_scale : user.weight_kg;
  const neck = cm('neck', c.neck), chest = cm('chest', c.chest), waist = cm('waist', c.waist), hips = cm('hips', c.hips);
  const thighL = cm('thigh_left', c.thigh_left), thighR = cm('thigh_right', c.thigh_right), calfL = cm('calf_left', c.calf_left), calfR = cm('calf_right', c.calf_right);
  const B = weightKg ? bmi(weightKg, heightCm) : null;
  const bmr = weightKg ? bmrMifflin(user.sex, weightKg, heightCm, user.age) : null;
  const whr = waist && hips ? waist / hips : null, whtr = waist ? waist / heightCm : null;
  // The scanner's neck reading is unreliable (jaw/head position) until the user has calibrated it against a tape measure, so Navy is skipped before that.
  const navy = calib && calib.neck ? bodyFatNavy(user.sex, heightCm, neck, waist, hips) : null;
  const deur = B != null ? bodyFatDeurenberg(user.sex, B, user.age) : null;
  let bf = null, bfMethod = null, conf = 'low';
  if (navy != null && deur != null) {
    if (Math.abs(navy - deur) <= 8 && calib && Object.keys(calib).length) { bf = (navy + deur) / 2; bfMethod = 'Navy + BMI average'; conf = 'medium'; }
    else if (Math.abs(navy - deur) <= 8) { bf = (navy + deur) / 2; bfMethod = 'Navy + BMI average'; conf = 'low'; }
    else { bf = deur; bfMethod = 'BMI-based (circumferences disagree; check clothing)'; conf = 'low'; }
  } else if (deur != null) { bf = deur; bfMethod = 'BMI-based (add tape measurements for the circumference formula)'; } else if (navy != null) { bf = navy; bfMethod = 'Navy'; }
  if (bf != null && calib && typeof calib.bf_offset === 'number') bf += clamp(calib.bf_offset, -10, 10);   // fitted against a DEXA / caliper reference
  if (bf != null) bf = clamp(bf, 3, 60);
  const fatMass = bf != null && weightKg ? weightKg * bf / 100 : null, leanMass = fatMass != null ? weightKg - fatMass : null;
  // metabolic age: age at which Mifflin-St Jeor BMR equals the lean-mass (Katch-McArdle) BMR
  let metAge = null;
  if (leanMass != null && weightKg) { const km = 370 + 21.6 * leanMass; metAge = clamp(((10 * weightKg + 6.25 * heightCm + (user.sex === 'male' ? 5 : -161)) - km) / 5, 18, 80); }
  const visceral = whtr != null ? clamp(1 + (whtr - 0.38) / 0.30 * 19, 1, 20) : null;
  let shape = null;
  if (whtr != null) {
    const s1 = clamp(100 - Math.max(0, whtr - 0.45) * 500, 0, 100);
    const t = user.sex === 'male' ? 0.90 : 0.80; const s2 = whr != null ? clamp(100 - Math.max(0, whr - t) * 400, 0, 100) : s1;
    shape = 0.6 * s1 + 0.4 * s2;
  }
  const ab = waist && weightKg ? absi(waist / 100, B, heightCm / 100) : null;
  // posture
  const p = m.posture || {};
  const flags = [];
  const f = (label, v, lim, unit, tip) => { if (v != null && Math.abs(v) > lim) flags.push({ label, value: r1(v), unit, tip }); };
  f('Forward head', p.head_forward_mm, 50, 'mm', 'Head sits ahead of the feet line. Neck and upper-back mobility work can help.');
  f('Head shift (sideways)', p.head_lateral_mm, 25, 'mm', 'Head is off-center over the feet.');
  f('Shoulder shift', p.shoulder_shift_mm, 25, 'mm', 'Shoulders are off-center over the feet.');
  f('Shoulder tilt', p.shoulder_tilt_deg, 2.5, 'deg', 'One shoulder rides higher than the other.');
  f('Hip shift', p.hip_shift_mm, 25, 'mm', 'Hips are shifted sideways relative to the feet.');
  let balance = null;
  if (scan.loads && scan.loads.length >= 5) {
    const l = scan.loads.slice(0, 4), tot = l[0] + l[1] + l[2] + l[3];
    balance = { panels_pct: l.map(v => r1(100 * v / tot)), total: scan.loads[4], pair_split_pct: [r1(100 * (l[0] + l[1]) / tot), r1(100 * (l[2] + l[3]) / tot)] };
  }
  const postureScore = clamp(100 - flags.reduce((s, x) => s + (x.label === 'Forward head' ? 10 : 8), 0), 0, 100);
  const out = {
    body: { height_cm: r1(heightCm), weight_kg: r1(weightKg), bmi: r1(B), bmr_kcal: bmr ? Math.round(bmr) : null },
    composition: { body_fat_pct: r1(bf), body_fat_method: bfMethod, confidence: conf, fat_mass_kg: r1(fatMass), lean_mass_kg: r1(leanMass), metabolic_age: metAge != null ? Math.round(metAge) : null, visceral_index: r1(visceral), shape_score: shape != null ? Math.round(shape) : null },
    ratios: { waist_to_hip: r1(whr != null ? Math.round(whr * 1000) / 1000 : null) === null ? null : Math.round(whr * 1000) / 1000, waist_to_height: whtr != null ? Math.round(whtr * 1000) / 1000 : null, absi: ab != null ? Math.round(ab * 10000) / 10000 : null },
    circumferences_cm: { neck: r1(neck), chest: r1(chest), waist: r1(waist), hips: r1(hips), thigh_left: r1(thighL), thigh_right: r1(thighR), calf_left: r1(calfL), calf_right: r1(calfR) },
    posture: { score: Math.round(postureScore), measures: p, flags },
    balance,
  };
  out.insights = insights(user, out);
  return out;
}

function insights(user, o) {
  const s = [];
  const c = o.composition, b = o.body, r = o.ratios;
  if (b.bmi != null) s.push(`Your BMI is ${b.bmi}.`);
  if (c.body_fat_pct != null) s.push(`Estimated body fat is ${c.body_fat_pct} percent (${c.confidence} confidence).`);
  if (r.waist_to_height != null) s.push(r.waist_to_height < 0.5 ? 'Your waist-to-height ratio is under 0.5, a healthy range.' : `Your waist-to-height ratio is ${r.waist_to_height}; a value under 0.5 is generally considered healthy.`);
  if (o.posture.flags.length) s.push(`Posture notes: ${o.posture.flags.map(x => x.label.toLowerCase()).join(', ')}.`); else s.push('No major posture flags in this scan.');
  return s;
}

module.exports = { analyse, bmi, bmrMifflin, bodyFatNavy, bodyFatDeurenberg };
