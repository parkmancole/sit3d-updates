(function () {
'use strict';
// Charts (SVG) and the 3D point-cloud viewer (canvas).
const S3 = window.S3;

// ---- charts ----
S3.sparkline = (vals, color = '#F58220') => {
  const v = vals.filter(x => x != null); if (v.length < 2) return '';
  const mn = Math.min(...v), mx = Math.max(...v), r = mx - mn || 1; const w = 90, h = 34;
  const pts = vals.map((x, i) => (x == null ? null : [i / (vals.length - 1) * (w - 6) + 3, h - 4 - ((x - mn) / r) * (h - 8)])).filter(Boolean);
  return `<svg class="spark" viewBox="0 0 ${w} ${h}"><polyline points="${pts.map(p => p.join(',')).join(' ')}" fill="none" stroke="${color}" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="${pts[pts.length - 1][0]}" cy="${pts[pts.length - 1][1]}" r="3.4" fill="${color}"/></svg>`;
};
S3.lineChart = (points, o = {}) => {       // points: [{t: ISO, v: number|null}]
  const pts = points.filter(p => p.v != null); const W = o.w || 860, H = o.h || 300, L = 54, R = 22, T = 18, B = 36;
  if (!pts.length) return '<div class="empty"><div class="big">No data yet</div>Complete a scan to start your history.</div>';
  const ys = pts.map(p => p.v); let mn = Math.min(...ys), mx = Math.max(...ys); if (mn === mx) { mn -= 1; mx += 1; } const pad = (mx - mn) * 0.18; mn -= pad; mx += pad;
  const ts = pts.map(p => new Date(p.t).getTime()), t0 = Math.min(...ts), t1 = Math.max(...ts); const span = t1 - t0 || 1;
  const X = (t) => (pts.length === 1 ? (L + (W - L - R) / 2) : L + ((new Date(t).getTime() - t0) / span) * (W - L - R)), Y = (v) => T + (1 - (v - mn) / (mx - mn)) * (H - T - B);
  const col = o.color || '#F58220', id = 'g' + Math.random().toString(36).slice(2, 7); let grid = '';
  for (let i = 0; i <= 4; i++) { const v = mn + (mx - mn) * i / 4, y = Y(v); grid += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="#F3E8DB"/><text x="${L - 10}" y="${y + 4}" text-anchor="end">${v.toFixed(o.dec == null ? 1 : o.dec)}</text>`; }
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.t).toFixed(1)},${Y(p.v).toFixed(1)}`).join(' ');
  const area = pts.length > 1 ? `${line} L${X(pts[pts.length - 1].t).toFixed(1)},${H - B} L${X(pts[0].t).toFixed(1)},${H - B} Z` : '';
  // date labels: first, last, and middle ones only when there is room, so they can never overlap
  const labs = []; { const xp = (p) => X(p.t), gap = Math.round(W * 0.17); if (pts.length === 1) labs.push(pts[0]); else { const first = pts[0], last = pts[pts.length - 1]; labs.push(first); for (let q = 1; q <= 3; q++) { const p = pts[Math.round((pts.length - 1) * q / 4)]; if (p !== first && p !== last && xp(p) - xp(labs[labs.length - 1]) >= gap && xp(last) - xp(p) >= gap) labs.push(p); } if (xp(last) - xp(first) >= gap) labs.push(last); } }
  const xl = labs.map((p, i) => `<text x="${X(p.t)}" y="${H - 10}" text-anchor="${pts.length === 1 ? 'middle' : (i === 0 ? 'start' : i === labs.length - 1 ? 'end' : 'middle')}">${S3.fmtDate(p.t)}</text>`).join('');
  const dotPts = pts.length <= 45 ? pts : [pts[pts.length - 1]];   // a long series is drawn as a clean line with just its latest point marked
  const dots = dotPts.map(p => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="5.5" fill="#fff" stroke="${col}" stroke-width="3"><title>${S3.fmtDate(p.t)}: ${p.v.toFixed(o.dec == null ? 1 : o.dec)} ${S3.esc(o.unit || '')}</title></circle>`).join('');
  return `<svg class="chart" viewBox="0 0 ${W} ${H}"><defs><linearGradient id="${id}" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="${col}" stop-opacity=".30"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></linearGradient></defs>${grid}${xl}${area ? `<path d="${area}" fill="url(#${id})"/>` : ''}${pts.length > 1 ? `<path d="${line}" fill="none" stroke="${col}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round"/>` : ''}${dots}</svg>`;
};
S3.gauge = (pct) => `<div class="gauge"><i style="left:${Math.max(2, Math.min(98, pct))}%"></i></div>`;
S3.ring = (frac, size = 240, stroke = 16) => { const r = (size - stroke) / 2, c = 2 * Math.PI * r; return `<svg viewBox="0 0 ${size} ${size}" width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#F3E6D6" stroke-width="${stroke}"/><circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#F58220" stroke-width="${stroke}" stroke-linecap="round" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - Math.max(0, Math.min(1, frac)))}"/></svg>`; };

// ---- 3D viewer ----
S3.Viewer = class {
  constructor(host, pts) {
    this.host = host; this.pts = pts; this.n = pts.length / 3; this.az = 0; this.el = 0.08; this.zoom = 1; this.auto = true; this.alive = true; this.drag = null;
    host.innerHTML = '<canvas></canvas><div class="hint">Drag to rotate · scroll to zoom</div><div class="vb"><button class="pill" data-v="front">Front</button><button class="pill" data-v="side">Side</button><button class="pill" data-v="back">Back</button></div>';
    this.cv = host.querySelector('canvas'); this.g = this.cv.getContext('2d');
    let zmax = 0; for (let i = 2; i < pts.length; i += 3) zmax = Math.max(zmax, pts[i]); this.H = zmax || 1700;
    // centre on the body's own x/y centroid
    let sx = 0, sy = 0, c = 0; for (let i = 0; i < pts.length; i += 3) if (pts[i + 2] > 200) { sx += pts[i]; sy += pts[i + 1]; c++; } this.cx = sx / (c || 1); this.cy = sy / (c || 1);
    this.cv.addEventListener('pointerdown', (e) => { this.drag = { x: e.clientX, az: this.az }; this.auto = false; this.cv.setPointerCapture(e.pointerId); });
    this.cv.addEventListener('pointermove', (e) => { if (this.drag) { this.az = this.drag.az + (e.clientX - this.drag.x) * 0.01; } });
    this.cv.addEventListener('pointerup', () => { this.drag = null; });
    this.cv.addEventListener('wheel', (e) => { e.preventDefault(); this.zoom = Math.max(0.6, Math.min(3, this.zoom * (e.deltaY < 0 ? 1.1 : 0.9))); }, { passive: false });
    host.querySelectorAll('[data-v]').forEach(b => b.addEventListener('click', () => { this.auto = false; this.az = { front: 0, side: Math.PI / 2, back: Math.PI }[b.dataset.v]; }));
    this.loop = this.loop.bind(this); requestAnimationFrame(this.loop);
  }
  destroy() { this.alive = false; }
  loop() {
    if (!this.alive || !this.host.isConnected) return; requestAnimationFrame(this.loop);
    const dpr = Math.min(2, window.devicePixelRatio || 1), w = this.host.clientWidth, h = this.host.clientHeight;
    if (this.cv.width !== Math.round(w * dpr) || this.cv.height !== Math.round(h * dpr)) { this.cv.width = Math.round(w * dpr); this.cv.height = Math.round(h * dpr); }
    const W = this.cv.width, Hh = this.cv.height; if (this.auto) this.az += 0.007;
    const img = this.g.createImageData(W, Hh), d = new Uint32Array(img.data.buffer); const zb = new Float32Array(W * Hh).fill(-1e9);
    const sc = (Hh * 0.86 / this.H) * this.zoom, ca = Math.cos(this.az), sa = Math.sin(this.az), ce = Math.cos(this.el), se = Math.sin(this.el);
    const ox = W / 2, oy = Hh * 0.5 + (this.H * sc) * 0.5 * 0.96, p = this.pts, r2 = Math.max(1, Math.ceil(8 * sc));
    for (let i = 0; i < p.length; i += 3) {
      const x = p[i] - this.cx, y = p[i + 1] - this.cy, z = p[i + 2];
      const xr = ca * x - sa * y, yr = sa * x + ca * y;           // yaw about the vertical axis
      const depth = yr * ce - z * se;                               // away from the viewer (+)
      const sx = Math.round(ox + xr * sc), sy = Math.round(oy - (z * ce + yr * se) * sc);
      const t = z / this.H, shade = Math.max(0.35, Math.min(1, 0.95 - depth / 900));
      const R = Math.round(255 * shade), G = Math.round((120 + 90 * t) * shade), Bc = Math.round((30 + 60 * t) * shade), col = (255 << 24) | (Bc << 16) | (G << 8) | R;
      for (let dy = 0; dy < r2 + 1; dy++) for (let dx = 0; dx < r2 + 1; dx++) { const X = sx + dx, Y = sy + dy; if (X < 0 || X >= W || Y < 0 || Y >= Hh) continue; const k = Y * W + X; if (-depth > zb[k]) { zb[k] = -depth; d[k] = col; } }
    }
    this.g.putImageData(img, 0, 0);
  }
};


// ---- on-screen PIN pad (touch friendly; physical number keys work too) ----
S3.pinPad = (name, max = 8) => `<div class="pinpad" data-max="${max}"><input type="hidden" name="${name}" value=""><div class="dots" data-hint="4 to ${max} digits"></div><div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => `<button type="button" class="pk" data-k="${n}">${n}</button>`).join('')}<button type="button" class="pk fn" data-k="back" aria-label="Delete">⌫</button><button type="button" class="pk" data-k="0">0</button><button type="button" class="pk fn ok" data-k="ok" aria-label="Done">✓</button></div></div>`;
(function pinHandlers() {
  const paint = (pad) => { const v = pad.querySelector('input').value; pad.querySelector('.dots').innerHTML = v.split('').map(() => '<i class="on"></i>').join(''); };
  const press = (pad, k) => {
    const inp = pad.querySelector('input'), max = +pad.dataset.max || 8;
    if (k === 'back') inp.value = inp.value.slice(0, -1);
    else if (k === 'ok') { const f = pad.closest('form'); if (f) { if (f.requestSubmit) f.requestSubmit(); else f.dispatchEvent(new Event('submit', { cancelable: true })); } return; }
    else if (inp.value.length < max) inp.value += k;
    if (S3.sfx && S3.sfx.key && k !== 'ok') { try { S3.sfx.key(); } catch (e) { /* ignore */ } }
    paint(pad);
  };
  let lastDown = 0;
  document.addEventListener('pointerdown', (e) => { const b = e.target.closest && e.target.closest('.pk'); if (!b) return; const pad = b.closest('.pinpad'); if (!pad) return; lastDown = Date.now(); e.preventDefault(); press(pad, b.dataset.k); }, true);
  document.addEventListener('click', (e) => { const b = e.target.closest && e.target.closest('.pk'); if (!b) return; if (Date.now() - lastDown < 700) { e.preventDefault(); return; } const pad = b.closest('.pinpad'); if (pad) press(pad, b.dataset.k); });
  document.addEventListener('keydown', (e) => {
    const t = e.target; if (t && t.matches && t.matches('input:not([type=hidden]),textarea,select')) return;
    const pad = document.querySelector('.pinpad'); if (!pad) return;
    if (/^[0-9]$/.test(e.key)) { press(pad, e.key); e.preventDefault(); } else if (e.key === 'Backspace') { press(pad, 'back'); e.preventDefault(); } else if (e.key === 'Enter') { press(pad, 'ok'); e.preventDefault(); }
  });
  S3.pinReset = (root) => { (root || document).querySelectorAll('.pinpad').forEach(p => { p.querySelector('input').value = ''; paint(p); }); };
})();


// ---- on-screen number pad for every numeric input (height, weight, tape measurements...) ----
(function numPad() {
  let pad = null, target = null;
  const el = () => {
    if (pad) return pad;
    pad = document.createElement('div'); pad.id = 'numpad'; pad.className = 'numpad';
    pad.innerHTML = '<div class="npd-top"><span class="npd-label"></span><button type="button" class="npd-done" data-k="done">Done</button></div><div class="npd-grid">' + [1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => '<button type="button" data-k="' + n + '">' + n + '</button>').join('') + '<button type="button" data-k=".">.</button><button type="button" data-k="0">0</button><button type="button" class="fn" data-k="back" aria-label="Delete">\u232B</button></div>';
    document.body.appendChild(pad);
    const act = (k) => {
      if (!target) return;
      if (k === 'done') { target.blur(); hide(); return; }
      let v = String(target.value || '');
      if (target._fresh && k !== 'back') v = '';   // first key replaces the old value
      target._fresh = false;
      if (k === 'back') v = v.slice(0, -1);
      else if (k === '.') { if (v.indexOf('.') < 0) v = (v === '' ? '0' : v) + '.'; }
      else if (v.length < 7) v += k;
      target.value = v; target.dispatchEvent(new Event('input', { bubbles: true }));
    };
    pad.addEventListener('pointerdown', (e) => { const b = e.target.closest('button'); if (!b) return; e.preventDefault(); act(b.dataset.k); });
    pad.addEventListener('mousedown', (e) => e.preventDefault());
    return pad;
  };
  const hide = () => { if (pad) pad.classList.remove('show'); document.body.classList.remove('has-numpad'); target = null; };
  document.addEventListener('focusin', (e) => {
    const t = e.target;
    if (!(t && t.tagName === 'INPUT' && (t.type === 'number' || t.dataset.num))) { if (!(e.target.closest && e.target.closest('#numpad'))) hide(); return; }
    if (t.type === 'number') { t.type = 'text'; t.dataset.num = '1'; }
    t.setAttribute('inputmode', 'none'); target = t; t._fresh = !!t.value;
    const p = el(); const lab = t.closest('label'); p.querySelector('.npd-label').textContent = (lab ? lab.childNodes[0].textContent : (t.placeholder || '')).trim().slice(0, 60);
    p.classList.add('show'); document.body.classList.add('has-numpad');
    setTimeout(() => { try { t.scrollIntoView({ block: 'center' }); } catch (err) { /* ignore */ } }, 60);
  });
  document.addEventListener('focusout', (e) => { setTimeout(() => { const a = document.activeElement; if (!a || a === document.body) hide(); }, 80); });
})();

})();
