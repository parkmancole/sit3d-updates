'use strict';
// Scanner controller: turntable (USB HID, node-hid) + depth capture (32-bit PowerShell child, Capture-Depth.ps1). Emits 'phase' events.
// Phases: starting -> sensors -> board -> homing? -> armed -> countdown -> scanning -> finishing -> saving -> done | error
const { EventEmitter } = require('events');
const fs = require('fs'), path = require('path'), cp = require('child_process');

let HID = null; try { HID = require('node-hid'); } catch (e) { HID = null; }
const VID = 5824, PID = 1158, UPAGE = 65451, USAGE = 512;
const ALLOWED = new Set(['tt_statusReady', 'tt_calib', 'tt_cameraReady', 'tt_resetCameraReady']);
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

class Scanner extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.opts = Object.assign({ serviceDir: 'C:\\Apps\\ProScanner\\Service', postrollMs: 3000, simulate: false }, opts);
    this.dev = null; this.capture = null; this.cancelled = false; this.busy = false;
  }
  phase(phase, extra = {}) { this.emit('phase', Object.assign({ phase, t: Date.now() }, extra)); }
  hardwareAvailable() {
    if (!HID) return { ok: false, why: 'USB library not available' };
    try { const d = HID.devices().find(x => x.vendorId === VID && x.productId === PID && x.usagePage === UPAGE && x.usage === USAGE); return d ? { ok: true, path: d.path } : { ok: false, why: 'Turntable not found (is the scanner plugged in and powered?)' }; }
    catch (e) { return { ok: false, why: String(e.message || e) }; }
  }
  openBoard() {
    const a = this.hardwareAvailable(); if (!a.ok) throw new Error(a.why);
    this.dev = new HID.HID(a.path); this.dev.on('data', (buf) => this._rx(buf)); this.dev.on('error', (e) => this.phase('log', { message: 'USB error: ' + e }));
  }
  closeBoard() { try { if (this.dev) this.dev.close(); } catch (e) { /* ignore */ } this.dev = null; }
  send(cmd) {
    if (!ALLOWED.has(cmd)) throw new Error('command not allowed: ' + cmd);
    const a = [0]; for (const c of cmd) a.push(c.charCodeAt(0)); while (a.length < 64) a.push(0);
    this.dev.write(a);
  }
  _rx(buf) {
    let s = ''; for (const b of buf) if (b > 39 && b < 127) s += String.fromCharCode(b);
    this.emit('rx', s); if (this._onRx) this._onRx(s);
    if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) this.emit('live', v); }   // also while armed / scanning
  }
  // Passive scale monitor for the scan screen: opens the board, sends only the harmless tt_statusReady, and forwards every weight= message the board reports.
  // (The firmware decides when it reports weight; if it stays silent while idle the screen simply shows no reading.)
  monitor(onLive) {
    if (this.opts.simulate || this.busy) return () => {};
    this.openBoard(); try { this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ } let n = 0; const t0 = Date.now();
    this._onRx = (s) => { if (s.startsWith('weight=')) { const v = s.slice(7).split('-').map(parseFloat).filter((x) => !isNaN(x)); if (v.length >= 5) { n++; onLive(v); } } };
    const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 3000);
    return () => { clearInterval(poll); this._onRx = null; this.closeBoard(); return { seen: n, seconds: Math.round((Date.now() - t0) / 1000) }; };
  }
  // Guided scale test: four ~26 s rounds, each "step OFF the platform" (6 s) then "step ON and stand still, hands off the handles" (20 s), recording EVERY board message with its round.
  // Rounds differ in how the board is treated: listen only / statusReady every 3 s / every 0.3 s / armed (tt_cameraReady) + every 3 s. Ends with tt_resetCameraReady.
  async scaleTest(onPhase) {
    if (this.busy) throw new Error('A scan is running.'); this.openBoard(); const out = []; const t0 = Date.now(); let round = 0;
    this._onRx = (s) => { if (out.length < 800) out.push({ t: Date.now() - t0, r: round, s: s.slice(0, 90) }); };
    const rounds = [{ label: 'listen only', poll: 0, arm: false }, { label: 'status poll every 3 s', poll: 3000, arm: false }, { label: 'status poll every 0.3 s', poll: 300, arm: false }, { label: 'armed + poll every 3 s', poll: 3000, arm: true }];
    try {
      for (let i = 0; i < rounds.length; i++) {
        round = i + 1; const R = rounds[i]; try { this.send(R.arm ? 'tt_cameraReady' : 'tt_resetCameraReady'); } catch (e) { /* ignore */ }
        let last = 0; const pump = async (ms, step) => { const e0 = Date.now(); while (Date.now() - e0 < ms) { if (R.poll && Date.now() - last >= R.poll) { last = Date.now(); try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } } if (onPhase) onPhase({ round, of: rounds.length, label: R.label, step, left: Math.ceil((ms - (Date.now() - e0)) / 1000) }); await sleep(250); } };
        await pump(6000, 'off'); await pump(20000, 'on');
      }
    } finally { try { this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ } this._onRx = null; this.closeBoard(); }
    return out;
  }
  cancel() { this.cancelled = true; if (this._abort) this._abort(new Error('Scan cancelled.')); }

  async rehome() {
    if (this.opts.simulate) { this.phase('homing', { message: 'Re-homing the turntable (simulated).' }); await sleep(2500); this.phase('idle'); return; }
    this.openBoard();
    try {
      this.phase('homing', { message: 'The platform is turning back to its start position. Stay clear of it.' });
      await new Promise((resolve, reject) => {
        const to = setTimeout(() => reject(new Error('Homing timed out.')), 80000); let sent = false;
        this._onRx = (s) => { if (s.startsWith('tt_statusReady:true')) { clearTimeout(to); resolve(); } else if (s.startsWith('tt_statusReady:false') && !sent) { sent = true; this.send('tt_calib'); } };
        const poll = setInterval(() => { try { this.send('tt_statusReady'); } catch (e) { /* ignore */ } }, 2000); this._abort = reject;
        this.once('__stop', () => clearInterval(poll)); to.unref && 0; setTimeout(() => clearInterval(poll), 80000);
      });
      this.phase('idle');
    } finally { this._onRx = null; this.closeBoard(); }
  }

  /** Run one scan. Resolves {workDir, scanDir, scanDurationS, startOffsetS, loads} */
  async runScan(workDir) {
    if (this.busy) throw new Error('A scan is already running.'); this.busy = true; this.cancelled = false;
    try { return this.opts.simulate ? await this._simulate(workDir) : await this._real(workDir); }
    finally { this.busy = false; try { if (this.dev) this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ } this.closeBoard();   // never leave the board armed after a failed or cancelled scan (an armed board may stop reporting weight)
      this._onRx = null; this._abort = null; }
  }

  async _simulate(workDir) {
    let simPre = null;
    const wait = async (ms) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(100); } };
    this.phase('starting', { message: 'Checking the scanner (simulation)…' }); await wait(800);
    this.phase('sensors', { message: 'Depth sensors ready.' }); await wait(1200);
    this.phase('board', { message: 'Turntable ready.' }); await wait(800);
    this.phase('armed', { message: 'Stand still and keep your hands off the handles while the scale reads your weight. (Simulation: the scan starts by itself.)' });
    for (let i = 0; i < 6; i++) { this.emit('live', [30.5, 33.5, 44.0, 48.0, 156.0 + Math.sin(i) * 0.15, 0.09]); await wait(500); }
    for (let n = 5; n >= 1; n--) { this.phase('weighcount', { n, message: 'Hold still. Hands off the handles.' }); for (let k = 0; k < 2; k++) { this.emit('live', [30.5, 33.5, 44.0, 48.0, 156.0, 0.09]); await wait(500); } }
    simPre = [30.5, 33.5, 44.0, 48.0, 156.0, 0.09]; this.phase('weighed', { kg: simPre[4] * 0.45359237, message: 'Weight captured. Now hold BOTH handle buttons to begin.' }); await wait(4000);
    for (let n = 4; n >= 1; n--) { this.phase('countdown', { n, message: 'Hold still…' }); await wait(1000); }
    this.phase('scanning', { startedAt: Date.now(), expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' });
    const t0 = Date.now(); while (Date.now() - t0 < 38000) { if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(250); }
    this.phase('finishing', { message: 'Scan complete. You can let go and step off.' }); await wait(2500);
    this.phase('saving', { message: 'Saving frames…' }); await wait(1200);
    return { simulated: true, workDir, loads: [31.3, 34.6, 45.2, 47.1, 158.1, 0.091], preLoads: simPre, scanDurationS: 37.9 };
  }

  async _real(workDir) {
    fs.mkdirSync(workDir, { recursive: true });
    const sig = path.join(workDir, '_signals'); fs.mkdirSync(sig, { recursive: true });
    for (const f of ['START', 'STOP']) { try { fs.unlinkSync(path.join(sig, f)); } catch (e) { /* none */ } }
    const capPs1 = this.opts.capturePs1, ps32 = path.join(process.env.SystemRoot || 'C:\\Windows', 'SysWOW64', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const name = 'scan', capLog = path.join(workDir, `capture_${name}.log`), pkg = path.join(workDir, `pkg-${name}-raw`);
    this.phase('starting', { message: 'Checking the scanner…' });
    for (let k = 0; ; k++) { try { this.openBoard(); try { this.send('tt_resetCameraReady'); } catch (e2) { /* ignore */ } break; } catch (e) { if (k >= 6) throw e; await sleep(400); } }   // the scale monitor on the scan screen may still be releasing the USB device
    // capture process (the depth sensors are sometimes still busy from the previous scan: if it dies before it is ready, wait and start it again)
    let capExit = null, capDone = null;
    const startCapture = () => { capExit = null; try { fs.unlinkSync(capLog); } catch (e) { /* none */ } this.capture = cp.spawn(ps32, ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-File', capPs1, '-Mode', 'Signal', '-ServiceDir', this.opts.serviceDir, '-OutDir', workDir, '-Name', name], { windowsHide: true }); capDone = new Promise(res => this.capture.on('exit', (c) => { capExit = c; res(c); })); };
    startCapture(); let capTries = 1;
    const abortP = new Promise((_, rej) => { this._abort = rej; });
    const guard = (p) => Promise.race([p, abortP]);
    const t0 = Date.now(); let ready = false;
    while (Date.now() - t0 < 45000 && !ready) {
      if (capExit !== null) {
        let tail = ''; try { tail = fs.readFileSync(capLog, 'utf8').trim().split(String.fromCharCode(10)).slice(-3).join(' | ').slice(0, 300); } catch (e) { /* none */ }
        this.phase('log', { message: 'depth capture exited early (try ' + capTries + ', code ' + capExit + '): ' + tail });
        if (capTries >= 3) throw new Error('The depth sensors could not be started. Check that all three sensors are plugged in.' + (tail ? ' (' + tail + ')' : ''));
        capTries++; this.phase('starting', { message: 'The depth sensors are not ready yet, trying again…' }); await sleep(2500); if (this.cancelled) throw new Error('Scan cancelled.'); startCapture(); continue;
      }
      try { ready = fs.readFileSync(capLog, 'utf8').includes('READY: streaming'); } catch (e) { /* not yet */ }
      if (this.cancelled) throw new Error('Scan cancelled.'); await sleep(300);
    }
    if (!ready) throw new Error('The depth sensors did not become ready in time.');
    this.phase('sensors', { message: 'Depth sensors ready.' });

    const rxLog = []; const ev = { scanStart: null, scanComplete: null }; let loads = null, armed = false, homingSent = false, earlyStop = false;
    // Weight is read while the person stands still with NO hands on the handles (gripping them adds ~3 lb to the load cells).
    // Readings are kept; a stable run (>=3 readings over >=1.5 s within 0.8 lb, person on the platform) is a capture. The capture used is the last one that ended >=0.7 s before the buttons were pressed.
    // WEIGH-IN. Log evidence from the tablet: the board does NOT stream weight; it sends one weight= when the settled load CHANGES (step-on, re-settle, gripping the handles),
    // and in practice only while armed (tt_cameraReady sent). So: arm, prompt to step on; the first reading >= 50 lb starts a 5..1 "hold still, hands off the handles" countdown;
    // a reading that differs by > 4 lb during it (still settling / moved) restarts it; a reading < 40 lb (stepped off) goes back to the prompt. At 0 the weight is the average of the
    // last readings of the countdown (the board only speaks on change, so these are the standing weight). If the buttons are gripped before a weight was taken the scan FAILS afterwards.
    let pressed = false, weighing = false, weighStart = 0, hinted = false, chosen = null, reads = [], counting = false, cdStart = 0, cdReads = [], cdLast = 0, restarts = 0, gripEarly = false;
    const LB = 0.45359237;
    const armNow = (kg, msg) => { weighing = false; this.phase('weighed', { kg, message: msg }); };
    const startCount = (r) => { counting = true; cdStart = Date.now(); cdReads = [r]; cdLast = 5; this.phase('weighcount', { n: 5, message: 'Hold still. Hands off the handles.' }); };
    const onWeight = (v) => {
      if (!weighing) return; const now = Date.now(), r = { t: now, v }; reads.push(r); if (reads.length > 600) reads.shift(); const tot = v[4];
      if (tot < 40) { if (counting) { counting = false; restarts++; this.phase('armed', { message: 'You stepped off. Step back on, stand still, hands off the handles.' }); } return; }
      if (!counting) { if (tot >= 50) startCount(r); return; }
      const prev = cdReads[cdReads.length - 1].v[4]; if (Math.abs(tot - prev) > 4) { restarts++; if (restarts > 8) { this._abort(new Error('Could not get a steady weight. Stand completely still and try again.')); return; } startCount(r); return; }
      cdReads.push(r);
    };
    const weighTick = () => {   // runs every 250 ms while weighing
      if (!weighing) return; const now = Date.now();
      if (!counting) {
        if (!hinted && now - weighStart > 15000) { hinted = true; this.phase('armed', { message: 'No weight detected yet. If you are already standing on the platform, step off and back on, then stand still, hands off the handles.' }); }
        if (now - weighStart > 120000) this._abort(new Error(reads.length ? 'No weight of 50 lb or more was detected on the platform. Step on and try again.' : 'The scale is not reporting any weight. Step off and back on the platform, then try again.'));
        return;
      }
      const el = now - cdStart, n = Math.max(1, 5 - Math.floor(el / 1000)); if (el < 5000) { if (n !== cdLast) { cdLast = n; this.phase('weighcount', { n, message: 'Hold still. Hands off the handles.' }); } return; }
      const use = cdReads.slice(-3), avg = [0, 1, 2, 3, 4, 5].map((i) => use.reduce((a, x) => a + (x.v[i] || 0), 0) / use.length);
      chosen = { loads: avg, n: use.length }; armNow(avg[4] * LB, 'Weight captured. Now hold BOTH handle buttons to begin.');
    };
    this.on('live', onWeight);
    const waitFor = (pred, ms, what) => new Promise((resolve, reject) => {
      const to = setTimeout(() => reject(new Error(what)), ms); const prev = this._onRx;
      this._onRx = (s) => { if (prev) prev(s); const v = pred(s); if (v) { clearTimeout(to); this._onRx = prev; resolve(v); } };
    });
    const writeSignal = (n) => fs.writeFileSync(path.join(sig, n), new Date().toISOString());
    // state machine on board messages
    const done = new Promise((resolve, reject) => {
      this._onRx = (s) => {
        if (rxLog.length < 300) rxLog.push(s.slice(0, 80));
        if (s.startsWith('tt_statusReady:true') && !armed) { armed = true; this.phase('board', { message: 'Turntable ready.' }); weighing = true; weighStart = Date.now(); this.send('tt_cameraReady'); this.phase('armed', { message: 'Step onto the platform, stand on the footprints facing the pole, and stand still with your hands OFF the handles while the scale reads your weight.' }); }
        else if (s.startsWith('tt_statusReady:false') && !armed && !homingSent) { homingSent = true; this.phase('homing', { message: 'The platform is turning to its start position. Please stay OFF the platform until it stops.' }); this.send('tt_calib'); }
        else if (s === 'tt_prepScanStart') { pressed = true; if (!chosen) gripEarly = true; weighing = false; counting = false; this.phase('countdown', { n: 4, message: 'Hold still…' }); }
        else if (s === 'tt_noScanStart') { if (chosen) this.phase('weighed', { kg: chosen.loads[4] * LB, message: 'Hold BOTH buttons to begin.' }); }
        else if (s === 'tt_scanStart') { ev.scanStart = Date.now(); writeSignal('START'); this.phase('scanning', { startedAt: ev.scanStart, expectedS: 38, message: 'Scanning — keep holding the buttons until the platform stops.' }); }
        else if (s === 'tt_scanComplete') { ev.scanComplete = Date.now(); this.phase('finishing', { message: 'Scan complete. Keep holding until the platform stops, then step off.' }); setTimeout(() => writeSignal('STOP'), this.opts.postrollMs); setTimeout(() => resolve(), 9500); }
        else if (s === 'tt_scanEarlyStop') { earlyStop = true; writeSignal('STOP'); setTimeout(() => reject(new Error('You let go of a button before the scan finished. Please try again and hold both buttons until the platform stops.')), 800); }
        else if (s.startsWith('weight=') && ev.scanStart) { const v = s.slice(7).split('-').map(parseFloat).filter(x => !isNaN(x)); if (v.length >= 5) loads = v; }   // the post-scan reading (hands on the handles); the weigh-in readings are kept separately
      };
    });
    this.send('tt_statusReady');
    let tick = 0; const poll = setInterval(() => { try { tick++; if (!pressed && tick % (armed ? 10 : 7) === 0) this.send('tt_statusReady');   // slow polling (3 s armed, ~2 s before), like the scan-screen monitor where live weight worked; fast polling may starve the board's weight reports } catch (e) { /* ignore */ } }, 300);   // keeps the board talking (also during the weigh-in)
    const wt = setInterval(weighTick, 250);
    const armTimeout = setTimeout(() => { if (!ev.scanStart && !this.cancelled) this._abort(new Error('No scan was started within 3 minutes.')); }, 180000);
    try { await guard(done); } finally { clearInterval(poll); clearInterval(wt); clearTimeout(armTimeout); this.removeListener('live', onWeight); this.phase('log', { message: 'weigh-in: ' + reads.length + ' readings, ' + restarts + ' restarts, ' + (chosen ? 'took ' + chosen.loads[4].toFixed(1) + ' lb from ' + chosen.n + ' readings' : 'no weight taken') + '; first totals ' + reads.slice(0, 40).map((x) => x.v[4].toFixed(1) + '@' + Math.round((x.t - reads[0].t) / 100) / 10).join(' ') }); }
    if (gripEarly || !chosen) throw new Error('Your weight was not taken before the scan started (the handles were gripped too early). Try again, and wait for "Weight captured" before touching the handles.');
    try { this.send('tt_resetCameraReady'); } catch (e) { /* ignore */ }
    this.phase('saving', { message: 'Saving frames…' });
    await guard(Promise.race([capDone, sleep(150000).then(() => { throw new Error('Saving the depth frames took too long.'); })]));
    if (capExit !== 0 && !fs.existsSync(path.join(pkg, 'capture_meta.json'))) throw new Error('The depth capture failed.');
    // the board reports the load-cell weight a few seconds after the scan; keep listening a little longer if it has not arrived yet
    for (let i = 0; i < 30 && !loads; i++) await sleep(200);
    const meta = JSON.parse(fs.readFileSync(path.join(pkg, 'capture_meta.json'), 'utf8'));
    this.removeListener('live', onWeight); const pc = chosen;
    return { preLoads: pc ? pc.loads : null, workDir, scanDir: pkg, scanDurationS: (ev.scanComplete - ev.scanStart) / 1000, startOffsetS: (Date.parse(meta.start_utc) - ev.scanStart) / 1000, loads, earlyStop, rx: rxLog.filter(x => !x.startsWith('tare=') && !x.startsWith('tt_statusReady')) };
  }
  killCapture() { try { if (this.capture) this.capture.kill(); } catch (e) { /* ignore */ } }
}
module.exports = { Scanner };
