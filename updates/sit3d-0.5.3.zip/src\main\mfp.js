'use strict';
// MyFitnessPal sync WITHOUT CSV files and without an official API (MyFitnessPal's API is closed to individual developers).
// The user signs in to myfitnesspal.com inside an app window (so passwords, captchas and 2-step logins are handled by MyFitnessPal itself;
// S*it3D never sees or stores the password). The browser session stays in a private per-user profile, and the app then reads the user's own
// food diary pages the same way their browser would. This is unofficial: it can stop working if MyFitnessPal changes its pages, and the
// user should be comfortable with MyFitnessPal's terms of service for their own data.
const { BrowserWindow, session } = require('electron');

const partitionFor = (userId) => 'persist:mfp-' + userId;
const DIARY = (iso) => 'https://www.myfitnesspal.com/food/diary?date=' + iso;

// Runs inside the diary page. Returns the day's totals mapped by column header.
const EXTRACT = `(() => {
  const txt = (el) => (el ? el.textContent.replace(/\\s+/g, ' ').trim() : '');
  const num = (s) => { const m = String(s).replace(/,/g, '').match(/-?[0-9]+(\\.[0-9]+)?/); return m ? parseFloat(m[0]) : null; };
  const url = location.href;
  if (/account\\/login|\\/login|oauth/.test(url)) return { ok: false, needLogin: true };
  const total = document.querySelector('tr.total');
  if (!total) return { ok: false, noDiary: true, title: document.title };
  const hdr = document.querySelector('tr.meal_header');
  let cols = hdr ? Array.from(hdr.querySelectorAll('td')).slice(1).map((td) => txt(td).toLowerCase()) : [];
  if (!cols.length || cols.length < 4) cols = ['calories', 'carbs', 'fat', 'protein', 'sodium', 'sugar'];
  const cells = Array.from(total.querySelectorAll('td')).slice(1);
  const vals = cells.map((td) => { const mv = td.querySelector('.macro-value'); return num(mv ? mv.textContent : td.textContent); });
  const out = {};
  cols.forEach((c, i) => { if (vals[i] != null) out[c.split(' ')[0].replace(/[^a-z]/g, '')] = vals[i]; });
  return { ok: true, totals: out, cols };
})()`;

function mapTotals(t) {
  const g = (...k) => { for (const x of k) if (t[x] != null) return t[x]; return 0; };
  return { kcal: g('calories', 'energy'), carbs: g('carbs', 'carbohydrates'), fat: g('fat'), protein: g('protein'), sodium: g('sodium'), sugar: g('sugar'), fiber: g('fiber'), n: 1 };
}

function hiddenWindow(userId) {
  return new BrowserWindow({ show: false, width: 1100, height: 900, webPreferences: { partition: partitionFor(userId), nodeIntegration: false, contextIsolation: true, enableRemoteModule: false } });
}

async function readDay(win, iso) {
  try { await win.loadURL(DIARY(iso)); } catch (e) { if (!/ERR_ABORTED/.test(String(e.message))) throw new Error('Could not reach MyFitnessPal (' + String(e.message).slice(0, 80) + ').'); }
  return win.webContents.executeJavaScript(EXTRACT);
}

// Opens the login window. Resolves true once the diary can be read, false if the window is closed first.
function connect(parent, userId) {
  return new Promise((resolve) => {
    const w = new BrowserWindow({ parent, modal: !!parent, width: 1000, height: 780, title: 'Log in to MyFitnessPal', autoHideMenuBar: true, webPreferences: { partition: partitionFor(userId), nodeIntegration: false, contextIsolation: true, enableRemoteModule: false } });
    let done = false, checking = false;
    const finish = (ok) => { if (done) return; done = true; try { w.destroy(); } catch (e) { /* closed */ } resolve(ok); };
    const check = async () => {
      if (done || checking) return; const u = w.webContents.getURL();
      if (!/^https:\/\/([a-z0-9-]+\.)*myfitnesspal\.com\//.test(u) || /account\/login|account\/create|oauth|signup|sso/.test(u)) return;
      checking = true;
      try { const h = hiddenWindow(userId); const r = await readDay(h, new Date().toISOString().slice(0, 10)); try { h.destroy(); } catch (e) { /* ignore */ } if (r && r.ok) finish(true); } catch (e) { /* keep waiting */ }
      checking = false;
    };
    w.webContents.on('did-navigate', check); w.webContents.on('did-navigate-in-page', check); w.webContents.on('did-finish-load', check);
    w.on('closed', () => { if (!done) { done = true; resolve(false); } });
    w.loadURL('https://www.myfitnesspal.com/account/login').catch(() => { /* handled by window events */ });
  });
}

function localIso(d) { const z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); }
function addDays(iso, n) { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return localIso(d); }

// Reads every day from `fromIso` to today. onDays(daysObject) is called with batches so partial progress is saved.
async function sync(userId, fromIso, onProgress, onDays) {
  const today = localIso(new Date()); const win = hiddenWindow(userId); const days = {}; let errors = 0, read = 0, noData = 0;
  const total = Math.max(1, Math.round((new Date(today + 'T12:00:00') - new Date(fromIso + 'T12:00:00')) / 86400000) + 1);
  try {
    for (let d = fromIso, i = 0; d <= today; d = addDays(d, 1), i++) {
      let r = null;
      try { r = await readDay(win, d); } catch (e) { errors++; if (errors >= 4) throw new Error('MyFitnessPal stopped answering. Try again later.'); await new Promise(x => setTimeout(x, 3000)); continue; }
      if (r && r.needLogin) throw new Error('NEED_LOGIN');
      if (r && r.ok) { errors = 0; const m = mapTotals(r.totals); if (m.kcal > 0) { days[d] = m; read++; } else noData++; }
      else if (r && r.noDiary) { errors++; if (errors >= 4) throw new Error('The MyFitnessPal diary page looks different than expected, so syncing stopped.'); }
      if (onProgress) onProgress({ p: (i + 1) / total, day: d });
      if (Object.keys(days).length >= 10 && onDays) { onDays(days); for (const k of Object.keys(days)) delete days[k]; }
      await new Promise(x => setTimeout(x, 1200));
    }
    if (onDays && Object.keys(days).length) onDays(days);
    return { read, noData, from: fromIso, to: today };
  } finally { try { win.destroy(); } catch (e) { /* ignore */ } }
}

async function disconnect(userId) { try { await session.fromPartition(partitionFor(userId)).clearStorageData(); } catch (e) { /* ignore */ } }

module.exports = { connect, sync, disconnect, EXTRACT, mapTotals, localIso, addDays, partitionFor };
