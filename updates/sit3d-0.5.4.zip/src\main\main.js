'use strict';
const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const path = require('path'), fs = require('fs'), cp = require('child_process');
const store = require('./store.js');
function rmrf(p) { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } }

const { Scanner } = require('./scanner.js');
const { analyse } = require('../pipeline/analysis.js');
const nutrition = require('./nutrition.js');
const { Updater } = require('./updater.js');
const mfp = require('./mfp.js');
const mnd = require('./mynetdiary.js');
const PROVIDERS = { mfp: { mod: mfp, name: 'MyFitnessPal', backDays: 90 }, mnd: { mod: mnd, name: 'MyNetDiary', backDays: 60 } };
const prov = (k) => { const p = PROVIDERS[k]; if (!p) throw new Error('Unknown nutrition app.'); return p; };

if (process.env.SIT3D_SHOTS) app.commandLine.appendSwitch('mute-audio');   // the developer self-test must never make noise on the user's PC
app.setName('sit3d');
app.setPath('userData', path.join(app.getPath('appData'), process.env.SIT3D_DATA_NAME || 'sit3d'));   // '*' is not allowed in Windows folder names
const DATA = process.env.SIT3D_DATA || app.getPath('userData');
const APP_ROOT = path.join(__dirname, '..', '..');
const LBS = 0.45359237;
const APP_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(APP_ROOT, 'package.json'), 'utf8')).version; } catch (e) { return '0.0.0'; } })();
let updater = null;
function logLine(msg) { try { const d = path.join(DATA, 'logs'); fs.mkdirSync(d, { recursive: true }); const f = path.join(d, 'sit3d.log'); try { if (fs.statSync(f).size > 1500000) fs.renameSync(f, f + '.old'); } catch (e) { /* none */ } fs.appendFileSync(f, new Date().toISOString() + ' ' + msg + '\n'); } catch (e) { /* never break the app for logging */ } }
let win = null, session = { userId: null }, scanner = null, scannerCfg = null;

const scannerFile = () => path.join(DATA, 'scanner.json');
function loadScannerCfg() { try { return JSON.parse(fs.readFileSync(scannerFile(), 'utf8')); } catch (e) { return { fxScale: 1, serviceDir: 'C:\\Apps\\ProScanner\\Service', keepRaw: true, simulate: false }; } }
function saveScannerCfg() { fs.writeFileSync(scannerFile(), JSON.stringify(scannerCfg, null, 1)); }
const send = (ch, payload) => { if (win && !win.isDestroyed()) win.webContents.send(ch, payload); };
const me = () => { if (!session.userId) throw new Error('Please sign in.'); const u = store.getUser(session.userId); if (!u) throw new Error('Session expired.'); return u; };
const wrap = (fn) => async (ev, ...a) => { try { return { ok: true, data: await fn(...a) }; } catch (e) { logLine('ERROR ' + String(e && e.stack || e).split('\n').slice(0, 4).join(' | ')); return { ok: false, error: String(e && e.message || e) }; } };

function summary(s) {
  const a = s.analysis || {};
  return { id: s.id, created: s.created, source: s.source, weight_kg: s.weight_kg, bmi: a.body && a.body.bmi, body_fat_pct: a.composition && a.composition.body_fat_pct, lean_mass_kg: a.composition && a.composition.lean_mass_kg, shape_score: a.composition && a.composition.shape_score, posture_score: a.posture && a.posture.score, waist_cm: a.circumferences_cm && a.circumferences_cm.waist, hips_cm: a.circumferences_cm && a.circumferences_cm.hips, chest_cm: a.circumferences_cm && a.circumferences_cm.chest, neck_cm: a.circumferences_cm && a.circumferences_cm.neck, thigh_cm: a.circumferences_cm && a.circumferences_cm.thigh_left, calf_cm: a.circumferences_cm && a.circumferences_cm.calf_left, metabolic_age: a.composition && a.composition.metabolic_age, visceral: a.composition && a.composition.visceral_index, height_cm: a.body && a.body.height_cm };
}

// ---- processing ----
function runWorker(spec, onProgress) {
  return new Promise((resolve, reject) => {
    const specFile = path.join(spec.outDir, 'spec.json'); fs.mkdirSync(spec.outDir, { recursive: true }); fs.writeFileSync(specFile, JSON.stringify(spec));
    const child = cp.spawn(process.execPath, [path.join(APP_ROOT, 'src', 'pipeline', 'run.js'), specFile], { env: Object.assign({}, process.env, { ELECTRON_RUN_AS_NODE: '1' }), windowsHide: true });
    let buf = '', err = '';
    child.stdout.on('data', (d) => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1); if (line.startsWith('PROGRESS ')) { try { onProgress(JSON.parse(line.slice(9))); } catch (e) { /* ignore */ } } else if (line.startsWith('ERROR ')) err = line.slice(6); } });
    child.stderr.on('data', (d) => { err += d; });
    child.on('exit', (code) => { if (code !== 0) return reject(new Error('Processing failed: ' + err.slice(0, 400))); try { resolve({ pipeline: JSON.parse(fs.readFileSync(path.join(spec.outDir, 'pipeline.json'), 'utf8')), viewFile: path.join(spec.outDir, 'view.bin') }); } catch (e) { reject(e); } });
  });
}
function buildScan(user, id, source, pipelineRes, extra) {
  const loads = extra.loads || null;
  let near = null; try { near = nutrition.nearestWeight(store.getNutrition(user.id).weights, extra.created || new Date().toISOString(), 4); } catch (e) { /* none */ }
  const weightKg = loads && loads[4] ? loads[4] * LBS : (extra.weight_kg || near || user.weight_kg || null);
  const measure = pipelineRes.pipeline.measure;
  const u = Object.assign({}, user, { age: store.ageFromDob(user.dob), weight_kg: weightKg });
  const analysis = analyse(u, { measure, loads }, user.calib || {});
  return { id, userId: user.id, created: extra.created || new Date().toISOString(), source, timing: extra.timing || null, loads, weight_kg: weightKg ? Math.round(weightKg * 10) / 10 : null, measure, analysis, info: pipelineRes.pipeline.info, tape: extra.tape || null, hasRaw: !!extra.hasRaw };
}
async function processAndSave(user, spec, extra, source) {
  const id = store.newScanId(); const tmp = path.join(DATA, 'tmp', id); spec.outDir = tmp;
  logLine('processing ' + spec.mode + ' scan ' + id); const res = await runWorker(spec, (p) => send('scan:progress', p));
  const scan = buildScan(user, id, source, res, extra); logLine('processed ' + id + ' height_mm=' + scan.measure.height_mm + ' waist_mm=' + (scan.measure.circumference_mm || {}).waist + ' fov=' + JSON.stringify(res.pipeline.info && res.pipeline.info.fov));
  const viewBuf = fs.readFileSync(res.viewFile); const view = new Int16Array(viewBuf.buffer, viewBuf.byteOffset, viewBuf.length / 2);
  const dir = store.saveScan(user.id, scan, view);
  if (extra.rawDir && scannerCfg.keepRaw) { try { fs.renameSync(extra.rawDir, path.join(dir, 'raw')); scan.hasRaw = true; store.updateScan(user.id, id, { hasRaw: true }); } catch (e) { /* keep going */ } }
  rmrf(tmp);
  return scan;
}

function ipc() {
  ipcMain.handle('app:info', wrap(async () => ({ version: APP_VERSION, appRoot: APP_ROOT, dataDir: DATA, hardware: Scanner.prototype.hardwareAvailable.call({}), users: store.userCount(), scanner: scannerCfg, user: session.userId ? store.getUser(session.userId) : null })));
  ipcMain.handle('auth:signup', wrap(async (f) => { const u = store.signup(f); session.userId = u.id; return u; }));
  ipcMain.handle('auth:login', wrap(async (n, p) => { const u = store.login(n, p); session.userId = u.id; autoSyncSoon(u.id); return u; }));
  ipcMain.handle('update:status', wrap(async () => updater ? updater.status() : { enabled: false, current: APP_VERSION }));
  ipcMain.handle('update:check', wrap(async () => { if (!updater) throw new Error('Updates are not available.'); await updater.check(); return updater.status(); }));
  ipcMain.handle('update:restart', wrap(async () => { if (scanner && scanner.busy) throw new Error('A scan is running. Restart after it finishes.'); app.relaunch(); app.exit(0); return true; }));
  // ---- live nutrition-app sync (MyFitnessPal, MyNetDiary; unofficial, see mfp.js / mynetdiary.js) ----
  ipcMain.handle('sync:status', wrap(async (k) => { const u = me(); return Object.assign({ running: syncRunning.has(u.id + k) }, store.getSync(u.id, k)); }));
  ipcMain.handle('sync:connect', wrap(async (k) => {
    const u = me(); const P = prov(k); const ok = await P.mod.connect(win, u.id);
    if (!ok) return { connected: false };
    store.setSync(u.id, k, { connected: true, since: new Date().toISOString(), error: null }); logLine(k + ' connected'); setTimeout(() => runSync(k, u.id, P.backDays).catch(() => {}), 500); return { connected: true };
  }));
  ipcMain.handle('sync:run', wrap(async (k, days) => { const u = me(); await runSync(k, u.id, days || null); return store.getSync(u.id, k); }));
  ipcMain.handle('sync:disconnect', wrap(async (k) => { const u = me(); await prov(k).mod.disconnect(u.id); store.setSync(u.id, k, { connected: false, error: null }); logLine(k + ' disconnected'); return true; }));
  ipcMain.handle('auth:users', wrap(async () => store.listUsers()));
  ipcMain.handle('auth:deleteAccount', wrap(async (pin) => { const u = me(); store.login(u.id, pin); store.deleteUser(u.id); logLine('account deleted'); session.userId = null; return true; }));
  ipcMain.handle('scans:setWeight', wrap(async (id, kg) => {
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.'); kg = Number(kg); if (!(kg >= 25 && kg <= 300)) throw new Error('Enter a weight between 25 and 300 kg (55 to 660 lb).');
    const uu = Object.assign({}, store.getUser(u.id), { age: store.ageFromDob(u.dob), weight_kg: kg });
    const analysis = analyse(uu, { measure: r.scan.measure, loads: r.scan.loads }, u.calib || {});
    store.updateScan(u.id, id, { analysis, weight_kg: Math.round(kg * 10) / 10, weight_source: 'entered' }); return store.getScan(u.id, id);
  }));
  ipcMain.handle('nutrition:get', wrap(async () => { const u = me(); const n = store.getNutrition(u.id); const sc = store.listScans(u.id); const last = sc.length ? sc[sc.length - 1].weight_kg : null; return { summary: nutrition.summarize(n, new Date().toISOString().slice(0, 10), last || u.weight_kg), imports: n.imports, weightLogs: Object.keys(n.weights).length }; }));
  ipcMain.handle('nutrition:import', wrap(async () => {
    const u = me(); const r = await dialog.showOpenDialog(win, { title: 'Choose nutrition or weight CSV exports', properties: ['openFile', 'multiSelections'], filters: [{ name: 'CSV exports', extensions: ['csv'] }] });
    if (r.canceled || !r.filePaths.length) return { canceled: true };
    const results = [];
    for (const f of r.filePaths) { try { const parsed = nutrition.parseExport(fs.readFileSync(f, 'utf8'), u.units === 'imperial' ? 'lb' : 'kg'); store.mergeNutrition(u.id, parsed, path.basename(f)); results.push({ file: path.basename(f), ok: true, kind: parsed.kind, days: Object.keys(parsed.days).length, weights: Object.keys(parsed.weights).length }); } catch (e) { results.push({ file: path.basename(f), ok: false, error: e.message }); } }
    logLine('nutrition import: ' + results.map(x => x.file + ':' + (x.ok ? 'ok' : 'fail')).join(', ')); return { results };
  }));
  ipcMain.handle('nutrition:clear', wrap(async () => { store.clearNutrition(me().id); return true; }));
  ipcMain.handle('auth:logout', wrap(async () => { session.userId = null; return true; }));
  ipcMain.handle('user:update', wrap(async (patch) => store.updateUser(me().id, patch)));
  ipcMain.handle('scans:list', wrap(async () => store.listScans(me().id).map(summary)));
  ipcMain.handle('scans:get', wrap(async (id) => { const r = store.getScan(me().id, id); if (!r) throw new Error('Scan not found.'); return r; }));
  ipcMain.handle('scans:delete', wrap(async (id) => { store.deleteScan(me().id, id); return true; }));
  ipcMain.handle('scans:tape', wrap(async (id, tape) => {   // tape measurements (cm) -> per-site calibration factors for this user
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.');
    const c = r.scan.measure.circumference_mm, calib = Object.assign({}, u.calib || {}); const map = { neck: 'neck', chest: 'chest', waist: 'waist', hips: 'hips', thigh_left: 'thigh_left', thigh_right: 'thigh_right', calf_left: 'calf_left', calf_right: 'calf_right' };
    for (const k of Object.keys(map)) { const t = Number(tape[k]); if (t > 10 && c[k]) calib[k] = Math.round((t * 10 / c[k]) * 1000) / 1000; }
    store.updateUser(u.id, { calib });
    const user2 = store.getUser(u.id); const uu = Object.assign({}, user2, { age: store.ageFromDob(user2.dob), weight_kg: r.scan.weight_kg });
    const analysis = analyse(uu, { measure: r.scan.measure, loads: r.scan.loads }, calib);
    store.updateScan(u.id, id, { analysis, tape }); return { calib, analysis };
  }));
  ipcMain.handle('scans:reprocess', wrap(async (id) => {
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.');
    const raw = path.join(store.scanPath(u.id, id), 'raw'); if (!fs.existsSync(raw)) throw new Error('This scan has no saved raw frames.');
    const t = r.scan.timing || {}; const tmp = path.join(DATA, 'tmp', id + '_re');
    const res = await runWorker({ mode: 'raw', scanDir: raw, scanDurationS: t.scanDurationS, startOffsetS: t.startOffsetS, fxScale: scannerCfg.fxScale, outDir: tmp }, (p) => send('scan:progress', p));
    const upd = buildScan(store.getUser(u.id), id, r.scan.source, res, { loads: r.scan.loads, timing: t, created: r.scan.created, tape: r.scan.tape, hasRaw: true });
    const vb = fs.readFileSync(res.viewFile); store.saveScan(u.id, upd, new Int16Array(vb.buffer, vb.byteOffset, vb.length / 2)); rmrf(tmp); return upd;
  }));
  ipcMain.handle('scan:demo', wrap(async () => { const u = me(); send('scan:progress', { p: 0, msg: 'Starting' }); return processAndSave(u, { mode: 'demo', demoFile: path.join(APP_ROOT, 'demo', 'demo_body.f32') }, { loads: [31.3, 34.6, 45.2, 47.1, 158.1, 0.091] }, 'demo'); }));
  ipcMain.handle('scan:start', wrap(async (mode) => {
    const u = me(); if (scanner && scanner.busy) throw new Error('A scan is already running.');
    scanner = new Scanner({ serviceDir: scannerCfg.serviceDir, capturePs1: path.join(APP_ROOT, 'hardware', 'Capture-Depth.ps1'), simulate: mode === 'simulate' });
    scanner.on('phase', (p) => { logLine('phase ' + p.phase + (p.message ? ' - ' + p.message : '')); send('scan:phase', p); });
    const work = path.join(DATA, 'tmp', 'live_' + store.newScanId());
    try {
      logLine('scan:start mode=' + mode + ' user=' + u.username); const r = await scanner.runScan(work); logLine('scanner done: duration=' + r.scanDurationS + ' offset=' + r.startOffsetS + ' loads=' + JSON.stringify(r.loads) + ' rx=' + JSON.stringify(r.rx || []));
      send('scan:phase', { phase: 'processing', message: 'Building your 3D model…' });
      let scan;
      if (r.simulated) scan = await processAndSave(u, { mode: 'demo', demoFile: path.join(APP_ROOT, 'demo', 'demo_body.f32') }, { loads: r.loads, timing: { scanDurationS: r.scanDurationS } }, 'simulated');
      else scan = await processAndSave(u, { mode: 'raw', scanDir: r.scanDir, scanDurationS: r.scanDurationS, startOffsetS: r.startOffsetS, fxScale: scannerCfg.fxScale }, { loads: r.loads, timing: { scanDurationS: r.scanDurationS, startOffsetS: r.startOffsetS }, rawDir: r.scanDir }, 'scanner');
      send('scan:phase', { phase: 'done', scanId: scan.id }); return scan;
    } catch (e) { scanner.killCapture(); send('scan:phase', { phase: 'error', message: String(e.message || e) }); throw e; }
    finally { try { rmrf(work); } catch (e) { /* ignore */ } }
  }));
  ipcMain.handle('scan:cancel', wrap(async () => { if (scanner) scanner.cancel(); return true; }));
  ipcMain.handle('scanner:rehome', wrap(async () => { const s = new Scanner({ simulate: scannerCfg.simulate }); s.on('phase', (p) => send('scan:phase', p)); await s.rehome(); return true; }));
  ipcMain.handle('scanner:config', wrap(async (patch) => { Object.assign(scannerCfg, patch || {}); saveScannerCfg(); return scannerCfg; }));
  ipcMain.handle('scanner:calibrateScale', wrap(async (id) => {   // adjust focal-length scale so this scan's measured height matches the user's entered height
    const u = me(); const r = store.getScan(u.id, id); if (!r) throw new Error('Scan not found.');
    const hm = r.scan.measure.height_mm, ht = u.height_cm * 10; if (!hm) throw new Error('No height measured.');
    const k = Math.max(0.8, Math.min(1.25, ht / hm)); scannerCfg.fxScale = Math.round((scannerCfg.fxScale / k) * 10000) / 10000; saveScannerCfg();
    return { fxScale: scannerCfg.fxScale, factor: k };
  }));
}

const syncRunning = new Set();
async function runSync(k, userId, backDays) {
  const P = prov(k); const key = userId + k;
  if (syncRunning.has(key)) return;
  const st = store.getSync(userId, k); if (!st.connected) return;
  syncRunning.add(key); send('sync:progress', { app: k, running: true, p: 0 });
  try {
    const today = P.mod.localIso(new Date());
    const from = backDays ? P.mod.addDays(today, -(backDays - 1)) : (st.lastDate ? P.mod.addDays(st.lastDate, -3) : P.mod.addDays(today, -(P.backDays - 1)));
    const r = await P.mod.sync(userId, from, (p) => send('sync:progress', { app: k, running: true, p: p.p, day: p.day }), (days) => store.mergeDays(userId, days));
    store.setSync(userId, k, { lastSync: new Date().toISOString(), lastDate: today, error: null, lastRead: r.read }); logLine(k + ' sync ok: ' + r.read + ' days with data (' + r.from + ' to ' + r.to + ')');
  } catch (e) {
    const need = e.message === 'NEED_LOGIN'; const msg = need ? P.name + ' asked for a new login. Please connect again.' : e.message;
    store.setSync(userId, k, need ? { connected: false, error: msg } : { error: e.message }); logLine(k + ' sync failed: ' + e.message);
    throw new Error(msg);
  } finally { syncRunning.delete(key); send('sync:progress', { app: k, running: false, p: 1 }); }
}
function autoSyncSoon(userId) { setTimeout(() => { for (const k of Object.keys(PROVIDERS)) { const st = store.getSync(userId, k); if (st.connected && (!st.lastSync || Date.now() - Date.parse(st.lastSync) > 3 * 3600 * 1000)) runSync(k, userId, null).catch(() => {}); } }, 20000); }

function createWindow() {
  win = new BrowserWindow({ width: 1320, height: 860, minWidth: 1024, minHeight: 700, backgroundColor: '#FFF7EF', title: 'S*it3D', show: false, autoHideMenuBar: true, webPreferences: { nodeIntegration: true, contextIsolation: false, enableRemoteModule: false, spellcheck: false } });
  Menu.setApplicationMenu(null);
  win.webContents.on('console-message', (e, level, msg, line, src) => { if (level >= 2) logLine('renderer ' + msg + ' (' + path.basename(src || '') + ':' + line + ')'); });
  win.loadFile(path.join(APP_ROOT, 'src', 'renderer', 'index.html'));
  win.once('ready-to-show', () => win.show());
  win.webContents.once('did-finish-load', () => setTimeout(() => { try { if (global.__sit3d && global.__sit3d.markGood) global.__sit3d.markGood(); } catch (e) { /* ignore */ } }, 6000));
  win.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11') win.setFullScreen(!win.isFullScreen()); if (i.type === 'keyDown' && i.control && i.shift && i.key === 'I') win.webContents.toggleDevTools(); });
}

if (!app.requestSingleInstanceLock()) { app.quit(); }
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  app.whenReady().then(() => {
    store.init(DATA); scannerCfg = loadScannerCfg();
    let pkgUrl = ''; try { pkgUrl = JSON.parse(fs.readFileSync(path.join(APP_ROOT, 'package.json'), 'utf8')).sit3dUpdateUrl || ''; } catch (e) { /* none */ }
    const codeDir = global.__sit3d ? global.__sit3d.codeDir : path.join(process.env.LOCALAPPDATA || DATA, 'sit3d', 'code');
    updater = new Updater({ url: process.env.SIT3D_UPDATE_URL || scannerCfg.updateUrl || pkgUrl, currentVersion: APP_VERSION, codeDir, log: logLine });
    ipc(); createWindow(); updater.start((a) => send('update:ready', a)); logLine('S*it3D started, data=' + DATA + ' hid=' + JSON.stringify(Scanner.prototype.hardwareAvailable.call({})));
    if (process.env.SIT3D_SHOTS) require('./autotest.js').run({ win, DATA, send, ipcMain });
  });
  app.on('window-all-closed', () => app.quit());
}
