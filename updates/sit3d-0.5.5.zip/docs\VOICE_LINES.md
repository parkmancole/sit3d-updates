# s*it3d voice lines

Generate each line once with a good text-to-speech voice (same voice and settings for all), export as **MP3** (or WAV), and name the file exactly as below.
Put the files in the folder `%APPDATA%\sit3d\voice\` on the scanner PC (create the folder if it does not exist). No reinstall is needed; the app picks them up the next time a line plays.
If a file is missing, the app falls back to the Windows voice for that line.

| File name | Line to record | When it plays |
|---|---|---|
| `voice_on.mp3` | Voice guidance is on. | Ticking the voice checkbox |
| `homing.mp3` | Please stay off the platform while it lines itself up. | Platform turning to its start mark |
| `armed.mp3` | Step onto the platform. Face the pole, and hold both handle buttons. | Scanner ready |
| `n3.mp3` | Three. | Countdown |
| `n2.mp3` | Two. | Countdown |
| `n1.mp3` | One. | Countdown |
| `scanning.mp3` | Scanning. Stay perfectly still. | Scan begins |
| `done.mp3` | Scan complete. Keep holding until the platform stops, then you can step off. | Scan finished |
| `results.mp3` | Your results are ready. | Results shown |
| `retry.mp3` | That scan didn't finish. Please try again. | Error / let go early |

Tips: keep clips short (under 5 s), trim leading silence, normalise to the same loudness, and a calm, clear, slightly upbeat voice works best.

## Built-in voice
The app ships with neural voice clips (Piper, voice: Cartesia Skylar) in the app's `voice` folder. Your own files in `%APPDATA%\sit3doice\` take priority over them. Candidate voices for the 'armed' line are in `voice_samples/`.
