'use strict';
// MyNetDiary live sync (unofficial; MyNetDiary has no public API). Same approach as mfp.js: the user signs in to mynetdiary.com inside an
// app window (the app never sees the password), the browser session lives in a private per-user profile, and the app then reads the
// user's own food-diary day totals by stepping back through the diary page, exactly as a person would.
const { BrowserWindow, session } = require('electron');

const partitionFor = (userId) => 'persist:mnd-' + userId;
const DIARY = 'https://www.mynetdiary.com/meals.do';

// Runs inside the diary page and returns the totals currently shown (the selected day).
const EXTRACT = `(() => {
  const t = document.body ? document.body.innerText : '';
  const label = t.split('Calorie Budget')[0].trim().split('\\n')[0].slice(0, 40);
  const m = /Eaten\\s+([0-9,]+)/.exec(t);
  if (!m) return { ok: false, label };
  const g = (name) => { const r = new RegExp(name + '\\\\s+([0-9,.]+)\\\\s+(?:left|over|target|no target)').exec(t); return r ? parseFloat(r[1].replace(/,/g, '')) : 0; };
  // individual foods: each meal section lists "<name, serving>" followed by ten values (calories, carbs, protein, fat, grade, sat fat, trans fat, fiber, sodium, calcium)
  const items = []; const parts = t.split(/(?:^|\\n)[ \\t]*(BREAKFAST|LUNCH|DINNER|SNACKS)[ \\t]*\\n/);
  const isNum = (x) => /^-?[0-9][0-9,]*(\\.[0-9]+)?$/.test(x); const isVal = (x) => isNum(x) || /^[A-F][+-]?$/.test(x) || x === '-' || x === '';
  for (let k = 1; k < parts.length; k += 2) {
    const meal = parts[k].charAt(0) + parts[k].slice(1).toLowerCase(); const lines = parts[k + 1].split('\\n').map((x) => x.trim());
    const clean = lines.filter((x) => x !== '' && x.indexOf('\\t') < 0);
    for (let i = 0; i + 10 < clean.length; i++) {
      const nm = clean[i]; if (isVal(nm) || /^(ADD|search|DONE|DETAILS|CANCEL)$/.test(nm) || nm.length < 2) continue;
      const v = clean.slice(i + 1, i + 11); if (!v.every(isVal) || !isNum(v[0])) continue;
      const n = (x) => (isNum(x) ? parseFloat(x.replace(/,/g, '')) : 0);
      items.push({ meal, name: nm, kcal: n(v[0]), carbs: n(v[1]), protein: n(v[2]), fat: n(v[3]), fiber: n(v[7]), sodium: n(v[8]), sugar: 0 }); i += 10;
    }
  }
  return { ok: true, label, kcal: parseFloat(m[1].replace(/,/g, '')), carbs: g('Carbs'), protein: g('Protein'), fat: g('Total Fat'), fiber: g('Fiber'), sodium: g('Sodium'), items };
})()`;
const CLICK_PREV = `(() => { const b = document.querySelector('[aria-label="Go to Previous day"],[title="Go to Previous day"]'); if (b) { b.click(); return true; } return false; })()`;

const sleep = (ms) => new Promise(r => setTimeout(r, ms));
function hiddenWindow(userId) { return new BrowserWindow({ show: false, width: 1200, height: 900, webPreferences: { partition: partitionFor(userId), nodeIntegration: false, contextIsolation: true, enableRemoteModule: false } }); }
const chromeUa = (wc) => wc.getUserAgent().replace(/ Electron\/[0-9.]+/, '').replace(/ sit3d\/[0-9.]+/i, '');

async function waitDiary(win, ms) {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { const r = await win.webContents.executeJavaScript(EXTRACT).catch(() => null); if (r && r.ok) return r; await sleep(500); }
  return null;
}

// Opens the login window. Resolves true once the diary can be read, false if the window is closed first.
function connect(parent, userId) {
  return new Promise((resolve) => {
    const w = new BrowserWindow({ parent, modal: !!parent, width: 1000, height: 780, title: 'Log in to MyNetDiary', autoHideMenuBar: true, webPreferences: { partition: partitionFor(userId), nodeIntegration: false, contextIsolation: true, enableRemoteModule: false } });
    w.webContents.setUserAgent(chromeUa(w.webContents));
    let done = false, checking = false;
    const finish = (ok) => { if (done) return; done = true; try { w.destroy(); } catch (e) { /* closed */ } resolve(ok); };
    const check = async () => {
      if (done || checking) return; const u = w.webContents.getURL();
      if (!/^https:\/\/([a-z0-9-]+\.)*mynetdiary\.com\/(dashboard|meals|plan|settings|analysis)\.do/.test(u)) return;
      checking = true;
      try { const r = await waitDiary(w, 1500) || (await w.loadURL(DIARY).then(() => waitDiary(w, 15000)).catch(() => null)); if (r && r.ok) finish(true); } catch (e) { /* keep waiting */ }
      checking = false;
    };
    w.webContents.on('did-navigate', check); w.webContents.on('did-navigate-in-page', check); w.webContents.on('did-finish-load', check);
    w.on('closed', () => { if (!done) { done = true; resolve(false); } });
    w.loadURL('https://www.mynetdiary.com/').catch(() => { /* handled by window events */ });
  });
}

function localIso(d) { const z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); }
function addDays(iso, n) { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return localIso(d); }

// Reads each day from today back to fromIso by stepping the diary's date selector.
async function sync(userId, fromIso, onProgress, onDays) {   // onDays(days, foods)
  const today = localIso(new Date()); const win = hiddenWindow(userId); win.webContents.setUserAgent(chromeUa(win.webContents));
  const total = Math.max(1, Math.round((new Date(today + 'T12:00:00') - new Date(fromIso + 'T12:00:00')) / 86400000) + 1);
  const days = {}, foods = {}; let read = 0, noData = 0;
  try {
    await win.loadURL(DIARY).catch(() => { /* redirects to login are handled below */ });
    let cur = await waitDiary(win, 20000);
    if (!cur) throw new Error('NEED_LOGIN');
    for (let i = 0; i < total; i++) {
      const d = addDays(today, -i);
      if (cur.kcal > 0) { days[d] = { kcal: cur.kcal, carbs: cur.carbs, protein: cur.protein, fat: cur.fat, fiber: cur.fiber, sodium: cur.sodium, sugar: 0, n: 1 }; foods[d] = cur.items || []; read++; } else noData++;
      if (onProgress) onProgress({ p: (i + 1) / total, day: d });
      if (Object.keys(days).length >= 10 && onDays) { onDays(days, foods); for (const k of Object.keys(days)) delete days[k]; for (const k of Object.keys(foods)) delete foods[k]; }
      if (i === total - 1) break;
      const before = cur.label;
      const clicked = await win.webContents.executeJavaScript(CLICK_PREV);
      if (!clicked) throw new Error('The MyNetDiary diary page looks different than expected, so syncing stopped.');
      // wait for the date label to change, then for the numbers to settle
      let next = null; const t0 = Date.now();
      while (Date.now() - t0 < 8000) { await sleep(350); const r = await win.webContents.executeJavaScript(EXTRACT).catch(() => null); if (r && r.ok && r.label !== before) { next = r; break; } }
      if (!next) throw new Error('MyNetDiary did not change day as expected, so syncing stopped.');
      await sleep(500);
      const settled = await win.webContents.executeJavaScript(EXTRACT).catch(() => null); cur = settled && settled.ok ? settled : next;
    }
    if (onDays && Object.keys(days).length) onDays(days, foods);
    return { read, noData, from: fromIso, to: today };
  } finally { try { win.destroy(); } catch (e) { /* ignore */ } }
}

async function disconnect(userId) { try { await session.fromPartition(partitionFor(userId)).clearStorageData(); } catch (e) { /* ignore */ } }

module.exports = { connect, sync, disconnect, EXTRACT, localIso, addDays, partitionFor };
