'use strict';
// Signed automatic updates for S*it3D (no admin, no installer).
// Checks <updateUrl>/manifest.json (+ manifest.sig, an ed25519 signature over the exact manifest bytes), downloads the zip it names,
// verifies size + SHA-256, unpacks it to %LOCALAPPDATA%\sit3d\code\<version> and tells boot.js to use it on the next start.
// Only versions signed with the private key held by the developer are ever installed. Node 12 compatible.
const fs = require('fs'), path = require('path'), crypto = require('crypto'), cp = require('child_process');
const https = require('https'), http = require('http'), { URL } = require('url');

const PUBKEY_FILE = path.join(__dirname, 'update_pub.pem');
const MAX_ZIP = 80 * 1024 * 1024;

function cmpVer(a, b) { const x = String(a).split('.').map(n => parseInt(n, 10) || 0), y = String(b).split('.').map(n => parseInt(n, 10) || 0); for (let i = 0; i < 4; i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d < 0 ? -1 : 1; } return 0; }

function fetchBuf(urlStr, maxBytes, redirects) {
  return new Promise((resolve, reject) => {
    let u; try { u = new URL(urlStr); } catch (e) { return reject(new Error('Bad update address.')); }
    const local = u.hostname === '127.0.0.1' || u.hostname === 'localhost';
    if (u.protocol !== 'https:' && !(u.protocol === 'http:' && local)) return reject(new Error('Updates must use https.'));
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.get(u, { headers: { 'User-Agent': 'sit3d-updater', 'Cache-Control': 'no-cache' }, timeout: 20000 }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && (redirects || 0) < 4) { res.resume(); return resolve(fetchBuf(new URL(res.headers.location, u).toString(), maxBytes, (redirects || 0) + 1)); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('Update server answered ' + res.statusCode)); }
      const chunks = []; let n = 0;
      res.on('data', (c) => { n += c.length; if (n > maxBytes) { req.destroy(new Error('Update is too large.')); return; } chunks.push(c); });
      res.on('end', () => resolve(Buffer.concat(chunks))); res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new Error('Update server timed out.'))); req.on('error', reject);
  });
}

function rmrf(p) { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } }
function expandZip(zip, dest) {
  return new Promise((resolve, reject) => {
    const ps = "Expand-Archive -LiteralPath '" + zip.split("'").join("''") + "' -DestinationPath '" + dest.split("'").join("''") + "' -Force";
    cp.execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, timeout: 120000 }, (err, so, se) => err ? reject(new Error('Could not unpack the update: ' + String(se || err.message).slice(0, 200))) : resolve());
  });
}

class Updater {
  // opts: { url, currentVersion, codeDir, log(msg) }
  constructor(opts) { this.opts = opts; this.state = { current: opts.currentVersion, available: null, lastCheck: null, error: null, checking: false }; this.timer = null; }
  enabled() { return !!this.opts.url; }
  status() { return Object.assign({ enabled: this.enabled() }, this.state); }
  start(onReady) { this.onReady = onReady; if (!this.enabled()) return; setTimeout(() => this.check().catch(() => {}), 8000); this.timer = setInterval(() => this.check().catch(() => {}), 6 * 3600 * 1000); }
  async check() {
    if (!this.enabled()) throw new Error('No update address is configured.');
    if (this.state.checking) return this.status();
    this.state.checking = true; this.state.error = null;
    try {
      const base = this.opts.url.replace(/\/+$/, '');
      const cb = '?cb=' + Math.floor(Date.now() / 60000);   // the raw file CDN caches for minutes: a changing query string always gets the latest manifest
      const man = await fetchBuf(base + '/manifest.json' + cb, 200000), sig = await fetchBuf(base + '/manifest.sig' + cb, 4000);
      const pub = fs.readFileSync(this.opts.pubkeyFile || PUBKEY_FILE, 'utf8');
      const ok = crypto.verify(null, man, pub, Buffer.from(sig.toString('utf8').trim(), 'base64'));
      if (!ok) throw new Error('Update signature is not valid; ignoring it.');
      const m = JSON.parse(man.toString('utf8'));
      if (!m.version || !m.zip || !m.sha256 || /[\\/]/.test(m.zip)) throw new Error('Malformed update manifest.');
      this.state.lastCheck = new Date().toISOString();
      const cur = this.opts.currentVersion;
      const staged = this._stagedVersion();
      if (cmpVer(m.version, cur) <= 0 || (staged && cmpVer(m.version, staged) <= 0)) { this.state.available = staged && cmpVer(staged, cur) > 0 ? { version: staged, notes: this.state.available ? this.state.available.notes : '' } : null; return this.status(); }
      this.opts.log('update: downloading ' + m.version);
      const zip = await fetchBuf(base + '/' + m.zip, Math.min(MAX_ZIP, (m.size || MAX_ZIP) + 1024));
      if (m.size && zip.length !== m.size) throw new Error('Update size does not match its manifest.');
      const h = crypto.createHash('sha256').update(zip).digest('hex');
      if (h.toLowerCase() !== String(m.sha256).toLowerCase()) throw new Error('Update checksum does not match; ignoring it.');
      const codeDir = this.opts.codeDir; fs.mkdirSync(codeDir, { recursive: true });
      const dirName = 'v' + m.version, tmpDir = path.join(codeDir, dirName + '.tmp'), finalDir = path.join(codeDir, dirName), zipFile = path.join(codeDir, dirName + '.zip');
      rmrf(tmpDir); rmrf(finalDir); fs.writeFileSync(zipFile, zip);
      await expandZip(zipFile, tmpDir); try { fs.unlinkSync(zipFile); } catch (e) { /* ignore */ }
      if (!fs.existsSync(path.join(tmpDir, 'src', 'main', 'main.js')) || !fs.existsSync(path.join(tmpDir, 'package.json'))) { rmrf(tmpDir); throw new Error('Update package is incomplete.'); }
      fs.renameSync(tmpDir, finalDir);
      let prev = null, prevVersion = null; try { const c = JSON.parse(fs.readFileSync(path.join(codeDir, 'current.json'), 'utf8')); if (c.good) { prev = c.dir; prevVersion = c.version; } else { prev = c.prev || null; prevVersion = c.prevVersion || null; } } catch (e) { /* none */ }
      fs.writeFileSync(path.join(codeDir, 'current.json'), JSON.stringify({ version: m.version, dir: dirName, good: false, tried: 0, prev, prevVersion }));
      // keep only the new and the previous version
      for (const d of fs.readdirSync(codeDir)) { if (/^v[0-9.]+(\.tmp)?$/.test(d) && d !== dirName && d !== prev) rmrf(path.join(codeDir, d)); }
      this.state.available = { version: m.version, notes: String(m.notes || '').slice(0, 600) };
      this.opts.log('update: ' + m.version + ' ready (applies on next start)');
      if (this.onReady) this.onReady(this.state.available);
      return this.status();
    } catch (e) { this.state.error = e.message; this.opts.log('update error: ' + e.message); throw e; } finally { this.state.checking = false; }
  }
  _stagedVersion() { try { const c = JSON.parse(fs.readFileSync(path.join(this.opts.codeDir, 'current.json'), 'utf8')); return c.version || null; } catch (e) { return null; } }
}

module.exports = { Updater, cmpVer };
