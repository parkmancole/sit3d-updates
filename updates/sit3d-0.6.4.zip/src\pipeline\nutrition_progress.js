'use strict';
// Compares what a person ate (imported / synced nutrition days) with how their body changed between scans. Pure functions (Node 12 compatible).
// Days with under 800 kcal logged are treated as incomplete logging and ignored in averages.
const MIN_KCAL = 800, KCAL_PER_KG = 7700;
const addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const diffDays = (a, b) => Math.round((new Date(b + 'T12:00:00Z') - new Date(a + 'T12:00:00Z')) / 86400000);
const isoDay = (s) => String(s).slice(0, 10);
const mean = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
const r1 = (v) => (v == null ? null : Math.round(v * 10) / 10);

function goodDays(days, from, toExclusive) {
  const out = []; for (let d = from; d < toExclusive; d = addDays(d, 1)) { const x = days[d]; if (x && x.kcal >= MIN_KCAL) out.push(Object.assign({ d }, x)); } return out;
}

// scans: [{created, weight_kg, body_fat_pct, waist_cm, lean_mass_kg}] oldest first or any order
function betweenScans(scans, days) {
  const sc = scans.slice().sort((a, b) => (a.created < b.created ? -1 : 1)); const rows = [];
  for (let i = 1; i < sc.length; i++) {
    const a = sc[i - 1], b = sc[i], d1 = isoDay(a.created), d2 = isoDay(b.created), n = diffDays(d1, d2); if (n < 1) continue;
    const g = goodDays(days, d1, d2); const coverage = g.length / n;
    const avg = (k) => r1(mean(g.map(x => x[k])));
    const dW = a.weight_kg != null && b.weight_kg != null ? r1(b.weight_kg - a.weight_kg) : null;
    const dBF = a.body_fat_pct != null && b.body_fat_pct != null ? r1(b.body_fat_pct - a.body_fat_pct) : null;
    const dWaist = a.waist_cm != null && b.waist_cm != null ? r1(b.waist_cm - a.waist_cm) : null;
    const dLean = a.lean_mass_kg != null && b.lean_mass_kg != null ? r1(b.lean_mass_kg - a.lean_mass_kg) : null;
    const kcal = g.length ? Math.round(mean(g.map(x => x.kcal))) : null;
    let balance = null, maintenance = null;
    if (dW != null && n >= 7) balance = Math.round(dW * KCAL_PER_KG / n);              // kcal/day surplus (+) or deficit (-) implied by the weight change
    if (balance != null && kcal != null && coverage >= 0.6) maintenance = kcal - balance;   // estimated maintenance intake
    rows.push({ from: d1, to: d2, days: n, logged: g.length, coverage: Math.round(coverage * 100) / 100, kcal, protein: avg('protein'), carbs: avg('carbs'), fat: avg('fat'), dWeight: dW, dBodyFat: dBF, dWaist, dLean, balance, maintenance });
  }
  return rows;
}

// seven-day rolling average of logged calories, one point per logged day
function rolling(days, fromIso, toIso, win) {
  const out = [];
  for (let d = fromIso; d <= toIso; d = addDays(d, 1)) {
    const x = days[d]; if (!x || x.kcal < MIN_KCAL) continue;
    const g = goodDays(days, addDays(d, -(win - 1)), addDays(d, 1)); if (g.length < 3) continue;
    out.push({ t: d + 'T12:00:00', v: Math.round(mean(g.map(y => y.kcal))) });
  }
  return out;
}

function windowSummary(days, today, n, weightKg) {
  const g = goodDays(days, addDays(today, -(n - 1)), addDays(today, 1)); if (!g.length) return null;
  const avg = (k) => Math.round(mean(g.map(x => x[k] || 0)));
  const protein = avg('protein');
  return { n: g.length, window: n, kcal: avg('kcal'), protein, carbs: avg('carbs'), fat: avg('fat'), fiber: avg('fiber'), sodium: avg('sodium'), proteinPerKg: weightKg ? Math.round(protein / weightKg * 100) / 100 : null };
}

function topFoods(foodsByDate, fromIso, toIso, limit) {
  const m = {};
  for (const d of Object.keys(foodsByDate)) {
    if (d < fromIso || d > toIso) continue;
    for (const it of foodsByDate[d]) {
      const base = String(it.name).split(',')[0].trim().toLowerCase(); if (!base) continue;   // "93% Lean Beef, 240 gram" and "93% Lean Beef, 120 gram" count as one food
      const o = m[base] || (m[base] = { name: String(it.name).split(',')[0].trim(), times: 0, kcal: 0, protein: 0 }); o.times++; o.kcal += it.kcal || 0; o.protein += it.protein || 0;
    }
  }
  const all = Object.keys(m).map(k => m[k]);
  const round = (o) => ({ name: o.name, times: o.times, kcal: Math.round(o.kcal), protein: Math.round(o.protein) });
  return { byCalories: all.sort((a, b) => b.kcal - a.kcal).slice(0, limit).map(round), byProtein: all.sort((a, b) => b.protein - a.protein).slice(0, limit).map(round), byFrequency: all.sort((a, b) => b.times - a.times).slice(0, limit).map(round) };
}

module.exports = { betweenScans, rolling, windowSummary, topFoods, goodDays, addDays, MIN_KCAL };
