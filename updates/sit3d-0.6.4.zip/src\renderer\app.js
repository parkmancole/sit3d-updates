(function () {
'use strict';
const S3 = window.S3;
S3.state = { user: null, info: null, scans: [], metric: 'body_fat_pct', voice: true, picked: [] };

S3.go = async (route, arg) => {
  try {
    if (!S3.state.user) return S3.viewAuth('login');
    window.scrollTo(0, 0);
    if (route === 'dash') await S3.viewDash();
    else if (route === 'scan') await S3.viewScan();
    else if (route === 'history') await S3.viewHistory();
    else if (route === 'profile') await S3.viewProfile();
    else if (route === 'nutrition') await S3.viewNutrition();
    else if (route === 'results') await S3.viewResults(arg);
    else await S3.viewDash();
  } catch (e) { S3.toast(e.message); console.error(e); }
};
S3.afterAuth = async () => { S3.state.info = await S3.api('app:info'); S3.go('dash'); };

S3.on('update:ready', (u) => { S3.toast('Update ' + u.version + ' downloaded. It applies the next time you open the app (see Profile to restart now).'); });
(async function boot() {
  try {
    S3.state.info = await S3.api('app:info');
    if (S3.state.info.user) { S3.state.user = S3.state.info.user; S3.go('dash'); } else S3.viewAuth('login');
  } catch (e) { document.body.innerHTML = '<pre style="padding:30px">Startup error: ' + S3.esc(e.message) + '</pre>'; }
})();

})();
