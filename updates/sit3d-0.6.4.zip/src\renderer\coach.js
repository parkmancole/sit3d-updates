(function () {
'use strict';
// AI coach panel: written insights + live voice conversation (Google Gemini Live). The panel floats at the right, so the user can keep browsing the app.
const S3 = window.S3, $ = (s, r) => (r || document).querySelector(s), esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// tiny, safe markdown: ## headings, - bullets, **bold**
function md(text) {
  const lines = esc(text).split(String.fromCharCode(10)); let html = '', inList = false;
  const inline = (t) => t.replace(/[*][*]([^*]+)[*][*]/g, '<b>$1</b>');
  for (const raw of lines) {
    const l = raw.trim();
    if (/^[-*] /.test(l)) { if (!inList) { html += '<ul>'; inList = true; } html += '<li>' + inline(l.slice(2)) + '</li>'; continue; }
    if (inList) { html += '</ul>'; inList = false; }
    if (/^#{1,3} /.test(l)) html += '<h4>' + inline(l.replace(/^#{1,3} /, '')) + '</h4>'; else if (l) html += '<p>' + inline(l) + '</p>';
  }
  if (inList) html += '</ul>'; return html;
}

// ---------------- live voice ----------------
const L = { ws: null, ctxIn: null, ctxOut: null, stream: null, proc: null, playAt: 0, srcs: [], on: false, allowBarge: false, timer: null, tr: { user: '', coach: '' } };
const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => { const bin = atob(s), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); return u8; };
function setStatus(t, cls) { const el = $('#cpStatus'); if (el) { el.textContent = t; el.className = 'cp-status ' + (cls || ''); } }
function addLine(who, text) { const box = $('#cpTr'); if (!box || !text) return; const d = document.createElement('div'); d.className = 'cp-line ' + who; d.textContent = text; box.appendChild(d); box.scrollTop = box.scrollHeight; return d; }

function stopPlayback() { L.srcs.forEach((s) => { try { s.stop(); } catch (e) { /* ended */ } }); L.srcs = []; L.playAt = 0; }
function playPcm(u8) {
  if (!L.ctxOut) return; const n = Math.floor(u8.length / 2), f32 = new Float32Array(n), dv = new DataView(u8.buffer, u8.byteOffset, n * 2);
  for (let i = 0; i < n; i++) f32[i] = dv.getInt16(i * 2, true) / 32768;
  const buf = L.ctxOut.createBuffer(1, n, 24000); buf.copyToChannel(f32, 0); const src = L.ctxOut.createBufferSource(); src.buffer = buf;
  const g = L.ctxOut.createGain(); g.gain.value = 0.9; src.connect(g); g.connect(L.ctxOut.destination);
  const t = Math.max(L.ctxOut.currentTime + 0.03, L.playAt); src.start(t); L.playAt = t + buf.duration; L.srcs.push(src); src.onended = () => { L.srcs = L.srcs.filter((x) => x !== src); if (!L.srcs.length) setStatus(L.on ? 'Listening…' : '', 'listen'); };
  setStatus('Coach is speaking…', 'speak');
}

async function liveStart(walk) {
  if (L.on) return; L.on = true; $('#cpTr').innerHTML = ''; L.tr = { user: '', coach: '' }; syncButtons();
  let cfg; try { cfg = await S3.api('ai:liveConfig'); } catch (e) { L.on = false; syncButtons(); setStatus(e.message, 'err'); return; }
  setStatus('Connecting…');
  try {
    L.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
  } catch (e) { L.on = false; syncButtons(); setStatus('The microphone is not available. Check that a mic is connected and allowed.', 'err'); return; }
  L.ctxOut = new (window.AudioContext || window.webkitAudioContext)(); L.ctxIn = new (window.AudioContext || window.webkitAudioContext)();
  const ws = new WebSocket('wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=' + encodeURIComponent(cfg.key)); L.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ setup: { model: cfg.model, generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: cfg.voice } } } }, systemInstruction: { parts: [{ text: cfg.system }] }, inputAudioTranscription: {}, outputAudioTranscription: {} } }));
  ws.onmessage = async (ev) => {
    let m; try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : await ev.data.text()); } catch (e) { return; }
    if (m.setupComplete) { startMic(); setStatus('Listening…', 'listen'); if (walk) ws.send(JSON.stringify({ clientContent: { turns: [{ role: 'user', parts: [{ text: 'Please walk me through everything: my latest scan, how I have changed, my nutrition and food choices, and your top three suggestions.' }] }], turnComplete: true } })); else ws.send(JSON.stringify({ clientContent: { turns: [{ role: 'user', parts: [{ text: 'Greet me in one short sentence and tell me I can ask about my scans and nutrition.' }] }], turnComplete: true } })); return; }
    const sc = m.serverContent;
    if (sc) {
      if (sc.interrupted) { stopPlayback(); }
      if (sc.modelTurn) for (const p of sc.modelTurn.parts || []) if (p.inlineData && p.inlineData.data) playPcm(unb64(p.inlineData.data));
      if (sc.inputTranscription && sc.inputTranscription.text) { L.tr.user += sc.inputTranscription.text; L.uLine = L.uLine || addLine('you', ''); if (L.uLine) L.uLine.textContent = L.tr.user; }
      if (sc.outputTranscription && sc.outputTranscription.text) { L.tr.coach += sc.outputTranscription.text; L.cLine = L.cLine || addLine('coach', ''); if (L.cLine) L.cLine.textContent = L.tr.coach; }
      if (sc.turnComplete) { L.tr = { user: '', coach: '' }; L.uLine = null; L.cLine = null; }
    }
    if (m.goAway) setStatus('The session is about to end. Start again to keep talking.', 'err');
  };
  ws.onerror = () => { if (L.on) setStatus('Could not reach the AI service.', 'err'); };
  ws.onclose = (e) => { if (L.on) { liveStop(); setStatus(e.code === 1000 ? 'Conversation ended.' : 'Connection closed' + (e.reason ? ': ' + e.reason.slice(0, 80) : '.'), e.code === 1000 ? '' : 'err'); } };
  L.timer = setTimeout(() => { liveStop(); setStatus('Session limit reached (15 minutes). Tap Talk to continue.'); }, 14 * 60 * 1000);
}
function startMic() {
  const src = L.ctxIn.createMediaStreamSource(L.stream); const proc = L.ctxIn.createScriptProcessor(4096, 1, 1); L.proc = proc; const ratio = L.ctxIn.sampleRate / 16000;
  proc.onaudioprocess = (e) => {
    if (!L.ws || L.ws.readyState !== 1) return; if (!L.allowBarge && L.ctxOut && L.playAt > L.ctxOut.currentTime) return;   // without headphones, do not listen while the coach talks (avoids echo)
    const inp = e.inputBuffer.getChannelData(0), n = Math.floor(inp.length / ratio), out = new Int16Array(n);
    for (let i = 0; i < n; i++) { const s = Math.max(-1, Math.min(1, inp[Math.floor(i * ratio)])); out[i] = s < 0 ? s * 32768 : s * 32767; }
    L.ws.send(JSON.stringify({ realtimeInput: { audio: { data: b64(new Uint8Array(out.buffer)), mimeType: 'audio/pcm;rate=16000' } } }));
  };
  const mute = L.ctxIn.createGain(); mute.gain.value = 0; src.connect(proc); proc.connect(mute); mute.connect(L.ctxIn.destination);
}
function liveStop() {
  L.on = false; clearTimeout(L.timer); stopPlayback();
  try { if (L.proc) L.proc.disconnect(); } catch (e) { /* ignore */ } try { if (L.stream) L.stream.getTracks().forEach((t) => t.stop()); } catch (e) { /* ignore */ }
  try { if (L.ws) { const w = L.ws; L.ws = null; w.close(); } } catch (e) { /* ignore */ } try { if (L.ctxIn) L.ctxIn.close(); if (L.ctxOut) L.ctxOut.close(); } catch (e) { /* ignore */ }
  L.ctxIn = L.ctxOut = L.stream = L.proc = null; syncButtons(); setStatus('');
}
function syncButtons() { const t = $('#cpTalk'), w = $('#cpWalk'); if (t) { t.textContent = L.on ? 'Stop' : 'Talk'; t.classList.toggle('on', L.on); } if (w) w.disabled = L.on; }

// ---------------- panel ----------------
let st = null;   // ai:status
async function refresh() { try { st = await S3.api('ai:status'); } catch (e) { st = { enabled: false }; } render(); }
function render() {
  const body = $('#cpBody'); if (!body) return;
  if (!st || !st.enabled) { body.innerHTML = `<div class="cp-empty"><div class="big">Set up your coach</div><p>The coach reads an <b>anonymous summary</b> of your scans and nutrition and gives suggestions. It needs your own free Google AI key.</p><button class="btn" id="cpSetup">Open Profile</button></div>`; $('#cpSetup').onclick = () => { S3.go('profile'); }; return; }
  body.innerHTML = `<div class="cp-tabs"><button data-tab="insights" class="on">Insights</button><button data-tab="talk">Talk</button></div>
    <div id="cpInsights"><div class="row" style="gap:8px"><button class="btn" id="cpAnalyze">${st.last ? 'Refresh analysis' : 'Analyze my progress'}</button></div><div id="cpResult" class="cp-result">${st.last ? `<div class="small muted">From ${esc(S3.fmtDate(st.last.at, true))}</div>` + md(st.last.text) : '<p class="muted small">Press the button to get suggestions based on your scans, nutrition and food choices.</p>'}</div>
      <form id="cpAsk" class="row" style="gap:8px;margin-top:10px"><input name="q" type="text" placeholder="Ask a question…" maxlength="300" style="flex:1"><button class="btn secondary" type="submit">Ask</button></form></div>
    <div id="cpTalkTab" style="display:none"><div class="row" style="gap:8px"><button class="btn" id="cpTalk">Talk</button><button class="btn secondary" id="cpWalk">Walk me through everything</button></div><div id="cpStatus" class="cp-status"></div><label class="small muted row" style="gap:6px;margin:6px 0"><input type="checkbox" id="cpBarge"> I am wearing headphones (lets me interrupt the coach)</label><div id="cpTr" class="cp-tr"><div class="small muted">Press Talk, then speak. You can keep using the app while the coach listens.</div></div></div>`;
  $$('[data-tab]', body).forEach((b) => b.onclick = () => { $$('[data-tab]', body).forEach((x) => x.classList.toggle('on', x === b)); $('#cpInsights').style.display = b.dataset.tab === 'insights' ? '' : 'none'; $('#cpTalkTab').style.display = b.dataset.tab === 'talk' ? '' : 'none'; });
  const busy = (on) => { $('#cpAnalyze').disabled = on; $('#cpAsk').querySelector('button').disabled = on; };
  const run = async (q) => { busy(true); $('#cpResult').innerHTML = '<p class="muted small">Thinking…</p>'; try { const r = await S3.api('ai:coach', q || null); $('#cpResult').innerHTML = (q ? `<div class="small muted">You asked: ${esc(q)}</div>` : '') + md(r.text); if (!q) st.last = r; } catch (e) { $('#cpResult').innerHTML = `<p class="err" style="display:block">${esc(e.message)}</p>`; } busy(false); };
  $('#cpAnalyze').onclick = () => run(null);
  $('#cpAsk').onsubmit = (e) => { e.preventDefault(); const q = String(new FormData(e.target).get('q') || '').trim(); if (q) { run(q); e.target.reset(); } };
  $('#cpTalk').onclick = () => { if (L.on) liveStop(); else liveStart(false); };
  $('#cpWalk').onclick = () => liveStart(true);
  $('#cpBarge').onchange = (e) => { L.allowBarge = e.target.checked; };
  syncButtons();
}
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));

S3.coachMount = () => {
  if ($('#cpBtn')) return;
  const btn = document.createElement('button'); btn.id = 'cpBtn'; btn.className = 'cp-fab'; btn.type = 'button'; btn.innerHTML = '<span>✦</span> Coach'; document.body.appendChild(btn);
  const panel = document.createElement('div'); panel.id = 'cpPanel'; panel.className = 'cp-panel'; panel.innerHTML = '<div class="cp-head"><b>Coach</b><button type="button" id="cpClose" aria-label="Close">×</button></div><div id="cpBody" class="cp-body"></div>'; document.body.appendChild(panel);
  btn.onclick = () => { const open = !panel.classList.contains('show'); panel.classList.toggle('show', open); document.body.classList.toggle('coach-open', open); if (open) refresh(); };
  $('#cpClose').onclick = () => { panel.classList.remove('show'); document.body.classList.remove('coach-open'); };
};
S3.coachUnmount = () => { liveStop(); ['cpBtn', 'cpPanel'].forEach((id) => { const e = document.getElementById(id); if (e) e.remove(); }); document.body.classList.remove('coach-open'); st = null; };
S3.coachRefresh = () => { if ($('#cpPanel') && $('#cpPanel').classList.contains('show')) refresh(); };
})();
