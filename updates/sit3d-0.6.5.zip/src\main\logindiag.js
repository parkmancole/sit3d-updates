'use strict';
// Diagnostics for the nutrition-app login windows: records (to the app log) what the page says after each load, which requests failed and
// console errors. Never records typed values, cookies or query strings.
const hostPath = (u) => { try { const x = new URL(u); return x.hostname + x.pathname.slice(0, 60); } catch (e) { return String(u).slice(0, 60); } };

function attach(w, L, urlPattern) {
  const wc = w.webContents, ses = wc.session; let n = 0;
  const filter = { urls: [urlPattern] };
  try { ses.webRequest.onCompleted(filter, (d) => { if (n < 80 && (d.statusCode >= 400 || /login|auth|session|token|captcha|challenge/i.test(d.url))) { n++; L('http ' + d.method + ' ' + d.statusCode + ' ' + hostPath(d.url)); } }); } catch (e) { /* ignore */ }
  try { ses.webRequest.onErrorOccurred(filter, (d) => { if (n < 80) { n++; L('request failed ' + d.error + ' ' + hostPath(d.url)); } }); } catch (e) { /* ignore */ }
  wc.on('console-message', (e, level, msg) => { if (level >= 2 && n < 80) { n++; L('page console: ' + String(msg).slice(0, 120)); } });
  wc.on('did-finish-load', async () => {
    try {
      const t = await wc.executeJavaScript("(document.body ? document.body.innerText : '').split(String.fromCharCode(10)).join(' ').slice(0, 300)");
      L('page text: ' + String(t).slice(0, 300));
    } catch (e) { /* page gone */ }
  });
  return () => { try { ses.webRequest.onCompleted(null); ses.webRequest.onErrorOccurred(null); } catch (e) { /* ignore */ } };
}
module.exports = { attach };
