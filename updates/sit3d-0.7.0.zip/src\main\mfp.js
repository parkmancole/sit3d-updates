'use strict';
// MyFitnessPal sync WITHOUT CSV files and without an official API (MyFitnessPal's API is closed to individual developers).
// The user signs in to myfitnesspal.com inside an app window (so passwords, captchas and 2-step logins are handled by MyFitnessPal itself;
// S*it3D never sees or stores the password). The browser session stays in a private per-user profile, and the app then reads the user's own
// food diary pages the same way their browser would. This is unofficial: it can stop working if MyFitnessPal changes its pages, and the
// user should be comfortable with MyFitnessPal's terms of service for their own data.
const fs = require('fs'), path = require('path');
const cdp = require('./cdp.js');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const DIARY = (iso) => (process.env.SIT3D_MFP_BASE || 'https://www.myfitnesspal.com') + '/food/diary?date=' + iso;   // the override is only used by the tests

// Runs inside the diary page. Returns the day's totals mapped by column header.
const EXTRACT = `(() => {
  const txt = (el) => (el ? el.textContent.replace(/\\s+/g, ' ').trim() : '');
  const num = (s) => { const m = String(s).replace(/,/g, '').match(/-?[0-9]+(\\.[0-9]+)?/); return m ? parseFloat(m[0]) : null; };
  const url = location.href;
  if (/account\\/login|\\/login|oauth/.test(url)) return { ok: false, needLogin: true };
  const total = document.querySelector('tr.total');
  if (!total) return { ok: false, noDiary: true, title: document.title };
  const hdr = document.querySelector('tr.meal_header');
  let cols = hdr ? Array.from(hdr.querySelectorAll('td')).slice(1).map((td) => txt(td).toLowerCase()) : [];
  if (!cols.length || cols.length < 4) cols = ['calories', 'carbs', 'fat', 'protein', 'sodium', 'sugar'];
  const cells = Array.from(total.querySelectorAll('td')).slice(1);
  const vals = cells.map((td) => { const mv = td.querySelector('.macro-value'); return num(mv ? mv.textContent : td.textContent); });
  const out = {};
  cols.forEach((c, i) => { if (vals[i] != null) out[c.split(' ')[0].replace(/[^a-z]/g, '')] = vals[i]; });
  const keyOf = (c) => c.split(' ')[0].replace(/[^a-z]/g, '');
  const items = []; let meal = '';
  document.querySelectorAll('tr').forEach((tr) => {
    if (tr.classList.contains('meal_header')) { meal = txt(tr.querySelector('td')); return; }
    const a = tr.querySelector('a[data-food-entry-id]'); if (!a) return;
    const tds = Array.from(tr.querySelectorAll('td')).filter((td) => !td.classList.contains('delete') && !td.classList.contains('first'));
    const it = { meal, name: txt(a) };
    cols.forEach((c, i) => { const td = tds[i]; if (!td) return; const mv = td.querySelector('.macro-value'); const v = num(mv ? mv.textContent : td.textContent); if (v != null) it[keyOf(c)] = v; });
    items.push(it);
  });
  return { ok: true, totals: out, cols, items };
})()`;

function mapTotals(t) {
  const g = (...k) => { for (const x of k) if (t[x] != null) return t[x]; return 0; };
  return { kcal: g('calories', 'energy'), carbs: g('carbs', 'carbohydrates'), fat: g('fat'), protein: g('protein'), sodium: g('sodium'), sugar: g('sugar'), fiber: g('fiber'), n: 1 };
}

function mapItem(it) {
  const g = (...k) => { for (const x of k) if (it[x] != null) return it[x]; return 0; };
  return { meal: it.meal || '', name: it.name || '', kcal: g('calories', 'energy'), carbs: g('carbs', 'carbohydrates'), fat: g('fat'), protein: g('protein'), sodium: g('sodium'), sugar: g('sugar') };
}

const LOGIN = 'https://www.myfitnesspal.com/account/login';
const localIso = (d) => { const z = (n) => String(n).padStart(2, '0'); return d.getFullYear() + '-' + z(d.getMonth() + 1) + '-' + z(d.getDate()); };
const addDays = (iso, n) => { const d = new Date(iso + 'T12:00:00'); d.setDate(d.getDate() + n); return localIso(d); };
const rmrf = (p) => { try { if (fs.rmSync) fs.rmSync(p, { recursive: true, force: true }); else fs.rmdirSync(p, { recursive: true }); } catch (e) { /* ignore */ } };

async function readDay(drv, iso) { await drv.goto(DIARY(iso)); return drv.evalJs(EXTRACT); }

// Opens a normal Edge/Chrome window on MyFitnessPal's login page (any sign-in method works there, including Google and 2-step login).
// The app watches the window; once the diary can be read it makes the login last 30 days, closes the window and returns true.
async function connect(parent, userId, log, profileDir) {
  const L = (m) => { try { if (log) log('mfp login: ' + m); } catch (e) { /* ignore */ } };
  let drv; try { drv = await cdp.launch({ profileDir, headless: false, app: true, url: LOGIN }); } catch (e) { L('browser start failed: ' + e.message); throw e; }
  L('browser opened'); const t0 = Date.now(); let lastCheck = 0, ok = false;
  try {
    while (!drv.exited() && Date.now() - t0 < 15 * 60 * 1000) {
      await sleep(1500); const u = await drv.url(); if (!u) continue;
      if (!/^https:\/\/([a-z0-9-]+\.)*myfitnesspal\.com\//.test(u) || /account\/login|account\/create|oauth|signup|sso/.test(u)) continue;
      if (Date.now() - lastCheck < 6000) continue; lastCheck = Date.now(); L('signed-in page ' + u.split('?')[0]);
      let r = null; try { r = await readDay(drv, localIso(new Date())); } catch (e) { L('diary check error ' + String(e.message).slice(0, 100)); continue; }
      L('diary check -> ' + JSON.stringify({ ok: !!(r && r.ok), needLogin: !!(r && r.needLogin), noDiary: !!(r && r.noDiary) }));
      if (r && r.ok) { ok = true; break; }
    }
    if (ok) { const n = await drv.persistSessionCookies(30).catch(() => 0); L('login kept for 30 days (' + n + ' cookies)'); }
  } finally { await drv.close(); }
  if (!ok) {   // the window was closed: maybe the login worked anyway, so look once with a hidden browser
    try { const h = await cdp.launch({ profileDir, headless: true, url: 'about:blank' }); try { const r = await readDay(h, localIso(new Date())); ok = !!(r && r.ok); L('check after close -> ' + ok); } finally { await h.close(); } } catch (e) { L('check after close failed: ' + String(e.message).slice(0, 100)); }
  }
  L('finished ' + ok); return ok;
}

// Reads every day from `fromIso` to today. onDays(days, foods) is called with batches so partial progress is saved.
async function sync(userId, fromIso, onProgress, onDays, profileDir, log, toIso) {
  const L = (m) => { try { if (log) log('mfp sync: ' + m); } catch (e) { /* ignore */ } };
  const today = toIso || localIso(new Date()); const days = {}, foods = {}; let errors = 0, read = 0, noData = 0;
  const total = Math.max(1, Math.round((new Date(today + 'T12:00:00') - new Date(fromIso + 'T12:00:00')) / 86400000) + 1);
  const drv = await cdp.launch({ profileDir, headless: true, url: 'about:blank' });
  try {
    for (let d = fromIso, i = 0; d <= today; d = addDays(d, 1), i++) {
      let r = null;
      try { r = await readDay(drv, d); } catch (e) { errors++; L('day ' + d + ' error ' + String(e.message).slice(0, 80)); if (errors >= 4) throw new Error('MyFitnessPal stopped answering. Try again later.'); await sleep(3000); continue; }
      if (r && r.needLogin) throw new Error('NEED_LOGIN');
      if (r && r.ok) { errors = 0; const m = mapTotals(r.totals); if (m.kcal > 0) { days[d] = m; foods[d] = (r.items || []).map(mapItem); read++; } else noData++; }
      else if (r && r.noDiary) { errors++; L('day ' + d + ' no diary table, title: ' + String(r.title).slice(0, 60)); if (errors >= 4) throw new Error('The MyFitnessPal diary page looks different than expected, so syncing stopped.'); }
      if (onProgress) onProgress({ p: (i + 1) / total, day: d });
      if (Object.keys(days).length >= 10 && onDays) { onDays(days, foods); for (const k of Object.keys(days)) delete days[k]; for (const k of Object.keys(foods)) delete foods[k]; }
      await sleep(900);
    }
    if (onDays && Object.keys(days).length) onDays(days, foods);
    return { read, noData, from: fromIso, to: today };
  } finally { await drv.close(); }
}

async function disconnect(userId, profileDir) { rmrf(profileDir); }

module.exports = { connect, sync, disconnect, EXTRACT, mapTotals, mapItem, localIso, addDays };
