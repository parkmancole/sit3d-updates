(function () {
'use strict';
// AI coach: pressing the Coach button starts a live voice conversation (Google Gemini Live); the "Summarize" bubble above it reads out the
// dashboard and the AI insights. The panel floats at the bottom right, so the app stays usable. Written insights live on the dashboard.
const S3 = window.S3, $ = (s, r) => (r || document).querySelector(s), $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// tiny, safe markdown: ## headings, - bullets, **bold**
function md(text) {
  const lines = esc(text).split(String.fromCharCode(10)); let html = '', inList = false;
  const inline = (t) => t.replace(/[*][*]([^*]+)[*][*]/g, '<b>$1</b>');
  for (const raw of lines) {
    const l = raw.trim();
    if (/^[-*] /.test(l)) { if (!inList) { html += '<ul>'; inList = true; } html += '<li>' + inline(l.slice(2)) + '</li>'; continue; }
    if (inList) { html += '</ul>'; inList = false; }
    if (/^#{1,3} /.test(l)) html += '<h4>' + inline(l.replace(/^#{1,3} /, '')) + '</h4>'; else if (l) html += '<p>' + inline(l) + '</p>';
  }
  if (inList) html += '</ul>'; return html;
}
S3.md = md;
const plain = (t) => String(t || '').split('#').join('').split('*').join('').trim();

// ---------------- what the coach is told when asked to summarize ----------------
function dashContext() {
  const sc = S3.state.scans || []; if (!sc.length) return 'No scans yet.';
  const a = sc[sc.length - 1], b = sc.length > 1 ? sc[sc.length - 2] : null; const parts = [];
  const add = (label, v, fmt, unit, prev) => { if (v == null) return; let s = label + ' ' + fmt(v) + (unit ? ' ' + unit : ''); if (prev != null && prev !== v) { const d = v - prev; s += ' (' + (d > 0 ? 'up ' : 'down ') + fmt(Math.abs(d)) + ' since the previous scan)'; } parts.push(s); };
  const n1 = (x) => (Math.round(x * 10) / 10).toString(), n0 = (x) => Math.round(x).toString();
  add('Weight', a.weight_kg != null ? parseFloat(S3.kg(a.weight_kg)) : null, n1, S3.unitsWt(), b && b.weight_kg != null ? parseFloat(S3.kg(b.weight_kg)) : null);
  add('Body fat', a.body_fat_pct, n1, 'percent', b && b.body_fat_pct);
  add('Lean mass', a.lean_mass_kg != null ? parseFloat(S3.kg(a.lean_mass_kg)) : null, n1, S3.unitsWt(), b && b.lean_mass_kg != null ? parseFloat(S3.kg(b.lean_mass_kg)) : null);
  add('Waist', a.waist_cm != null ? parseFloat(S3.cm(a.waist_cm)) : null, n1, S3.unitsLen(), b && b.waist_cm != null ? parseFloat(S3.cm(b.waist_cm)) : null);
  add('Shape score', a.shape_score, n0, 'out of 100', b && b.shape_score); add('Posture score', a.posture_score, n0, 'out of 100', b && b.posture_score);
  return 'Scans on file: ' + sc.length + '. Latest scan: ' + parts.join('; ') + '.';
}

// ---------------- live voice ----------------
const L = { ws: null, ctxIn: null, ctxOut: null, stream: null, proc: null, playAt: 0, srcs: [], on: false, allowBarge: false, timer: null, tr: { user: '', coach: '' }, uLine: null, cLine: null };
const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const unb64 = (s) => { const bin = atob(s), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); return u8; };
function setStatus(t, cls) { const el = $('#cpStatus'); if (el) { el.textContent = t; el.className = 'cp-status ' + (cls || ''); } }
function addLine(who, text) { const box = $('#cpTr'); if (!box) return null; const d = document.createElement('div'); d.className = 'cp-line ' + who; d.textContent = text || ''; box.appendChild(d); box.scrollTop = box.scrollHeight; return d; }
function stopPlayback() { L.srcs.forEach((s) => { try { s.stop(); } catch (e) { /* ended */ } }); L.srcs = []; L.playAt = 0; }
function playPcm(u8) {
  if (!L.ctxOut) return; const n = Math.floor(u8.length / 2), f32 = new Float32Array(n), dv = new DataView(u8.buffer, u8.byteOffset, n * 2);
  for (let i = 0; i < n; i++) f32[i] = dv.getInt16(i * 2, true) / 32768;
  const buf = L.ctxOut.createBuffer(1, n, 24000); buf.copyToChannel(f32, 0); const src = L.ctxOut.createBufferSource(); src.buffer = buf;
  const g = L.ctxOut.createGain(); g.gain.value = 0.9; src.connect(g); g.connect(L.ctxOut.destination);
  const t = Math.max(L.ctxOut.currentTime + 0.03, L.playAt); src.start(t); L.playAt = t + buf.duration; L.srcs.push(src); src.onended = () => { L.srcs = L.srcs.filter((x) => x !== src); if (!L.srcs.length) setStatus(L.on ? 'Listening…' : '', 'listen'); };
  setStatus('Coach is speaking…', 'speak');
}
function sendTurn(text) { if (L.ws && L.ws.readyState === 1) L.ws.send(JSON.stringify({ clientContent: { turns: [{ role: 'user', parts: [{ text }] }], turnComplete: true } })); }
function summaryPrompt() {
  const ins = S3.state.insights && S3.state.insights.text ? ' My AI insights say: ' + plain(S3.state.insights.text).split(String.fromCharCode(10)).join(' ') : '';
  return 'Please give me a short spoken summary of my dashboard and my AI insights, in under a minute. Dashboard: ' + dashContext() + ins + ' End by offering to answer questions.';
}

async function liveStart(mode) {
  if (window.__sit3dNoLive) { setStatus('(live voice is disabled in the self-test)'); return; }   // the automated test must never open the microphone
  if (L.on) return; L.on = true; $('#cpTr').innerHTML = ''; L.tr = { user: '', coach: '' }; L.uLine = L.cLine = null; syncButtons();
  let cfg; try { cfg = await S3.api('ai:liveConfig'); } catch (e) { L.on = false; syncButtons(); setStatus(e.message, 'err'); return; }
  setStatus('Connecting…');
  try { L.stream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } }); }
  catch (e) { L.on = false; syncButtons(); setStatus('The microphone is not available. Check that a mic is connected and allowed.', 'err'); return; }
  L.ctxOut = new (window.AudioContext || window.webkitAudioContext)(); L.ctxIn = new (window.AudioContext || window.webkitAudioContext)();
  const ws = new WebSocket('wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=' + encodeURIComponent(cfg.key)); L.ws = ws;
  ws.onopen = () => ws.send(JSON.stringify({ setup: { model: cfg.model, generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: cfg.voice } } } }, systemInstruction: { parts: [{ text: cfg.system }] }, inputAudioTranscription: {}, outputAudioTranscription: {} } }));
  ws.onmessage = async (ev) => {
    let m; try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : await ev.data.text()); } catch (e) { return; }
    if (m.setupComplete) { startMic(); setStatus('Listening…', 'listen'); sendTurn(mode === 'summary' ? summaryPrompt() : 'Greet me in one short sentence and tell me I can ask about my scans and nutrition, or tap Summarize.'); return; }
    const sc = m.serverContent;
    if (sc) {
      if (sc.interrupted) stopPlayback();
      if (sc.modelTurn) for (const p of sc.modelTurn.parts || []) if (p.inlineData && p.inlineData.data) playPcm(unb64(p.inlineData.data));
      if (sc.inputTranscription && sc.inputTranscription.text) { L.tr.user += sc.inputTranscription.text; L.uLine = L.uLine || addLine('you', ''); if (L.uLine) L.uLine.textContent = L.tr.user; }
      if (sc.outputTranscription && sc.outputTranscription.text) { L.tr.coach += sc.outputTranscription.text; L.cLine = L.cLine || addLine('coach', ''); if (L.cLine) L.cLine.textContent = L.tr.coach; }
      if (sc.turnComplete) { L.tr = { user: '', coach: '' }; L.uLine = null; L.cLine = null; }
    }
    if (m.goAway) setStatus('The session is about to end. Press Coach again to keep talking.', 'err');
  };
  ws.onerror = () => { if (L.on) setStatus('Could not reach the AI service.', 'err'); };
  ws.onclose = (e) => { if (L.on) { liveStop(); setStatus(e.code === 1000 ? 'Conversation ended.' : 'Connection closed' + (e.reason ? ': ' + e.reason.slice(0, 80) : '.'), e.code === 1000 ? '' : 'err'); } };
  L.timer = setTimeout(() => { liveStop(); setStatus('Session limit reached (15 minutes). Press Coach to continue.'); }, 14 * 60 * 1000);
}
function startMic() {
  const src = L.ctxIn.createMediaStreamSource(L.stream); const proc = L.ctxIn.createScriptProcessor(4096, 1, 1); L.proc = proc; const ratio = L.ctxIn.sampleRate / 16000;
  proc.onaudioprocess = (e) => {
    if (!L.ws || L.ws.readyState !== 1) return; if (!L.allowBarge && L.ctxOut && L.playAt > L.ctxOut.currentTime) return;   // without headphones, do not listen while the coach talks (avoids echo)
    const inp = e.inputBuffer.getChannelData(0), n = Math.floor(inp.length / ratio), out = new Int16Array(n);
    for (let i = 0; i < n; i++) { const s = Math.max(-1, Math.min(1, inp[Math.floor(i * ratio)])); out[i] = s < 0 ? s * 32768 : s * 32767; }
    L.ws.send(JSON.stringify({ realtimeInput: { audio: { data: b64(new Uint8Array(out.buffer)), mimeType: 'audio/pcm;rate=16000' } } }));
  };
  const mute = L.ctxIn.createGain(); mute.gain.value = 0; src.connect(proc); proc.connect(mute); mute.connect(L.ctxIn.destination);
}
function liveStop() {
  L.on = false; clearTimeout(L.timer); stopPlayback();
  try { if (L.proc) L.proc.disconnect(); } catch (e) { /* ignore */ } try { if (L.stream) L.stream.getTracks().forEach((t) => t.stop()); } catch (e) { /* ignore */ }
  try { if (L.ws) { const w = L.ws; L.ws = null; w.close(); } } catch (e) { /* ignore */ } try { if (L.ctxIn) L.ctxIn.close(); if (L.ctxOut) L.ctxOut.close(); } catch (e) { /* ignore */ }
  L.ctxIn = L.ctxOut = L.stream = L.proc = null; syncButtons(); setStatus('');
}
function syncButtons() { const s = $('#cpStop'); if (s) s.style.display = L.on ? '' : 'none'; const f = $('#cpBtn'); if (f) f.classList.toggle('live', L.on); }

// ---------------- panel ----------------
let enabled = null;
function renderBody() {
  const body = $('#cpBody'); if (!body) return;
  if (!enabled) { body.innerHTML = '<div class="cp-empty"><div class="big">Set up your coach</div><p>The coach talks with you about your scans and nutrition. It needs your own free Google AI key, which you add in Profile.</p><button class="btn" id="cpSetup">Open Profile</button></div>'; $('#cpSetup').onclick = () => { closePanel(); S3.go('profile'); }; return; }
  body.innerHTML = '<div class="row" style="gap:8px;justify-content:space-between"><div id="cpStatus" class="cp-status"></div><button class="btn ghost" id="cpStop" style="display:none;padding:6px 12px">Stop</button></div><div id="cpTr" class="cp-tr"><div class="small muted">Speak any time. Tap Summarize for a spoken overview of your dashboard and insights.</div></div><label class="small muted row" style="gap:6px;margin:4px 0 0"><input type="checkbox" id="cpBarge" ' + (L.allowBarge ? 'checked' : '') + '> I am wearing headphones (lets me interrupt the coach)</label>';
  $('#cpStop').onclick = () => liveStop(); $('#cpBarge').onchange = (e) => { L.allowBarge = e.target.checked; }; syncButtons();
}
async function openPanel() {
  const panel = $('#cpPanel'); panel.classList.add('show'); $('#cpChip').classList.add('show');
  try { const st = await S3.api('ai:status'); enabled = !!st.enabled; } catch (e) { enabled = false; }
  renderBody(); $('#cpChip').style.display = enabled ? '' : 'none';
  if (enabled && !L.on) liveStart('greet');
}
function closePanel() { liveStop(); const p = $('#cpPanel'); if (p) p.classList.remove('show'); const c = $('#cpChip'); if (c) c.classList.remove('show'); }

S3.coachMount = () => {
  if ($('#cpBtn')) return;
  const btn = document.createElement('button'); btn.id = 'cpBtn'; btn.className = 'cp-fab'; btn.type = 'button'; btn.innerHTML = '<span>✦</span> Coach'; document.body.appendChild(btn);
  const chip = document.createElement('button'); chip.id = 'cpChip'; chip.className = 'cp-chip'; chip.type = 'button'; chip.textContent = 'Summarize'; document.body.appendChild(chip);
  const panel = document.createElement('div'); panel.id = 'cpPanel'; panel.className = 'cp-panel'; panel.innerHTML = '<div class="cp-head"><b>Coach</b><button type="button" id="cpClose" aria-label="Close">×</button></div><div id="cpBody" class="cp-body"></div>'; document.body.appendChild(panel);
  btn.onclick = () => { if (panel.classList.contains('show')) closePanel(); else openPanel(); };
  chip.onclick = () => { if (!enabled) return; if (L.on) { stopPlayback(); sendTurn(summaryPrompt()); setStatus('Summarizing…', 'speak'); } else liveStart('summary'); };
  $('#cpClose').onclick = () => closePanel();
};
S3.coachUnmount = () => { liveStop(); ['cpBtn', 'cpPanel', 'cpChip'].forEach((id) => { const e = document.getElementById(id); if (e) e.remove(); }); enabled = null; };
S3.coachRefresh = () => { if ($('#cpPanel') && $('#cpPanel').classList.contains('show')) openPanel(); };

// ---------------- dashboard insights card (written analysis) ----------------
// Opening the app asks for a scan first; the analysis runs right after a scan is saved (or on request), so it always reflects fresh data.
S3.runInsights = () => {
  if (S3.state.insightsP) return S3.state.insightsP;
  S3.state.insightsAuto = true;
  const p = S3.api('ai:coach', null).then((r) => { S3.state.insights = { text: r.text, at: r.at }; S3.state.insightsErr = null; }).catch((e) => { S3.state.insightsErr = e.message; }).then(() => { S3.state.insightsP = null; });
  S3.state.insightsP = p; return p;
};
S3.aiCard = async () => {
  const el = $('#aicard'); if (!el) return;
  let st; try { st = await S3.api('ai:status'); } catch (e) { return; }
  if (!st.enabled) { el.innerHTML = '<div class="card flat" style="margin-bottom:16px"><div class="row"><div class="grow"><h3 style="margin:0 0 4px">AI insights</h3><p class="muted small" style="margin:0">Add your free Google AI key in Profile to get personalised suggestions and a talking coach.</p></div><button class="btn secondary" id="aigo">Set up</button></div></div>'; $('#aigo').onclick = () => S3.go('profile'); return; }
  if (!S3.state.insights && st.last) S3.state.insights = st.last;
  const body = (busy) => {
    const last = S3.state.insights; const err = S3.state.insightsErr;
    const head = '<div class="row" style="margin-bottom:6px"><h3 class="grow" style="margin:0">AI insights</h3><span class="small muted">' + (busy ? 'Updating…' : last ? 'Updated ' + esc(S3.fmtDate(last.at, true)) : '') + '</span><button class="btn ghost" id="airefresh"' + (busy ? ' disabled' : '') + '>Refresh</button></div>';
    return '<div class="card" style="margin-bottom:16px">' + head + (err && !busy ? '<p class="err" style="display:block;margin:0 0 8px">' + esc(err) + '</p>' : '') + '<div class="cp-result">' + (last ? md(last.text) : '<p class="muted small">Analyzing your scans and nutrition…</p>') + '</div></div>';
  };
  const show = (busy) => { el.innerHTML = body(busy); $('#airefresh').onclick = async () => { show(true); S3.state.insightsAuto = true; await S3.runInsights(); show(false); }; };
  if (S3.state.insightsP) { show(true); await S3.state.insightsP; show(false); return; }      // an analysis is already running (started after the scan)
  if (S3.state.scanDone || S3.state.insightsAuto) { if (S3.state.scanDone && !S3.state.insightsAuto) { show(true); await S3.runInsights(); } show(false); return; }
  // nothing yet this session: ask for the scan first
  const last = S3.state.insights;
  el.innerHTML = '<div class="card flat" style="margin-bottom:16px"><div class="row" style="gap:12px;flex-wrap:wrap"><div class="grow"><h3 style="margin:0 0 4px">Take your scan first</h3><p class="muted small" style="margin:0">Your AI insights are created from your newest scan, so do that first and they will appear here.' + (last ? ' Your last analysis was ' + esc(S3.fmtDate(last.at, true)) + '.' : '') + '</p></div><button class="btn" id="aiscan">Start scan</button><button class="btn ghost" id="aino">Analyze now</button></div></div>';
  $('#aiscan').onclick = () => S3.go('scan');
  $('#aino').onclick = async () => { show(true); await S3.runInsights(); show(false); };
};
})();
