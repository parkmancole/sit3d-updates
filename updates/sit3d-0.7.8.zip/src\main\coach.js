'use strict';
// AI coach for S*it3D (Google Gemini, "bring your own free key").
// Privacy by design: only an ANONYMOUS summary is ever sent (no name, email, username, birthday or ids), and only after the user has turned the
// coach on and acknowledged what is sent. The API key is stored per user, encrypted with Windows DPAPI (readable only by this Windows account).
// Node 12 compatible.
const fs = require('fs'), path = require('path'), https = require('https'), cp = require('child_process');

const TEXT_MODELS = ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.5-flash', 'gemini-3.1-flash-lite'];   // free-tier models get busy, so try several in turn
const TEXT_MODEL = TEXT_MODELS[0];
const LIVE_MODEL = 'gemini-3.8-live';
const VOICES = ['Kore', 'Aoede', 'Puck', 'Charon', 'Leda', 'Zephyr'];

// ---------- key storage (DPAPI) ----------
function ps(script, input) { return cp.execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], { input, encoding: 'utf8', windowsHide: true, timeout: 20000 }).trim(); }
function protect(text) { try { return 'dpapi:' + ps("Add-Type -AssemblyName System.Security; $t = [Console]::In.ReadToEnd(); [Convert]::ToBase64String([Security.Cryptography.ProtectedData]::Protect([Text.Encoding]::UTF8.GetBytes($t), $null, 'CurrentUser'))", text); } catch (e) { throw new Error('Could not protect the key on this PC.'); } }
function unprotect(blob) { if (!blob || blob.indexOf('dpapi:') !== 0) throw new Error('No key saved.'); return ps("Add-Type -AssemblyName System.Security; $b = [Console]::In.ReadToEnd().Trim(); [Text.Encoding]::UTF8.GetString([Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($b), $null, 'CurrentUser'))", blob.slice(6)); }

const cfgFile = (dataDir, userId) => path.join(dataDir, 'ai', userId + '.json');
function loadCfg(dataDir, userId) { try { return JSON.parse(fs.readFileSync(cfgFile(dataDir, userId), 'utf8')); } catch (e) { return {}; } }
function saveCfg(dataDir, userId, cfg) { fs.mkdirSync(path.join(dataDir, 'ai'), { recursive: true }); fs.writeFileSync(cfgFile(dataDir, userId), JSON.stringify(cfg)); }
function setKey(dataDir, userId, key, consent) {
  key = String(key || '').trim(); if (key.length < 20 || /\s/.test(key)) throw new Error('That does not look like a Google AI key.');
  if (!consent) throw new Error('Please tick the box to confirm you understand what is sent.');
  const cfg = loadCfg(dataDir, userId); cfg.enc = protect(key); cfg.consent = new Date().toISOString(); cfg.voice = cfg.voice || 'Kore'; saveCfg(dataDir, userId, cfg); return status(dataDir, userId);
}
function getKey(dataDir, userId) { const cfg = loadCfg(dataDir, userId); if (!cfg.enc || !cfg.consent) throw new Error('The AI coach is not set up yet. Add your Google AI key in Profile.'); return unprotect(cfg.enc); }
function clear(dataDir, userId) { try { fs.unlinkSync(cfgFile(dataDir, userId)); } catch (e) { /* none */ } }
function status(dataDir, userId) { const c = loadCfg(dataDir, userId); return { enabled: !!(c.enc && c.consent), voice: c.voice || 'Kore', voices: VOICES, since: c.consent || null, model: TEXT_MODEL, liveModel: LIVE_MODEL }; }
function setVoice(dataDir, userId, v) { const c = loadCfg(dataDir, userId); if (VOICES.indexOf(v) < 0) throw new Error('Unknown voice.'); c.voice = v; saveCfg(dataDir, userId, c); return status(dataDir, userId); }

// ---------- the anonymous packet ----------
const r1 = (v) => (v == null ? null : Math.round(v * 10) / 10);
function weekly(days, today, weeks) {
  const out = []; const NP = require('../pipeline/nutrition_progress.js');
  for (let w = weeks - 1; w >= 0; w--) {
    const end = NP.addDays(today, -7 * w), start = NP.addDays(end, -6); const g = NP.goodDays(days, start, NP.addDays(end, 1)); if (!g.length) continue;
    const avg = (k) => Math.round(g.reduce((a, x) => a + (x[k] || 0), 0) / g.length);
    out.push({ week_ending: end, days_logged: g.length, kcal: avg('kcal'), protein_g: avg('protein'), carbs_g: avg('carbs'), fat_g: avg('fat') });
  }
  return out;
}
// user: {sex, age, height_cm, goal, units}; scans: summaries (oldest first); progress: result of nutrition:progress; days: nutrition days
function buildPacket(user, scans, progress, days, today) {
  const ageBand = user.age == null ? null : Math.floor(user.age / 5) * 5 + '-' + (Math.floor(user.age / 5) * 5 + 4);
  const goal = String(user.goal || '').replace(/[^\w\s.,%+\-/'()]/g, '').slice(0, 140);
  return {
    profile: { sex: user.sex, age_range: ageBand, height_cm: user.height_cm, stated_goal: goal || null },
    scans: scans.slice(-8).map((s) => ({ date: String(s.created).slice(0, 10), weight_kg: s.weight_kg, body_fat_pct: s.body_fat_pct, lean_mass_kg: s.lean_mass_kg, waist_cm: s.waist_cm, hips_cm: s.hips_cm, chest_cm: s.chest_cm, shape_score: s.shape_score, posture_score: s.posture_score, bmi: s.bmi, visceral_index: s.visceral })),
    nutrition: progress && progress.hasData ? {
      last_7_days: progress.windows.w7, last_30_days: progress.windows.w30, last_90_days: progress.windows.w90, weekly_trend: weekly(days || {}, today, 12),
      between_scans: (progress.between || []).slice(-4), most_eaten_foods_30d: progress.top.byFrequency, biggest_protein_sources_30d: progress.top.byProtein,
      food_roi_last_14_days: progress.roi ? { note: 'best = highest protein per 100 kcal (keep); worst = most calories spent for the least protein (cut or swap). lowValueKcalPerDay is the calories per day that could be saved by cutting or swapping that food.', best: progress.roi.best, worst: progress.roi.worst, potentialSavingsPerDay: progress.roi.potentialSavingsPerDay } : null,
    } : null,
    caveats: ['Body measurements come from a home 3D scanner and are estimates; clothing and posture affect them.', 'Calories under 800 on a day are treated as incomplete logging.'],
  };
}
const SYSTEM = 'You are a supportive nutrition and body-composition coach inside a home body-scanner app. You are not a doctor and must not give medical advice, diagnose, or suggest supplements or drugs. ' +
  'Use ONLY the data provided. Be concrete: name the foods from the lists, give calorie and protein ranges in numbers, and say what to track next. If the data is too thin to conclude something, say what is missing. ' +
  'If calories look dangerously low or the user seems to be eating very little, gently suggest speaking with a doctor or dietitian. Keep a warm, plain tone and avoid shaming. Use the user\'s units where given in the data (kg/cm).';

// ---------- Gemini text ----------
function post(url, key, body) {
  return new Promise((resolve, reject) => {
    const u = new URL(url); const data = JSON.stringify(body);
    const req = https.request({ method: 'POST', hostname: u.hostname, path: u.pathname + u.search, headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key, 'Content-Length': Buffer.byteLength(data) }, timeout: 30000 }, (res) => {
      const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => { let j = null; try { j = JSON.parse(Buffer.concat(ch).toString('utf8')); } catch (e) { /* not json */ } resolve({ status: res.statusCode, json: j }); });
    });
    req.on('timeout', () => req.destroy(new Error('The AI service timed out.'))); req.on('error', reject); req.end(data);
  });
}
function explain(res) {
  const msg = res.json && res.json.error && res.json.error.message ? String(res.json.error.message).slice(0, 160) : '';
  if (res.status === 429) return 'The free AI limit was reached for now. Try again in a little while.';
  if (res.status === 503) return 'The free Google AI models are busy right now. Try again in a minute.';
  if (res.status === 400 && /API key/i.test(msg)) return 'Google did not accept the key. Check it in Profile.';
  if (res.status === 401 || res.status === 403) return 'Google did not accept the key. Check it in Profile.';
  return 'The AI service had a problem (' + res.status + ').' + (msg ? ' ' + msg : '');
}
async function coachText(key, packet, question) {
  const prompt = (question ? 'The user asks: ' + question + '\n\n' : 'Give a SHORT insights report for a busy reader who will skim it. Exactly these sections: "## Where you are" (at most 2 short bullets: progress against their goal and since the previous scan, and whether calories and protein support it; if no goal is stated just say so in a few words, do not dwell on it), "## Best value foods" (the 3 best from food_roi_last_14_days.best, one bullet each: bold short food name, then at most 6 words), "## Foods to cut or swap" (the 3 worst from food_roi_last_14_days.worst, one bullet each: bold short food name, a dash, the kcal per day saved; then on the NEXT line, indented by two spaces and NOT starting with a dash, write Swap for: and the replacement), "## Next steps" (exactly 3 bullets, at most 10 words each). Shorten food names (drop brand prefixes and serving counts). No filler, no caveats about short time windows unless they change the advice.\n\n') + 'DATA (anonymous):\n' + JSON.stringify(packet);
  const body = {
    systemInstruction: { parts: [{ text: SYSTEM + ' Format: short markdown with "## " headings and "- " bullets, under 130 words.' }] },
    contents: [{ role: 'user', parts: [{ text: prompt }] }], generationConfig: { temperature: 0.4, maxOutputTokens: 1500 },
  };
  let res = null;
  for (const model of TEXT_MODELS) {
    try { res = await post('https://generativelanguage.googleapis.com/v1beta/models/' + model + ':generateContent', key, body); } catch (e) { res = { status: 0, json: null }; continue; }   // timeout: try the next model
    if (res.status === 200 && res.json) break;
    if (res.status === 401 || res.status === 403 || (res.status === 400 && res.json && res.json.error && /API key/i.test(res.json.error.message || ''))) break;   // a bad key will not get better
  }
  if (!res || res.status !== 200 || !res.json) throw new Error(res && res.status ? explain(res) : 'The AI service did not answer in time. Try again in a moment.');
  const c = res.json.candidates && res.json.candidates[0]; const text = c && c.content && c.content.parts ? c.content.parts.map((p) => p.text || '').join('').trim() : '';
  if (!text) throw new Error('The AI returned an empty answer. Try again.');
  return text;
}

// ---------- Live voice (the renderer opens the WebSocket; this prepares its configuration) ----------
function liveConfig(dataDir, userId, packet) {
  const key = getKey(dataDir, userId); const c = loadCfg(dataDir, userId);
  const system = SYSTEM + ' You are speaking out loud with the user: use short spoken sentences, no markdown, no lists read symbol by symbol. When asked to walk them through everything, cover in order: latest scan and body composition, how it changed, nutrition and food choices, then three concrete suggestions, and ask if they want to go deeper on anything. ' +
    'You may answer questions about this data only.\n\nDATA (anonymous):\n' + JSON.stringify(packet);
  return { key, model: 'models/' + LIVE_MODEL, voice: c.voice || 'Kore', system };
}

module.exports = { setKey, getKey, clear, status, setVoice, buildPacket, coachText, liveConfig, weekly, SYSTEM, TEXT_MODEL, LIVE_MODEL, protect, unprotect };
