(function () {
'use strict';
// Shared helpers: backend calls, formatting, units, icons, sound/voice.
const { ipcRenderer } = require('electron');
window.S3 = window.S3 || {};
const S3 = window.S3;

S3.api = async (name, ...args) => { const r = await ipcRenderer.invoke(name, ...args); if (!r.ok) throw new Error(r.error); return r.data; };
S3.on = (ch, fn) => { ipcRenderer.removeAllListeners(ch); ipcRenderer.on(ch, (e, p) => fn(p)); };
S3.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
S3.$ = (sel, el) => (el || document).querySelector(sel);
S3.$$ = (sel, el) => Array.from((el || document).querySelectorAll(sel));
S3.toast = (msg, ms = 3600) => { const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; document.body.appendChild(t); setTimeout(() => t.remove(), ms); };

// ---- units ----
const imperial = () => S3.state && S3.state.user && S3.state.user.units === 'imperial';
S3.unitsLen = () => (imperial() ? 'in' : 'cm'); S3.unitsWt = () => (imperial() ? 'lb' : 'kg');
S3.cm = (v, d = 1) => (v == null ? '—' : (imperial() ? (v / 2.54).toFixed(d) : v.toFixed(d)));
S3.cmVal = (v) => (v == null ? null : (imperial() ? v / 2.54 : v));
S3.kg = (v, d = 1) => (v == null ? '—' : (imperial() ? (v * 2.2046226).toFixed(d) : v.toFixed(d)));
S3.kgVal = (v) => (v == null ? null : (imperial() ? v * 2.2046226 : v));
S3.height = (cm) => { if (cm == null) return '—'; if (!imperial()) return cm.toFixed(0) + ' cm'; const i = cm / 2.54; return `${Math.floor(i / 12)}′ ${Math.round(i % 12)}″`; };
S3.fmtDate = (iso, long) => { const d = new Date(iso); return long ? d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: '2-digit' }); };
S3.fmtDur = (s) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

// ---- icons (stroke) ----
const ic = (d) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${d}</svg>`;
S3.icon = {
  food: ic('<path d="M6 3v8a3 3 0 0 0 3 3v7"/><path d="M9 3v6"/><path d="M12 3v8"/><path d="M18 3c-2 2-3 5-3 8h3v10"/>'),
  dash: ic('<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>'),
  scan: ic('<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><circle cx="12" cy="9" r="2.4"/><path d="M7.5 18c.6-2.6 2.4-4 4.5-4s3.9 1.4 4.5 4"/>'),
  hist: ic('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>'),
  user: ic('<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>'),
  out: ic('<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>'),
  up: '▲', down: '▼',
};

// ---- sound & voice (Web Audio; no assets needed) ----
let ctx = null;
const ac = () => { if (!ctx) { try { ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: 'interactive' }); } catch (e) { try { ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e2) { ctx = null; } } } if (ctx && ctx.state === 'suspended') { try { ctx.resume(); } catch (e) { /* ignore */ } } return ctx; };
// warm the audio engine up front so the first key press is not late
let keyBuf = null;
function keyBuffer() { const a = ac(); if (!a) return null; if (!keyBuf) { const n = Math.floor(a.sampleRate * 0.05); keyBuf = a.createBuffer(1, n, a.sampleRate); const d = keyBuf.getChannelData(0); for (let i = 0; i < n; i++) { const t = i / a.sampleRate; d[i] = Math.sin(2 * Math.PI * 1000 * t) * Math.exp(-t * 70) * 0.5; } } return keyBuf; }
try { window.addEventListener('pointerdown', () => { ac(); keyBuffer(); }, { once: true, capture: true }); setTimeout(() => { ac(); keyBuffer(); }, 300); } catch (e) { /* ignore */ }
function tone(freq, dur, when = 0, vol = 0.18, type = 'sine') {
  const a = ac(); if (!a) return; const o = a.createOscillator(), g = a.createGain(); o.type = type; o.frequency.value = freq; o.connect(g); g.connect(a.destination);
  const t = a.currentTime + when; g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t + dur); o.start(t); o.stop(t + dur + 0.02);
}
S3.sfx = {
  enabled: () => !(S3.state && S3.state.user && S3.state.user.muted),
  key() { if (!this.enabled()) return; const a = ac(), b = keyBuffer(); if (!a || !b) return; const s = a.createBufferSource(); s.buffer = b; s.connect(a.destination); s.start(0); },
  tick() { if (this.enabled()) tone(880, 0.12, 0, 0.16); }, countdown() { if (this.enabled()) tone(660, 0.18, 0, 0.2); },
  go() { if (this.enabled()) { tone(1046, 0.5, 0, 0.22); tone(1568, 0.5, 0.0, 0.1); } },
  armed() { if (this.enabled()) { tone(523, 0.14, 0); tone(784, 0.2, 0.15); } },
  done() { if (this.enabled()) { tone(523, 0.16, 0); tone(659, 0.16, 0.16); tone(784, 0.16, 0.32); tone(1046, 0.5, 0.48); } },
  error() { if (this.enabled()) { tone(300, 0.25, 0, 0.2, 'triangle'); tone(220, 0.35, 0.22, 0.2, 'triangle'); } },
};
S3.VOICE = { voice_on: 'Voice guidance is on.', homing: 'Please stay off the platform while it lines itself up.', armed: 'Step onto the platform. Face the pole, and hold both handle buttons.', n3: 'Three.', n2: 'Two.', n1: 'One.', scanning: 'Scanning. Stay perfectly still.', done: 'Scan complete. Keep holding until the platform stops, then you can step off.', results: 'Your results are ready.', retry: "That scan didn't finish. Please try again.",
  tut1: 'First, wear underwear or very tight, minimal clothing. The scanner measures whatever it sees, so loose clothes add size.', tut2: 'Tie back long hair. Take off your shoes, jewellery, and empty your pockets.', tut3: 'When the platform has lined itself up, step on and stand on the footprints, facing the pole, with your feet shoulder-width apart.', tut4: 'Hold both handle buttons the whole time. The scan starts four seconds after you grip them, and takes about forty seconds.', tut5: 'Stand completely still while the platform turns once. No talking, no shifting, and look straight ahead. Let go only when it stops.' };
// Plays a pre-recorded clip <data folder>/voice/<key>.mp3 (or .wav) if present, otherwise falls back to the system voice.
S3._voice = { cur: null };
S3.speak = (text, key, onend) => {
  try {
    if (!(S3.state && S3.state.voice)) return;
    const say = () => { try { const u = new SpeechSynthesisUtterance(text); u.rate = 1.0; if (onend) { u.onend = onend; u.onerror = onend; } speechSynthesis.cancel(); speechSynthesis.speak(u); } catch (e) { /* no voice */ } };
    const info = S3.state.info || {}; if (!key || !(info.dataDir || info.appRoot)) return say();
    try { if (S3._voice.cur) S3._voice.cur.pause(); speechSynthesis.cancel(); } catch (e) { /* ignore */ }
    const slash = (d) => 'file:///' + String(d).split(String.fromCharCode(92)).join('/');
    const bases = [];
    if (info.dataDir) bases.push(slash(info.dataDir) + '/voice/' + key);     // your own recordings win
    if (info.appRoot) bases.push(slash(info.appRoot) + '/voice/' + key);     // the clips that ship with the app
    const cands = []; bases.forEach(b => ['.mp3', '.wav', '.ogg'].forEach(x => cands.push(b + x)));
    const tryNext = (i) => { if (i >= cands.length) return say(); const a = new Audio(cands[i]); a.volume = 0.35; if (onend) a.onended = onend; a.onerror = () => tryNext(i + 1); S3._voice.cur = a; a.play().catch(() => tryNext(i + 1)); };
    tryNext(0);
  } catch (e) { /* ignore */ }
};
S3.say = (key) => S3.speak(S3.VOICE[key], key);

})();
