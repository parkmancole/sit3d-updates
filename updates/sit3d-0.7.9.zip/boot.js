'use strict';
// S*it3D launcher. This file is deliberately tiny and never changes through updates.
// It starts the newest verified update from %LOCALAPPDATA%\sit3d\code if there is one, otherwise the code bundled next to it.
// Safety net: a new version must reach "healthy" (window loaded) within 2 start attempts, otherwise it is dropped and the previous code runs.
const fs = require('fs'), path = require('path');

const BUNDLED = __dirname;
const CODE = path.join(process.env.LOCALAPPDATA || path.join(process.env.USERPROFILE || '', 'AppData', 'Local'), 'sit3d', 'code');
const CUR = path.join(CODE, 'current.json');
const readJson = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return null; } };
const writeJson = (f, v) => { try { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v)); } catch (e) { /* ignore */ } };
function exists(p) { try { fs.accessSync(p); return true; } catch (e) { return false; } }

let root = BUNDLED, cur = readJson(CUR);
if (cur && cur.dir && exists(path.join(CODE, cur.dir, 'src', 'main', 'main.js'))) {
  if (!cur.good) cur.tried = (cur.tried || 0) + 1;
  if (!cur.good && cur.tried > 2) {                       // new version never became healthy: roll back
    try { fs.writeFileSync(path.join(CODE, 'rolled_back.txt'), new Date().toISOString() + ' ' + cur.version + '\n'); } catch (e) { /* ignore */ }
    if (cur.prev && exists(path.join(CODE, cur.prev, 'src', 'main', 'main.js'))) cur = { version: cur.prevVersion || '', dir: cur.prev, good: true, tried: 0 };
    else cur = null;
    if (cur) writeJson(CUR, cur); else { try { fs.unlinkSync(CUR); } catch (e) { /* ignore */ } }
  } else writeJson(CUR, cur);
  if (cur) root = path.join(CODE, cur.dir);
}

global.__sit3d = {
  bundledRoot: BUNDLED, codeDir: CODE, root, version: (cur && cur.version) || null,
  markGood() { const c = readJson(CUR); if (c && !c.good) { c.good = true; c.tried = 0; writeJson(CUR, c); } },
};
try { require(path.join(root, 'src', 'main', 'main.js')); }
catch (e) {                                              // the updated code would not even load: drop it and run the bundled code
  if (root === BUNDLED) throw e;
  try { fs.writeFileSync(path.join(CODE, 'rolled_back.txt'), new Date().toISOString() + ' load error: ' + String(e && e.message) + '\n'); fs.unlinkSync(CUR); } catch (e2) { /* ignore */ }
  global.__sit3d.root = BUNDLED; global.__sit3d.version = null;
  require(path.join(BUNDLED, 'src', 'main', 'main.js'));
}
