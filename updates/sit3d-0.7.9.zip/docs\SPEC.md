# S*it3D - product spec (v0.1)
Local, no-admin Windows app that drives the ProScanner hardware (3x PrimeSense depth sensors + HID turntable), reconstructs a 3D body model, estimates measurements, and tracks progress per user.

## What the original cloud returned (public sources: fit3d.com/reporting, support articles, reseller guides)
Body fat %, fat mass, lean mass (appendicular lean mass in studies), visceral fat, metabolic age, BMR; circumference measurements (12+ sites; 400+ in the cloud); Body Shape Rating 0-100 (higher = lower risk); posture (head/shoulder/hip tilt and shift; balance = weight over four panels); 3D avatar; two-scan side-by-side comparison; goals; glossary; results in ~1-4 min; scan ~35-40 s; rescan every 30-90 days. Formulas are proprietary and not published.

## What S*it3D computes (own, documented methods - ALL ESTIMATES, not medical advice)
- Height, weight (scale: 4 corner loads + total from the turntable), BMI, BMR (Mifflin-St Jeor), waist/hip ratio, waist/height ratio.
- Circumferences from 3D cross-sections: neck, shoulder width, chest, waist, hips, upper thigh L/R, calf L/R, bicep L/R, forearm L/R.
- Body fat % (US Navy circumference method; BMI/age/sex Deurenberg cross-check), fat mass, lean mass, metabolic age (BMR-matching), visceral-fat index (waist/height based), Shape Score 0-100 (waist/height + WHR + ABSI based).
- Posture from the 3D model: head forward shift, head tilt, shoulder tilt/shift, hip tilt/shift, knee/ankle alignment where visible; balance from the four load cells.
- Progress: per-user history of every metric, deltas between scans, goals, side-by-side 3D viewer.
## Hardware pipeline (calibrated from scan 1)
Depth PNG (rotate 180 deg) -> back-project (fx~575.8) -> level/pose (3 cameras at 397/849/1666 mm, 1077 mm from the axis) -> unwind by platform angle theta(t) (omega ~9.8 deg/s CCW, derived from the HID scanStart/scanComplete times) -> multi-frame voxel support filter -> body model.
## Accounts and data
Local accounts (name, username, sex, date of birth, height, units, scrypt-hashed password); data under %APPDATA%\sit3d\users\<id>\scans\<scanId>\ (result.json, body.bin, optional raw frames). No cloud, no network.
