# Faithful standalone port of cv-capture.exe's capture loop (no admin, no service, no cloud).
# Uses the service's own 32-bit OpenNI2.dll + drivers (PS1080.ini overrides apply), depth video mode = index 4 of the sensor's
# supported-mode list (640x480 @30 fps, 1 mm), pixels > Cutoff (1625 mm) zeroed, keep 1 of every Keep loop iterations
# (type 3 = 8), 16-bit grayscale PNGs written at the end to <OutDir>\pkg-<Name>-raw\sensor_<i>\NNN.png.
# EXTRA vs the original: iterations.csv (host time + per-sensor timestamp/frameIndex for EVERY loop iteration) and capture_meta.json.
#
# Run in 32-bit, STA PowerShell:
#   C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe -STA -ExecutionPolicy Bypass -File Capture-Depth.ps1 -Mode Timed -Seconds 6
#   ... -Mode Signal   : stream idle until a file named START appears in OutDir\_signals, record until STOP appears (max 60 s like the original).
#   ... -SelfTest      : no sensors needed; writes + re-reads a synthetic 16-bit PNG to prove the PNG path works.
param(
  [string]$ServiceDir = "C:\Apps\ProScanner\Service",
  [string]$OutDir = (Join-Path ([Environment]::GetFolderPath('Desktop')) "fit3d_captures"),
  [string]$Name = (Get-Date -Format "yyyyMMddHHmmss"),
  [ValidateSet('Timed','Signal')][string]$Mode = 'Timed',
  [int]$Seconds = 6,
  [int]$Expect = 3,
  [int]$Keep = 8,
  [int]$Cutoff = 1625,
  [int]$ModeIndex = 4,
  [int]$MaxMs = 60000,
  [switch]$SelfTest
)
$ErrorActionPreference = 'Stop'
if ([IntPtr]::Size -ne 4) { throw "Run in 32-bit PowerShell (SysWOW64)." }
if ([Threading.Thread]::CurrentThread.GetApartmentState() -ne 'STA') { Write-Warning "Not STA: start powershell with -STA if PNG encoding fails." }

$cs = @"
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Media;
using System.Windows.Media.Imaging;

public static class OniN {
  const string D = "OpenNI2.dll";
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniInitialize(int apiVersion);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern void oniShutdown();
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniGetDeviceList(out IntPtr devs, out int n);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniReleaseDeviceList(IntPtr devs);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniDeviceOpen(IntPtr uri, out IntPtr dev);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniDeviceClose(IntPtr dev);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr oniDeviceGetSensorInfo(IntPtr dev, int sensorType);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniDeviceCreateStream(IntPtr dev, int sensorType, out IntPtr stream);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniStreamSetProperty(IntPtr stream, int id, IntPtr data, int size);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniStreamGetProperty(IntPtr stream, int id, IntPtr data, ref int size);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniStreamStart(IntPtr stream);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern void oniStreamStop(IntPtr stream);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern void oniStreamDestroy(IntPtr stream);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern int oniStreamReadFrame(IntPtr stream, out IntPtr frame);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern void oniFrameRelease(IntPtr frame);
  [DllImport(D, CallingConvention=CallingConvention.Cdecl)] public static extern IntPtr oniGetExtendedError();
  public static string Err() { IntPtr p = oniGetExtendedError(); return p == IntPtr.Zero ? "" : Marshal.PtrToStringAnsi(p); }
}

public class DepthCapture {
  class Dev {
    public IntPtr H, S; public string Uri; public int W, Ht; public float Hfov, Vfov; public List<short[]> Frames = new List<short[]>();
  }
  public int Expect = 3, Keep = 8, Cutoff = 1625, ModeIndex = 4;
  public string PkgDir, Name, ServiceDir;
  public Action<string> Log = delegate(string s) { Console.WriteLine(s); };
  List<Dev> devs = new List<Dev>();
  StringBuilder iters = new StringBuilder();
  public long Iterations; public DateTime StartUtc, StopUtc; public int RecMs;

  public void Init() {
    int rc = OniN.oniInitialize(2002);
    if (rc != 0) throw new Exception("oniInitialize failed " + rc + " " + OniN.Err());
    IntPtr pd; int n;
    OniN.oniGetDeviceList(out pd, out n);
    Log("devices found: " + n);
    if (n != Expect) throw new Exception("Expected " + Expect + " devices but found " + n);
    int sz = 3 * 256 + 4;
    for (int i = 0; i < n; i++) {
      Dev d = new Dev();
      IntPtr p = new IntPtr(pd.ToInt32() + i * sz);
      d.Uri = Marshal.PtrToStringAnsi(p);
      rc = OniN.oniDeviceOpen(p, out d.H);
      if (rc != 0) throw new Exception("oniDeviceOpen failed " + rc + " " + OniN.Err());
      rc = OniN.oniDeviceCreateStream(d.H, 3, out d.S);
      if (rc != 0) throw new Exception("create depth stream failed " + rc + " " + OniN.Err());
      IntPtr si = OniN.oniDeviceGetSensorInfo(d.H, 3);
      int cnt = Marshal.ReadInt32(si, 4);
      IntPtr arr = Marshal.ReadIntPtr(si, 8);
      if (ModeIndex >= cnt) throw new Exception("mode index " + ModeIndex + " >= " + cnt);
      IntPtr mode = new IntPtr(arr.ToInt32() + 16 * ModeIndex);   // supportedVideoModes + 0x40, as cv-capture does
      rc = OniN.oniStreamSetProperty(d.S, 3, mode, 16);
      if (rc != 0) throw new Exception("set video mode failed " + rc + " " + OniN.Err());
      Log("sensor_" + i + " " + d.Uri + " mode idx " + ModeIndex + ": fmt=" + Marshal.ReadInt32(mode, 0) + " " + Marshal.ReadInt32(mode, 4) + "x" + Marshal.ReadInt32(mode, 8) + "@" + Marshal.ReadInt32(mode, 12));
      IntPtr fb = Marshal.AllocHGlobal(8); int fsz = 4;
      if (OniN.oniStreamGetProperty(d.S, 1, fb, ref fsz) == 0) d.Hfov = BitConverter.ToSingle(BitConverter.GetBytes(Marshal.ReadInt32(fb)), 0);
      fsz = 4; if (OniN.oniStreamGetProperty(d.S, 2, fb, ref fsz) == 0) d.Vfov = BitConverter.ToSingle(BitConverter.GetBytes(Marshal.ReadInt32(fb)), 0);
      Marshal.FreeHGlobal(fb);
      Log("sensor_" + i + " FOV h=" + d.Hfov.ToString("R", System.Globalization.CultureInfo.InvariantCulture) + " v=" + d.Vfov.ToString("R", System.Globalization.CultureInfo.InvariantCulture) + " rad");
      rc = OniN.oniStreamStart(d.S);
      if (rc != 0) throw new Exception("start stream failed " + rc + " " + OniN.Err());
      devs.Add(d);
    }
    OniN.oniReleaseDeviceList(pd);
  }

  // read and discard frames from all sensors until stopWait() is true (the 'capturing but not recording' phase)
  public void Idle(Func<bool> startRequested) {
    long frames = 0;
    while (!startRequested()) {
      for (int i = 0; i < devs.Count; i++) {
        IntPtr f; int rc = OniN.oniStreamReadFrame(devs[i].S, out f);
        if (rc != 0) throw new Exception("read frame failed " + rc + " " + OniN.Err());
        OniN.oniFrameRelease(f);
      }
      frames++;
    }
    Log("idle phase read " + frames + " iterations");
  }

  public void Record(Func<bool> stopRequested, int maxMs) {
    Stopwatch sw = Stopwatch.StartNew();
    StartUtc = DateTime.UtcNow;
    iters.AppendLine("iter,host_ms,kept," + HeaderCols());
    long iter = 0;
    while (true) {
      if (stopRequested() || sw.ElapsedMilliseconds >= maxMs) break;
      bool keep = (iter % Keep) == 0;
      StringBuilder row = new StringBuilder();
      row.Append(iter).Append(',').Append(sw.ElapsedMilliseconds).Append(',').Append(keep ? 1 : 0);
      for (int i = 0; i < devs.Count; i++) {
        Dev d = devs[i];
        IntPtr f; int rc = OniN.oniStreamReadFrame(d.S, out f);
        if (rc != 0) throw new Exception("read frame failed " + rc + " " + OniN.Err());
        IntPtr data = Marshal.ReadIntPtr(f, 4);
        long ts = Marshal.ReadInt64(f, 16);
        int fidx = Marshal.ReadInt32(f, 24);
        int w = Marshal.ReadInt32(f, 28), h = Marshal.ReadInt32(f, 32), stride = Marshal.ReadInt32(f, 64);
        row.Append(',').Append(ts).Append(',').Append(fidx);
        if (keep) {
          d.W = w; d.Ht = h;
          short[] buf = new short[w * h];
          if (stride == w * 2) Marshal.Copy(data, buf, 0, w * h);
          else for (int y = 0; y < h; y++) Marshal.Copy(new IntPtr(data.ToInt32() + y * stride), buf, y * w, w);
          for (int k = 0; k < buf.Length; k++) if ((ushort)buf[k] > Cutoff) buf[k] = 0;
          d.Frames.Add(buf);
        }
        OniN.oniFrameRelease(f);
      }
      iters.AppendLine(row.ToString());
      iter++;
    }
    Iterations = iter; StopUtc = DateTime.UtcNow; RecMs = (int)sw.ElapsedMilliseconds;
    Log("recorded " + iter + " iterations in " + RecMs + " ms; kept frames/sensor: " + devs[0].Frames.Count);
  }

  string HeaderCols() {
    StringBuilder s = new StringBuilder();
    for (int i = 0; i < devs.Count; i++) { if (i > 0) s.Append(','); s.Append("ts" + i + ",fidx" + i); }
    return s.ToString();
  }

  public static void WritePng(string path, short[] px, int w, int h) {
    BitmapSource bmp = BitmapSource.Create(w, h, 96, 96, PixelFormats.Gray16, null, px, w * 2);
    PngBitmapEncoder enc = new PngBitmapEncoder();
    enc.Frames.Add(BitmapFrame.Create(bmp));
    using (FileStream fs = File.Create(path)) enc.Save(fs);
  }

  public void Save() {
    Directory.CreateDirectory(PkgDir);
    for (int i = 0; i < devs.Count; i++) {
      string sd = Path.Combine(PkgDir, "sensor_" + i);
      Directory.CreateDirectory(sd);
      for (int j = 0; j < devs[i].Frames.Count; j++)
        WritePng(Path.Combine(sd, j.ToString().PadLeft(3, '0') + ".png"), devs[i].Frames[j], devs[i].W, devs[i].Ht);
      Log("Saved " + devs[i].Frames.Count + " frames to sensor_" + i);
    }
    File.WriteAllText(Path.Combine(PkgDir, "iterations.csv"), iters.ToString());
    StringBuilder m = new StringBuilder();
    m.AppendLine("{");
    m.AppendLine("  \"name\": \"" + Name + "\", \"keep\": " + Keep + ", \"cutoff_mm\": " + Cutoff + ", \"mode_index\": " + ModeIndex + ",");
    m.AppendLine("  \"start_utc\": \"" + StartUtc.ToString("o") + "\", \"stop_utc\": \"" + StopUtc.ToString("o") + "\", \"record_ms\": " + RecMs + ", \"iterations\": " + Iterations + ",");
    m.Append("  \"sensors\": [");
    for (int i = 0; i < devs.Count; i++) { if (i > 0) m.Append(", "); m.Append("{\"index\": " + i + ", \"uri\": \"" + devs[i].Uri.Replace("\\", "\\\\") + "\", \"frames\": " + devs[i].Frames.Count + ", \"hfov_rad\": " + devs[i].Hfov.ToString("R", System.Globalization.CultureInfo.InvariantCulture) + ", \"vfov_rad\": " + devs[i].Vfov.ToString("R", System.Globalization.CultureInfo.InvariantCulture) + "}"); }
    m.AppendLine("]");
    m.AppendLine("}");
    File.WriteAllText(Path.Combine(PkgDir, "capture_meta.json"), m.ToString());
  }

  public void Shutdown() {
    foreach (Dev d in devs) {
      if (d.S != IntPtr.Zero) { OniN.oniStreamStop(d.S); OniN.oniStreamDestroy(d.S); }
      if (d.H != IntPtr.Zero) OniN.oniDeviceClose(d.H);
    }
    OniN.oniShutdown();
  }
}
"@
Add-Type -TypeDefinition $cs -ReferencedAssemblies 'PresentationCore','WindowsBase','System.Xaml' -Language CSharp

$null = New-Item -ItemType Directory -Force $OutDir
$logPath = Join-Path $OutDir "capture_$Name.log"
function L($s) { $line = "$(Get-Date -Format 'HH:mm:ss.fff') $s"; Write-Host $line; Add-Content -Path $logPath -Value $line }

if ($SelfTest) {
  $w = 640; $h = 480; $px = New-Object 'int16[]' ($w * $h)
  for ($i = 0; $i -lt $px.Length; $i++) { $px[$i] = [int16](($i % $w) * 3) }     # 0..1917 mm gradient
  $p = Join-Path $OutDir "selftest_$Name.png"
  [DepthCapture]::WritePng($p, $px, $w, $h)
  $hdr = [int[]]([IO.File]::ReadAllBytes($p)[0..28])
  $bitDepth = $hdr[24]; $colorType = $hdr[25]
  $ww = ($hdr[16] -shl 24) + ($hdr[17] -shl 16) + ($hdr[18] -shl 8) + $hdr[19]
  $hh = ($hdr[20] -shl 24) + ($hdr[21] -shl 16) + ($hdr[22] -shl 8) + $hdr[23]
  L ("selftest PNG header: " + $ww + "x" + $hh + " bit_depth=" + $bitDepth + " color_type=" + $colorType + " (expect 640x480, 16, 0 = 16-bit grayscale) file=" + (Get-Item $p).Length + " bytes")
  L ("selftest OK: " + (($bitDepth -eq 16) -and ($colorType -eq 0) -and ($ww -eq 640) -and ($hh -eq 480)))
  return
}

$dll = Join-Path $ServiceDir "OpenNI2.dll"
if (-not (Test-Path $dll)) { throw "OpenNI2.dll not found in $ServiceDir" }
Set-Location $ServiceDir                        # OpenNI finds OpenNI2\Drivers + OpenNI.ini relative to the dll / cwd
$env:PATH = "$ServiceDir;$env:PATH"
$sigDir = Join-Path $OutDir "_signals"; $null = New-Item -ItemType Directory -Force $sigDir
$startF = Join-Path $sigDir "START"; $stopF = Join-Path $sigDir "STOP"
Remove-Item $startF, $stopF -ErrorAction SilentlyContinue

$cap = New-Object DepthCapture
$cap.Expect = $Expect; $cap.Keep = $Keep; $cap.Cutoff = $Cutoff; $cap.ModeIndex = $ModeIndex; $cap.Name = $Name
$cap.PkgDir = Join-Path $OutDir "pkg-$Name-raw"
$cap.Log = [Action[string]]{ param($s) L $s }
try {
  $sw = [Diagnostics.Stopwatch]::StartNew()
  $cap.Init()
  L ("init took " + $sw.ElapsedMilliseconds + " ms")
  if ($Mode -eq 'Timed') {
    $t = [Diagnostics.Stopwatch]::StartNew()
    $cap.Idle([Func[bool]]{ $t.ElapsedMilliseconds -ge 1000 })     # 1 s of streaming before recording
    $r = [Diagnostics.Stopwatch]::StartNew()
    $cap.Record([Func[bool]]{ $r.ElapsedMilliseconds -ge ($Seconds * 1000) }, $MaxMs)
  } else {
    L "READY: streaming, waiting for $startF"
    $cap.Idle([Func[bool]]{ Test-Path $startF })
    L "START signal seen"
    $cap.Record([Func[bool]]{ Test-Path $stopF }, $MaxMs)
  }
  $cap.Save()
  L "DONE: $($cap.PkgDir)"
} finally {
  try { $cap.Shutdown() } catch { L "shutdown error: $_" }
}
