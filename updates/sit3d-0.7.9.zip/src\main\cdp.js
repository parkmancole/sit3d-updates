'use strict';
// Drives the user's real Microsoft Edge / Google Chrome through the DevTools protocol, with a private profile folder owned by S*it3D.
// Why: the browser built into this app is too old (Chromium 85) for modern sign-in pages (MyFitnessPal, MyNetDiary, Google), but Edge is
// installed on every Windows PC and always current. The user signs in inside a normal Edge window; the app later reuses that profile in a
// hidden (headless) Edge to read the user's own diary pages. Node 12 compatible, no dependencies (includes a tiny WebSocket client).
const fs = require('fs'), path = require('path'), net = require('net'), http = require('http'), crypto = require('crypto'), cp = require('child_process');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function findBrowser() {
  const pf = process.env['ProgramFiles'] || 'C:\\Program Files', pf86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', la = process.env.LOCALAPPDATA || '';
  const c = [
    path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'), path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'), path.join(la, 'Google', 'Chrome', 'Application', 'chrome.exe'),
  ];
  for (const p of c) { try { fs.accessSync(p); return p; } catch (e) { /* next */ } }
  return null;
}

function freePort() { return new Promise((resolve, reject) => { const s = net.createServer(); s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => resolve(p)); }); s.on('error', reject); }); }
function getJson(port, p) { return new Promise((resolve, reject) => { const req = http.get({ host: '127.0.0.1', port, path: p, timeout: 3000 }, (res) => { const ch = []; res.on('data', (c) => ch.push(c)); res.on('end', () => { try { resolve(JSON.parse(Buffer.concat(ch).toString('utf8'))); } catch (e) { reject(e); } }); }); req.on('error', reject); req.on('timeout', () => req.destroy(new Error('timeout'))); }); }

// ---- minimal WebSocket client (text frames only) ----
function wsConnect(urlStr) {
  return new Promise((resolve, reject) => {
    const u = new URL(urlStr); const key = crypto.randomBytes(16).toString('base64');
    const req = http.request({ host: u.hostname, port: u.port, path: u.pathname + u.search, headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Key': key, 'Sec-WebSocket-Version': '13' } });
    req.on('upgrade', (res, socket, head) => {
      let buf = head && head.length ? Buffer.from(head) : Buffer.alloc(0), frag = []; const api = { onmessage: null, onclose: null, closed: false };
      const send = (op, payload) => { const mask = crypto.randomBytes(4), len = payload.length; let hdr; if (len < 126) hdr = Buffer.from([0x80 | op, 0x80 | len]); else if (len < 65536) { hdr = Buffer.alloc(4); hdr[0] = 0x80 | op; hdr[1] = 0x80 | 126; hdr.writeUInt16BE(len, 2); } else { hdr = Buffer.alloc(10); hdr[0] = 0x80 | op; hdr[1] = 0x80 | 127; hdr.writeUInt32BE(0, 2); hdr.writeUInt32BE(len, 6); } const body = Buffer.alloc(len); for (let i = 0; i < len; i++) body[i] = payload[i] ^ mask[i % 4]; socket.write(Buffer.concat([hdr, mask, body])); };
      api.send = (text) => { if (!api.closed) send(1, Buffer.from(text, 'utf8')); };
      api.close = () => { if (!api.closed) { api.closed = true; try { send(8, Buffer.alloc(0)); } catch (e) { /* ignore */ } try { socket.end(); } catch (e) { /* ignore */ } } };
      const parse = () => {
        for (;;) {
          if (buf.length < 2) return; const op = buf[0] & 0x0f, fin = (buf[0] & 0x80) !== 0; let len = buf[1] & 0x7f, off = 2;
          if (len === 126) { if (buf.length < 4) return; len = buf.readUInt16BE(2); off = 4; } else if (len === 127) { if (buf.length < 10) return; len = buf.readUInt32BE(2) * 4294967296 + buf.readUInt32BE(6); off = 10; }
          if (buf.length < off + len) return; const payload = buf.slice(off, off + len); buf = buf.slice(off + len);
          if (op === 8) { api.closed = true; if (api.onclose) api.onclose(); try { socket.end(); } catch (e) { /* ignore */ } return; }
          if (op === 9) { send(10, payload); continue; } if (op === 10) continue;
          frag.push(payload); if (fin) { const text = Buffer.concat(frag).toString('utf8'); frag = []; if (api.onmessage) api.onmessage(text); }
        }
      };
      socket.on('data', (d) => { buf = Buffer.concat([buf, d]); parse(); }); socket.on('close', () => { api.closed = true; if (api.onclose) api.onclose(); }); socket.on('error', () => { api.closed = true; });
      parse(); resolve(api);
    });
    req.on('response', () => reject(new Error('DevTools refused the connection.'))); req.on('error', reject); req.end();
  });
}

// ---- a driven browser page ----
async function launch(opts) {
  const exe = opts.exe || findBrowser(); if (!exe) throw new Error('Microsoft Edge or Google Chrome is needed for this connection, and neither was found on this PC.');
  fs.mkdirSync(opts.profileDir, { recursive: true }); const port = await freePort();
  const args = ['--user-data-dir=' + opts.profileDir, '--remote-debugging-port=' + port, '--remote-allow-origins=*', '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--disable-sync', '--disable-features=Translate,msEdgeSignIn,msEdgeShopping'];
  if (opts.headless) args.push('--headless=new', '--disable-gpu', '--window-size=1280,900', '--hide-scrollbars', '--mute-audio');
  else if (opts.app) args.push('--app=' + opts.url); else args.push(opts.url || 'about:blank');
  if (opts.headless) args.push('about:blank');   // navigate only after the user agent has been adjusted
  const child = cp.spawn(exe, args, { stdio: 'ignore', windowsHide: !!opts.headless }); let exited = false; child.on('exit', () => { exited = true; }); child.on('error', () => { exited = true; });
  // wait for the debugging endpoint and a page target
  let target = null; const t0 = Date.now();
  while (Date.now() - t0 < 20000 && !exited) { try { const list = await getJson(port, '/json'); target = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl); if (target) break; } catch (e) { /* not up yet */ } await sleep(300); }
  if (!target) { try { child.kill(); } catch (e) { /* ignore */ } throw new Error('The browser did not start.'); }
  const ws = await wsConnect(target.webSocketDebuggerUrl); let id = 0; const pending = new Map();
  ws.onmessage = (t) => { let m; try { m = JSON.parse(t); } catch (e) { return; } if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); if (m.error) p.reject(new Error(m.error.message || 'protocol error')); else p.resolve(m.result); } };
  const call = (method, params) => new Promise((resolve, reject) => { const i = ++id; pending.set(i, { resolve, reject }); ws.send(JSON.stringify({ id: i, method, params: params || {} })); setTimeout(() => { if (pending.has(i)) { pending.delete(i); reject(new Error('browser did not answer ' + method)); } }, 30000); });
  await call('Page.enable'); await call('Runtime.enable'); await call('Network.enable');
  if (opts.headless) { const v = await getJson(port, '/json/version').catch(() => ({})); const ua = String(v['User-Agent'] || '').replace('HeadlessChrome', 'Chrome'); if (ua) await call('Network.setUserAgentOverride', { userAgent: ua }); }
  const drv = {
    pid: child.pid, exited: () => exited,
    evalJs: async (expr) => { const r = await call('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw new Error('page script error: ' + String((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails.text).slice(0, 160)); return r.result ? r.result.value : undefined; },
    url: async () => { try { return await drv.evalJs('location.href'); } catch (e) { return ''; } },
    goto: async (u, waitMs, readyExpr) => { await call('Page.navigate', { url: u }); const t1 = Date.now(); await sleep(250); const expr = readyExpr || "document.readyState === 'complete'"; while (Date.now() - t1 < (waitMs || 25000)) { try { if (await drv.evalJs('!!(' + expr + ')')) return; } catch (e) { /* navigating */ } await sleep(150); } },
    // diary pages are plain server-rendered HTML: skip images, fonts, video, ads and trackers so each page loads in a second or two
    blockHeavy: async () => { try { await call('Network.setBlockedURLs', { urls: ['*.png', '*.jpg', '*.jpeg', '*.gif', '*.webp', '*.svg', '*.ico', '*.woff', '*.woff2', '*.ttf', '*.mp4', '*.webm', '*doubleclick*', '*googlesyndication*', '*google-analytics*', '*googletagmanager*', '*googletagservices*', '*adservice*', '*amazon-adsystem*', '*facebook.net*', '*facebook.com/tr*', '*criteo*', '*taboola*', '*outbrain*', '*scorecardresearch*', '*quantserve*', '*hotjar*', '*optimizely*', '*segment.*', '*branch.io*', '*braze*', '*onetrust*', '*cookielaw*', '*adnxs*', '*rubiconproject*', '*pubmatic*', '*openx*'] }); } catch (e) { /* optional */ } },
    cookies: async () => (await call('Network.getAllCookies')).cookies || [],
    persistSessionCookies: async (days) => { const exp = Math.floor(Date.now() / 1000) + 86400 * (days || 30); let n = 0; for (const c of await drv.cookies()) { if (c.session) { try { await call('Network.setCookie', { name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, expires: exp }); n++; } catch (e) { /* skip */ } } } return n; },
    close: async () => { try { await call('Browser.close'); } catch (e) { /* may drop the socket */ } for (let i = 0; i < 20 && !exited; i++) await sleep(150); if (!exited) { try { child.kill(); } catch (e) { /* ignore */ } await sleep(300); } try { ws.close(); } catch (e) { /* ignore */ } },
  };
  if (opts.headless && opts.blockHeavy) await drv.blockHeavy();
  if (opts.headless && opts.url) await drv.goto(opts.url);
  else if (opts.url) { const t2 = Date.now(); while (Date.now() - t2 < 25000) { try { const st = await drv.evalJs('document.readyState'); if (st === 'complete' && (await drv.url()) !== 'about:blank') break; } catch (e) { /* loading */ } await sleep(300); } }
  return drv;
}

module.exports = { findBrowser, launch, wsConnect, sleep };
