'use strict';
// Nutrition / weight import for S*it3D. No network: reads CSV exports from nutrition apps.
// Supported: MyFitnessPal (Nutrition-Summary and Measurement-Summary CSV from the data export),
//            Cronometer (dailysummary.csv), Lose It! and any CSV with a date column plus calories/protein/carbs/fat.
// (Node 12 compatible: no optional chaining.)

const NL = String.fromCharCode(10), CR = String.fromCharCode(13), BOM = String.fromCharCode(0xFEFF);

function parseCsv(text) {
  const rows = []; let row = [], cell = '', q = false;
  text = String(text).split(BOM).join('');
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += ch; }
    else if (ch === '"') q = true;
    else if (ch === ',') { row.push(cell); cell = ''; }
    else if (ch === NL || ch === CR) { if (ch === CR && text[i + 1] === NL) i++; row.push(cell); cell = ''; if (row.length > 1 || row[0] !== '') rows.push(row); row = []; }
    else cell += ch;
  }
  if (cell !== '' || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

function isoDate(s) {
  s = String(s || '').trim(); if (!s) return null;
  let m = s.split('T')[0].split(' ')[0];
  if (m.length >= 10 && m[4] === '-' && m[7] === '-') return m.slice(0, 10);
  const p = m.split('/');
  if (p.length === 3) { let [a, b, y] = p.map(x => parseInt(x, 10)); if (y < 100) y += 2000; if (!(a >= 1 && a <= 12 && b >= 1 && b <= 31)) { const t = a; a = b; b = t; } if (a >= 1 && a <= 12 && b >= 1 && b <= 31 && y > 1990) return y + '-' + String(a).padStart(2, '0') + '-' + String(b).padStart(2, '0'); }
  return null;
}
const num = (v) => { const x = parseFloat(String(v).split(',').join('')); return isNaN(x) ? null : x; };

const COLS = {
  kcal: ['calories', 'energy (kcal)', 'energy', 'kcal', 'calories (kcal)'],
  protein: ['protein (g)', 'protein', 'protein_g'],
  carbs: ['carbohydrates (g)', 'carbs (g)', 'carbohydrate (g)', 'carbs_g', 'carbohydrates', 'carbs', 'net carbs (g)'],
  fat: ['fat (g)', 'total fat (g)', 'fat_g', 'fat', 'total fat'],
  fiber: ['fiber (g)', 'fiber', 'fibre (g)'],
  sugar: ['sugar (g)', 'sugars (g)', 'sugar', 'sugar_g'],
  sodium: ['sodium (mg)', 'sodium_mg', 'sodium'],
};
function findCol(header, names) { for (const n of names) { const i = header.indexOf(n); if (i >= 0) return i; } return -1; }

// unit: 'lb' | 'kg' — how to read plain "Weight" columns
function parseExport(text, unit) {
  const rows = parseCsv(text); if (rows.length < 2) throw new Error('That file looks empty.');
  const header = rows[0].map(h => String(h).trim().toLowerCase());
  let di = header.indexOf('date'); if (di < 0) di = header.indexOf('day'); if (di < 0) throw new Error('No Date column found. Use the CSV export from your nutrition app.');
  const out = { days: {}, weights: {}, foods: {}, kind: null, rows: 0 };
  const fi = ['food', 'food name', 'name'].map(h => header.indexOf(h)).find(i => i >= 0) ;
  const ci = {}; for (const k of Object.keys(COLS)) ci[k] = findCol(header, COLS[k]);
  const mi = ['meal', 'group'].map(h => header.indexOf(h)).find(i => i >= 0);
  const wi = header.findIndex(h => h === 'weight' || h.indexOf('weight (') === 0 || h === 'body weight');
  if (ci.kcal >= 0) {
    out.kind = fi !== undefined && fi >= 0 ? (header.indexOf('food name') >= 0 ? 'Cronometer (foods)' : 'Food log (foods)') : (mi !== undefined && mi >= 0 ? 'MyFitnessPal / Lose It! (per meal)' : (header.indexOf('energy (kcal)') >= 0 ? 'Cronometer (daily)' : 'Nutrition CSV'));
    for (let r = 1; r < rows.length; r++) {
      const row = rows[r]; const d = isoDate(row[di]); if (!d) continue;
      if (mi !== undefined && mi >= 0 && /^total/i.test(String(row[mi] || '').trim())) continue;
      const kc = num(row[ci.kcal]); if (kc == null) continue;
      const o = out.days[d] || (out.days[d] = { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 0, n: 0 });
      o.kcal += kc; o.n++;
      for (const k of ['protein', 'carbs', 'fat', 'fiber', 'sugar', 'sodium']) if (ci[k] >= 0) o[k] += num(row[ci[k]]) || 0;
      if (fi !== undefined && fi >= 0 && String(row[fi] || '').trim()) { const it = { meal: mi !== undefined && mi >= 0 ? String(row[mi] || '').trim() : '', name: String(row[fi]).trim(), kcal: kc }; for (const k of ['protein', 'carbs', 'fat', 'fiber', 'sugar', 'sodium']) it[k] = ci[k] >= 0 ? (num(row[ci[k]]) || 0) : 0; (out.foods[d] = out.foods[d] || []).push(it); }
      out.rows++;
    }
    for (const d of Object.keys(out.days)) { const o = out.days[d]; for (const k of Object.keys(o)) if (k !== 'n') o[k] = Math.round(o[k] * 10) / 10; }
  } else if (wi >= 0) {
    out.kind = 'Weight log';
    const lb = unit !== 'kg';
    for (let r = 1; r < rows.length; r++) { const d = isoDate(rows[r][di]); const w = num(rows[r][wi]); if (d && w && w > 20) { out.weights[d] = Math.round((lb ? w * 0.45359237 : w) * 10) / 10; out.rows++; } }
  } else throw new Error('Could not find calories or weight columns in that file.');
  if (!out.rows) throw new Error('No usable rows found in that file.');
  return out;
}

function mean(a) { return a.length ? a.reduce((x, y) => x + y, 0) / a.length : null; }
function dayKey(offset, today) { const d = new Date(today + 'T12:00:00Z'); d.setUTCDate(d.getUTCDate() - offset); return d.toISOString().slice(0, 10); }

// Summary used by the dashboard. Days with under 800 kcal are treated as incomplete logging and left out of averages.
function summarize(nut, today, weightKg) {
  const days = nut.days || {}; const keys = Object.keys(days).sort(); if (!keys.length) return null;
  const last = keys[keys.length - 1]; const ref = today && today < last ? today : (last > today ? today : last);
  const win = (n) => { const out = []; for (let i = 0; i < n; i++) { const d = days[dayKey(i, ref)]; if (d && d.kcal >= 800) out.push(d); } return out; };
  const avg = (arr, k) => { const m = mean(arr.map(x => x[k])); return m == null ? null : Math.round(m); };
  const w7 = win(7), w28 = win(28); const base = w28.length >= 3 ? w28 : win(90);
  const stale = Math.round((new Date(today + 'T12:00:00Z') - new Date(last + 'T12:00:00Z')) / 86400000);
  const series = []; for (let i = 27; i >= 0; i--) { const d = dayKey(i, ref); series.push({ d, kcal: days[d] ? days[d].kcal : null }); }
  const protein = avg(base, 'protein');
  return { first: keys[0], last, daysLogged: keys.length, staleDays: stale, avg7: { n: w7.length, kcal: avg(w7, 'kcal'), protein: avg(w7, 'protein'), carbs: avg(w7, 'carbs'), fat: avg(w7, 'fat') }, avg28: { n: base.length, kcal: avg(base, 'kcal'), protein, carbs: avg(base, 'carbs'), fat: avg(base, 'fat') }, proteinPerKg: protein && weightKg ? Math.round(protein / weightKg * 100) / 100 : null, series };
}

function nearestWeight(weights, iso, windowDays) {
  let best = null, bd = 1e9; const t = new Date(iso.slice(0, 10) + 'T12:00:00Z').getTime();
  for (const d of Object.keys(weights || {})) { const dd = Math.abs((new Date(d + 'T12:00:00Z').getTime() - t) / 86400000); if (dd < bd) { bd = dd; best = weights[d]; } }
  return bd <= (windowDays || 4) ? best : null;
}

module.exports = { parseCsv, parseExport, summarize, nearestWeight, isoDate };
