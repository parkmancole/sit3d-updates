'use strict';
// Platform angle (deg, CCW from above) as a function of time since tt_scanStart, derived from the measured profile (phone-video calibration).
const cal = require('./calibration.json');
function makeAngleModel(scanDurationS) {
  const A = cal.angle;
  // index pulse occurs (pulse_to_complete_s) before tt_scanComplete, at index_pulse_angle_deg: use it to fit this scan's cruise speed
  const tPulse = scanDurationS - A.pulse_to_complete_s;
  const omega = A.index_pulse_angle_deg / (tPulse - A.start_lag_s);
  const aComplete = omega * (scanDurationS - A.start_lag_s);
  const dec = A.decel;
  function decelDelta(dt) {                // extra angle (deg) after scanComplete, scaled by omega relative to the calibration run
    const k = omega / A.omega_deg_s;
    if (dt <= 0) return 0;
    if (dt >= dec[dec.length - 1][0]) return dec[dec.length - 1][1] * k;
    for (let i = 1; i < dec.length; i++) if (dt <= dec[i][0]) { const f = (dt - dec[i - 1][0]) / (dec[i][0] - dec[i - 1][0]); return (dec[i - 1][1] + f * (dec[i][1] - dec[i - 1][1])) * k; }
    return 0;
  }
  const theta = (t) => {
    if (t <= 0) return 0;
    if (t < A.start_lag_s) return Math.max(0, omega * (t - 0.12) * 0.5);
    if (t <= scanDurationS) return omega * (t - A.start_lag_s);
    return aComplete + decelDelta(t - scanDurationS);
  };
  return { theta, omega, aComplete };
}
module.exports = { makeAngleModel };
