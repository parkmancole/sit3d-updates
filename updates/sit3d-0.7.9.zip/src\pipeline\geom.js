'use strict';
// Geometry helpers on voxel point clouds (Float32Array xyz, mm).
const cal = require('./calibration.json');
function isolateBody(pts, vs = 8) {
  // 1) drop platform (z < 10) and the two handle poles, keep radius < 560
  const n = pts.length / 3, keep = [];
  const P = cal.poles.centers_xy, pr = cal.poles.exclude_radius_mm;
  for (let i = 0; i < n; i++) {
    const x = pts[3 * i], y = pts[3 * i + 1], z = pts[3 * i + 2];
    if (z < 10 || z > 2000) continue;
    if (x * x + y * y > 560 * 560) continue;
    let pole = false;
    for (const c of P) if (z < cal.poles.top_mm && (x - c[0]) ** 2 + (y - c[1]) ** 2 < pr * pr) pole = true;
    if (pole) continue;
    keep.push(i);
  }
  // 2) largest 26-connected component on the voxel grid
  const idx = new Map(); const key = (a, b, c) => ((a + 512) << 20) | ((b + 512) << 10) | (c + 64);
  const ix = new Int32Array(keep.length), iy = new Int32Array(keep.length), iz = new Int32Array(keep.length);
  keep.forEach((k, j) => { ix[j] = Math.floor(pts[3 * k] / vs); iy[j] = Math.floor(pts[3 * k + 1] / vs); iz[j] = Math.floor(pts[3 * k + 2] / vs); idx.set(key(ix[j], iy[j], iz[j]), j); });
  const comp = new Int32Array(keep.length).fill(-1); let best = -1, bestN = 0, nc = 0;
  const stack = [];
  for (let s = 0; s < keep.length; s++) {
    if (comp[s] !== -1) continue;
    let cnt = 0; stack.push(s); comp[s] = nc;
    while (stack.length) {
      const j = stack.pop(); cnt++;
      for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) for (let dz = -1; dz <= 1; dz++) {
        if (!dx && !dy && !dz) continue;
        const q = idx.get(key(ix[j] + dx, iy[j] + dy, iz[j] + dz));
        if (q !== undefined && comp[q] === -1) { comp[q] = nc; stack.push(q); }
      }
    }
    if (cnt > bestN) { bestN = cnt; best = nc; }
    nc++;
  }
  const out = []; keep.forEach((k, j) => { if (comp[j] === best) out.push(pts[3 * k], pts[3 * k + 1], pts[3 * k + 2]); });
  return Float32Array.from(out);
}
// 2D connected clusters of points on a grid (cell size g), returns arrays of point-index lists
function clusters2D(xs, ys, g = 8) {
  const m = new Map(); const key = (a, b) => (a + 4096) * 8192 + (b + 4096);
  const cx = xs.map(v => Math.floor(v / g)), cy = ys.map(v => Math.floor(v / g));
  const cells = new Map();
  for (let i = 0; i < xs.length; i++) { const k = key(cx[i], cy[i]); if (!cells.has(k)) cells.set(k, []); cells.get(k).push(i); }
  const seen = new Set(), out = [];
  for (const [k0, l0] of cells) {
    if (seen.has(k0)) continue;
    const grp = []; const st = [k0]; seen.add(k0);
    while (st.length) {
      const k = st.pop(); const a = Math.floor(k / 8192) - 4096, b = (k % 8192) - 4096; for (const i of cells.get(k)) grp.push(i);
      for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) { const kk = key(a + dx, b + dy); if (cells.has(kk) && !seen.has(kk)) { seen.add(kk); st.push(kk); } }
    }
    out.push(grp);
  }
  return out.sort((p, q) => q.length - p.length);
}
// perimeter of the outline of a 2D point set: star-shaped polygon around the centroid (percentile radius per angular bin), bins=90
function perimeter2D(us, vs_, bins = 90, pct = 0.85) {
  const n = us.length; if (n < 6) return { perim: 0, area: 0, cu: 0, cv: 0, poly: [] };
  let cu = 0, cv = 0; for (let i = 0; i < n; i++) { cu += us[i]; cv += vs_[i]; } cu /= n; cv /= n;
  const rb = Array.from({ length: bins }, () => []);
  for (let i = 0; i < n; i++) { const a = Math.atan2(vs_[i] - cv, us[i] - cu); const b = Math.min(bins - 1, Math.floor((a + Math.PI) / (2 * Math.PI) * bins)); rb[b].push(Math.hypot(us[i] - cu, vs_[i] - cv)); }
  let R = rb.map(l => { if (!l.length) return NaN; l.sort((a, b) => a - b); return l[Math.min(l.length - 1, Math.floor(pct * l.length))]; });
  // fill empty bins by interpolation, then 3-bin median smoothing
  for (let i = 0; i < bins; i++) if (!isFinite(R[i])) { let a = 1; while (!isFinite(R[(i - a + bins) % bins]) && a < bins) a++; let b = 1; while (!isFinite(R[(i + b) % bins]) && b < bins) b++; R[i] = (R[(i - a + bins) % bins] + R[(i + b) % bins]) / 2; }
  R = R.map((v, i) => { const t = [R[(i - 1 + bins) % bins], v, R[(i + 1) % bins]].sort((p, q) => p - q); return t[1]; });
  const poly = R.map((r, i) => { const a = -Math.PI + (i + 0.5) / bins * 2 * Math.PI; return [cu + r * Math.cos(a), cv + r * Math.sin(a)]; });
  let perim = 0, area = 0; for (let i = 0; i < bins; i++) { const p = poly[i], q = poly[(i + 1) % bins]; perim += Math.hypot(q[0] - p[0], q[1] - p[1]); area += p[0] * q[1] - q[0] * p[1]; }
  return { perim, area: Math.abs(area) / 2, cu, cv, poly };
}
module.exports = { isolateBody, clusters2D, perimeter2D };
