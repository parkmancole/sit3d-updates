'use strict';
// Body measurements from the unwound body point cloud (mm). Person faces -Y (toward the cameras); person's LEFT is +X.
// All values are ESTIMATES from the visible surface (clothing included).
const { isolateBody, clusters2D, perimeter2D } = require('./geom.js');

function slab(body, z, half = 6) {
  const xs = [], ys = [];
  for (let i = 0; i < body.length; i += 3) if (Math.abs(body[i + 2] - z) <= half) { xs.push(body[i]); ys.push(body[i + 1]); }
  return { xs, ys };
}
function summarise(cl, xs, ys) {   // one cluster -> stats
  const U = cl.map(i => xs[i]), V = cl.map(i => ys[i]); const p = perimeter2D(U, V);
  return { n: cl.length, perim: p.perim, cx: p.cu, cy: p.cv, w: Math.max(...U) - Math.min(...U), d: Math.max(...V) - Math.min(...V), minx: Math.min(...U), maxx: Math.max(...U) };
}
// profile at one height: list of clusters (big first)
function level(body, z) {
  const { xs, ys } = slab(body, z); if (xs.length < 12) return [];
  return clusters2D(xs, ys, 8).filter(c => c.length >= 10).map(c => summarise(c, xs, ys));
}
function central(cs) {          // the cluster covering x ~ 0 with the biggest width
  let best = null; for (const c of cs) if (c.minx < 40 && c.maxx > -40 && (!best || c.w > best.w)) best = c; return best;
}

function measureBody(points) {
  const body = isolateBody(points);
  let H = 0; for (let i = 2; i < body.length; i += 3) if (body[i] > H) H = body[i];
  // ---- vertical profile at 8 mm steps ----
  const prof = []; for (let z = 24; z <= H - 6; z += 8) prof.push({ z, cs: level(body, z) });
  const at = (z) => prof.reduce((b, p) => (Math.abs(p.z - z) < Math.abs(b.z - z) ? p : b), prof[0]);
  // crotch: lowest z where the two legs have merged into one central cluster with width > 280
  let crotch = null;
  for (const p of prof) { if (p.z < 0.25 * H) continue; const c = central(p.cs); if (c && c.w > 280 && c.n > 200) { crotch = p.z; break; } }
  if (!crotch) crotch = 0.47 * H;
  const tor = prof.filter(p => p.z >= crotch).map(p => ({ z: p.z, c: central(p.cs) })).filter(t => t.c);
  const pick = (lo, hi, better) => { let best = null; for (const t of tor) if (t.z >= lo && t.z <= hi && (!best || better(t.c, best.c))) best = t; return best; };
  const hip = pick(crotch, crotch + 0.16 * H, (a, b) => a.perim > b.perim);
  const wLo = hip ? Math.max(0.55 * H, hip.z + 0.05 * H) : 0.55 * H, wHi = 0.66 * H;
  const waist = pick(wLo, wHi, (a, b) => a.perim < b.perim) || pick(0.5 * H, 0.7 * H, (a, b) => a.perim < b.perim);
  // armpit = first z above the waist where the central width jumps (arms merge into the torso)
  let armpitZ = null; { let prevW = null; for (const t of tor) { if (t.z < (waist ? waist.z : 0.6 * H)) { prevW = t.c.w; continue; } if (prevW && t.c.w > 1.3 * prevW && t.c.w > 450) { armpitZ = t.z; break; } prevW = t.c.w; } }
  if (!armpitZ) armpitZ = 0.72 * H;
  const chest = pick(armpitZ - 70, armpitZ - 20, (a, b) => a.perim > b.perim);
  // neck: minimum perimeter of the central cluster in [0.82H, 0.93H] while narrow (< 260 mm wide)
  let neck = null; for (const t of tor) { if (t.z < 0.82 * H || t.z > 0.93 * H) continue; if (t.c.w > 260) continue; if (!neck || t.c.perim < neck.c.perim) neck = t; }
  // legs below the crotch: left (+x) / right (-x)
  const legAt = (z) => { const cs = at(z).cs.filter(c => c.n > 40); const L = cs.filter(c => c.cx > 0).sort((a, b) => b.n - a.n)[0], R = cs.filter(c => c.cx < 0).sort((a, b) => b.n - a.n)[0]; return { L, R }; };
  const thighZ = crotch - 40; const th = legAt(thighZ);
  let calfL = null, calfR = null, calfZL = 0, calfZR = 0;
  for (const p of prof) { if (p.z < 0.13 * H || p.z > 0.26 * H) continue; const { L, R } = legAt(p.z); if (L && (!calfL || L.perim > calfL.perim)) { calfL = L; calfZL = p.z; } if (R && (!calfR || R.perim > calfR.perim)) { calfR = R; calfZR = p.z; } }
  // arms are oblique: perimeter of the horizontal section times cos(tilt)
  const armSection = (sign) => {
    const rows = []; for (const p of prof) { if (p.z < 0.50 * H || p.z > armpitZ - 15) continue; const a = p.cs.filter(c => sign * c.cx > 220 && c.n > 30).sort((x, y) => y.n - x.n)[0]; if (a) rows.push({ z: p.z, a }); }
    if (rows.length < 6) return null;
    const half = Math.floor(rows.length / 2); const up = rows.slice(half), lo = rows.slice(0, half);
    const slope = (arr) => { if (arr.length < 3) return 0; const dz = arr[arr.length - 1].z - arr[0].z, dx = arr[arr.length - 1].a.cx - arr[0].a.cx; return dz ? Math.abs(dx / dz) : 0; };
    const corr = (arr) => Math.cos(Math.atan(slope(arr)));
    const best = (arr) => arr.reduce((b, r) => (r.a.perim > b.a.perim ? r : b), arr[0]);
    const bi = best(up), fo = best(lo);
    return { bicep: bi.a.perim * corr(up), forearm: fo.a.perim * corr(lo) };
  };
  const armL = armSection(+1), armR = armSection(-1);
  // ---- posture (mm / deg); forward = -Y, left = +X ----
  const feet = prof.filter(p => p.z < 120).flatMap(p => p.cs.filter(c => c.n > 100 && Math.abs(c.cx) < 300));
  const feetCx = feet.length ? feet.reduce((s, c) => s + c.cx, 0) / feet.length : 0, feetCy = feet.length ? feet.reduce((s, c) => s + c.cy, 0) / feet.length : 0;
  const hs = [0, 0, 0]; let hn = 0; for (let i = 0; i < body.length; i += 3) if (body[i + 2] > H - 0.11 * H) { hs[0] += body[i]; hs[1] += body[i + 1]; hs[2] += body[i + 2]; hn++; }
  const hc = hs.map(v => v / Math.max(1, hn));
  const shBand = tor.filter(t => Math.abs(t.z - 0.82 * H) < 25).map(t => t.c);
  const sh = shBand.length ? shBand.reduce((s, c) => [s[0] + c.cx, s[1] + c.cy], [0, 0]).map(v => v / shBand.length) : [0, 0];
  const topAt = (sgn) => { let zmax = -1; for (let i = 0; i < body.length; i += 3) { const x = body[i], z = body[i + 2]; if (sgn * x > 70 && sgn * x < 200 && z > 0.74 * H && z < 0.9 * H && Math.abs(body[i + 1] - sh[1]) < 120) zmax = Math.max(zmax, z); } return zmax; };
  const zL = topAt(+1), zR = topAt(-1);
  const posture = {
    head_forward_mm: -(hc[1] - feetCy), head_lateral_mm: hc[0] - feetCx,
    shoulder_shift_mm: sh[0] - feetCx, shoulder_forward_mm: -(sh[1] - feetCy),
    hip_shift_mm: hip ? hip.c.cx - feetCx : null, hip_forward_mm: hip ? -(hip.c.cy - feetCy) : null,
    shoulder_tilt_deg: (zL > 0 && zR > 0) ? Math.atan2(zL - zR, 260) * 180 / Math.PI : null,
  };
  const r = (v) => (v == null || !isFinite(v) ? null : Math.round(v * 10) / 10);
  const result = {
    height_mm: r(H), crotch_height_mm: r(crotch),
    landmarks_mm: { hip: r(hip && hip.z), waist: r(waist && waist.z), chest: r(chest && chest.z), neck: r(neck && neck.z), armpit: r(armpitZ), thigh: r(thighZ), calfL: r(calfZL), calfR: r(calfZR) },
    circumference_mm: {
      neck: r(neck && neck.c.perim), chest: r(chest && chest.c.perim), waist: r(waist && waist.c.perim), hips: r(hip && hip.c.perim),   // neck is low-confidence: jaw/head position can bias it
      thigh_left: r(th.L && th.L.perim), thigh_right: r(th.R && th.R.perim), calf_left: r(calfL && calfL.perim), calf_right: r(calfR && calfR.perim),
      bicep_left: null, bicep_right: null, forearm_left: null, forearm_right: null,   // oblique arm sections not reliable yet (see docs)
    },
    widths_mm: { hip_width: r(hip && hip.c.w), hip_depth: r(hip && hip.c.d), waist_width: r(waist && waist.c.w), waist_depth: r(waist && waist.c.d) },
    posture: Object.fromEntries(Object.entries(posture).map(([k, v]) => [k, r(v)])),
    body_points: body.length / 3,
  };
  return { result, body };
}
module.exports = { measureBody };
