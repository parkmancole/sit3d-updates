'use strict';
// Minimal decoder for 8/16-bit grayscale, non-interlaced PNG (what Capture-Depth writes). No dependencies.
const zlib = require('zlib');
const fs = require('fs');
function decodeGray16(buf) {
  if (buf.readUInt32BE(0) !== 0x89504e47) throw new Error('not a PNG');
  let pos = 8, width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
  const idat = [];
  while (pos < buf.length) {
    const len = buf.readUInt32BE(pos), type = buf.toString('ascii', pos + 4, pos + 8);
    if (type === 'IHDR') { width = buf.readUInt32BE(pos + 8); height = buf.readUInt32BE(pos + 12); bitDepth = buf[pos + 16]; colorType = buf[pos + 17]; interlace = buf[pos + 20]; }
    else if (type === 'IDAT') idat.push(buf.slice(pos + 8, pos + 8 + len));
    else if (type === 'IEND') break;
    pos += 12 + len;
  }
  if (colorType !== 0 || (bitDepth !== 16 && bitDepth !== 8) || interlace) throw new Error('unsupported PNG (need gray, non-interlaced)');
  const bpp = bitDepth / 8, stride = width * bpp;
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const out = new Uint16Array(width * height);
  let prev = Buffer.alloc(stride), cur = Buffer.alloc(stride);
  for (let y = 0; y < height; y++) {
    const ft = raw[y * (stride + 1)], line = raw.slice(y * (stride + 1) + 1, (y + 1) * (stride + 1));
    for (let i = 0; i < stride; i++) {
      const a = i >= bpp ? cur[i - bpp] : 0, b = prev[i], c = i >= bpp ? prev[i - bpp] : 0;
      let v = line[i];
      if (ft === 1) v += a; else if (ft === 2) v += b; else if (ft === 3) v += (a + b) >> 1;
      else if (ft === 4) { const p = a + b - c, pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c); v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c); }
      cur[i] = v & 255;
    }
    for (let x = 0; x < width; x++) out[y * width + x] = bitDepth === 16 ? (cur[2 * x] << 8) | cur[2 * x + 1] : cur[x];
    const t = prev; prev = cur; cur = t;
  }
  return { width, height, data: out };
}
function readGray16(file) { return decodeGray16(fs.readFileSync(file)); }
module.exports = { decodeGray16, readGray16 };
