'use strict';
// Depth frames -> body point cloud. Mirrors the validated Python pipeline (re/analysis): rotate 180, back-project, level/pose the 3 cameras,
// unwind by the platform angle, then keep only voxels seen in >= minSupport distinct frames (a rigid rotating body is; the static room is not).
const fs = require('fs'), path = require('path');
const cal = require('./calibration.json');
const { readGray16 } = require('./png16.js');
const { makeAngleModel } = require('./angle.js');

const rad = (d) => d * Math.PI / 180;
const mul = (A, B) => A.map((r, i) => [0, 1, 2].map(j => r[0] * B[0][j] + r[1] * B[1][j] + r[2] * B[2][j]));
const Rx = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[1, 0, 0], [0, c, -s], [0, s, c]]; };
const Ry = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[c, 0, s], [0, 1, 0], [-s, 0, c]]; };
const Rz = (a) => { const c = Math.cos(a), s = Math.sin(a); return [[c, -s, 0], [s, c, 0], [0, 0, 1]]; };
const Bm = [[1, 0, 0], [0, 0, 1], [0, -1, 0]];          // camera (x right, y down, z fwd) -> world (X right, Y fwd, Z up) for a level camera

// sensor index (0=low, 1=top, 2=middle) -> {M: 3x3, t: [3]} such that world = M*P_cam + t   (P_cam in mm, intrinsics-scaled)
function sensorTransforms() {
  const L = cal.sensor0_level, up = L.normal.slice();
  const un = Math.hypot(...up); up[0] /= un; up[1] /= un; up[2] /= un;
  let e1 = [1 - up[0] * up[0], -up[0] * up[1], -up[0] * up[2]]; const n1 = Math.hypot(...e1); e1 = e1.map(v => v / n1);
  const e2 = [up[1] * e1[2] - up[2] * e1[1], up[2] * e1[0] - up[0] * e1[2], up[0] * e1[1] - up[1] * e1[0]];
  const M0 = [e1, e2, up], c0 = L.c0;
  const t0 = [-(M0[0][0] * c0[0] + M0[0][1] * c0[1] + M0[0][2] * c0[2]) - L.axis_ab[0], -(M0[1][0] * c0[0] + M0[1][1] * c0[1] + M0[1][2] * c0[2]) - L.axis_ab[1], -(M0[2][0] * c0[0] + M0[2][1] * c0[1] + M0[2][2] * c0[2])];
  const T = [{ M: M0, t: t0 }];
  for (const key of ['sensor1_pose', 'sensor2_pose']) {
    const p = cal[key];
    const R = mul(mul(mul(Rz(rad(p.yaw_deg)), Rx(rad(p.pitch_deg))), Ry(rad(p.roll_deg))), Bm);
    T.push({ M: R, t: [p.tx, p.ty, p.height] });
  }
  return T;                                            // order: low, top, middle  (== sensor_0, sensor_1, sensor_2 folders)
}

class VoxelTable {
  constructor(bits = 23) {
    this.size = 1 << bits; this.mask = this.size - 1;
    this.keys = new Int32Array(this.size).fill(-1); this.cnt = new Uint16Array(this.size); this.last = new Int16Array(this.size).fill(-1);
    this.sx = new Float32Array(this.size); this.sy = new Float32Array(this.size); this.sz = new Float32Array(this.size); this.used = 0;
  }
  add(key, frame, x, y, z) {
    let h = (Math.imul(key, 2654435761) >>> 9) & this.mask;
    for (;;) {
      const k = this.keys[h];
      if (k === key) break;
      if (k === -1) { this.keys[h] = key; this.used++; break; }
      h = (h + 1) & this.mask;
    }
    if (this.last[h] !== frame) { this.last[h] = frame; this.cnt[h]++; }
    this.sx[h] += x; this.sy[h] += y; this.sz[h] += z;      // running sums (centroid later), counted per point
    this.np = (this.np || 0) + 0;
    return h;
  }
}

/**
 * opts: {step:2, voxel:8, minSupport:10, maxRadius:800, fxScale:1, framesDir, timing:{scanDurationS, startOffsetS}, frameTimesS:[...]}
 */
function reconstruct(scanDir, opts, progress) {
  const step = opts.step || 2, vs = opts.voxel || 8, minSup = opts.minSupport || 10, maxR = opts.maxRadius || 800, fxs = opts.fxScale || 1;
  const fx = cal.intrinsics.fx * fxs, fy = cal.intrinsics.fy * fxs, cx = cal.intrinsics.cx, cy = cal.intrinsics.cy;
  const T = sensorTransforms();
  const W = 640, H = 480, maxDepth = cal.image.max_depth_mm;
  // pixel rays for the 180-degree-rotated image
  const rays = []; for (let r = 0; r < H; r += step) for (let c = 0; c < W; c += step) rays.push([r, c]);
  const tbl = new VoxelTable(23);
  const am = makeAngleModel(opts.scanDurationS);
  const frames = opts.frameTimesS.length;
  const cnt2 = new Float32Array(frames);                       // per-frame point counts (diagnostic)
  for (let i = 0; i < frames; i++) {
    const th = rad(-am.theta(opts.frameTimesS[i])), cs = Math.cos(th), sn = Math.sin(th);
    for (let s = 0; s < 3; s++) {
      const im = readGray16(path.join(scanDir, 'sensor_' + s, String(i).padStart(3, '0') + '.png')).data;
      const M = T[s].M, t = T[s].t;
      for (let k = 0; k < rays.length; k++) {
        const r = rays[k][0], c = rays[k][1];
        const z = im[r * W + c]; if (z === 0 || z > maxDepth) continue;
        const u = (W - 1 - c), v = (H - 1 - r);                // rotate 180
        const px = (u - cx) * z / fx, py = (v - cy) * z / fy;
        const X = M[0][0] * px + M[0][1] * py + M[0][2] * z + t[0];
        const Y = M[1][0] * px + M[1][1] * py + M[1][2] * z + t[1];
        const Z = M[2][0] * px + M[2][1] * py + M[2][2] * z + t[2];
        if (Z < -120 || Z > 2150) continue;
        const xr = cs * X - sn * Y, yr = sn * X + cs * Y;      // unwind by -theta
        if (xr * xr + yr * yr > maxR * maxR) continue;
        const ix = Math.floor(xr / vs) + 256, iy = Math.floor(yr / vs) + 256, iz = Math.floor(Z / vs) + 64;
        if (ix < 0 || ix > 1023 || iy < 0 || iy > 1023 || iz < 0 || iz > 1023) continue;
        tbl.add((ix << 20) | (iy << 10) | iz, i, xr, yr, Z); cnt2[i]++;
      }
    }
    if (progress && (i % 8 === 0 || i === frames - 1)) progress((i + 1) / frames);
  }
  // collect supported voxels; centroid = mean of points that fell in the voxel (sum / number of hits) -> we only kept sums, so use voxel centre blend
  const pts = []; let kept = 0;
  for (let h = 0; h < tbl.size; h++) {
    if (tbl.keys[h] === -1 || tbl.cnt[h] < minSup) continue;
    const key = tbl.keys[h], ix = (key >> 20) & 1023, iy = (key >> 10) & 1023, iz = key & 1023;
    pts.push((ix - 256 + 0.5) * vs, (iy - 256 + 0.5) * vs, (iz - 64 + 0.5) * vs); kept++;
  }
  return { points: Float32Array.from(pts), n: kept, voxelsTotal: tbl.used, voxel: vs, omega: am.omega, thetaEnd: am.aComplete };
}
module.exports = { reconstruct, sensorTransforms };
