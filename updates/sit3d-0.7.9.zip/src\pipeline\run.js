'use strict';
// Worker: raw scan folder (or demo cloud) -> body model + measurements. Run as: sit3d.exe(ELECTRON_RUN_AS_NODE) run.js <spec.json>
// Writes <outDir>/pipeline.json and <outDir>/view.bin (Int16 xyz, mm) and prints "PROGRESS {...}" lines.
const fs = require('fs'), path = require('path');
const { reconstruct } = require('./reconstruct.js');
const { measureBody } = require('./measure.js');

const spec = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const progress = (p, msg) => process.stdout.write('PROGRESS ' + JSON.stringify({ p, msg }) + '\n');
function main() {
  fs.mkdirSync(spec.outDir, { recursive: true });
  let points, info = {};
  if (spec.mode === 'demo') {
    progress(0.1, 'Loading demo scan');
    const b = fs.readFileSync(spec.demoFile); points = new Float32Array(b.buffer, b.byteOffset, b.length / 4);
    info = { omega: 9.77, thetaEnd: 366.7, source: 'demo' };
  } else {
    const rows = fs.readFileSync(path.join(spec.scanDir, 'iterations.csv'), 'utf8').trim().split(/\r?\n/).slice(1).map(l => l.split(','));
    const kept = rows.filter(r => r[2] === '1');
    const frameTimesS = kept.map(r => (spec.startOffsetS || 0.038) + parseFloat(r[1]) / 1000 + 0.017);
    progress(0.02, 'Building the 3D model');
    const res = reconstruct(spec.scanDir, { step: 2, scanDurationS: spec.scanDurationS, frameTimesS, fxScale: spec.fxScale || 1 }, (p) => progress(0.02 + 0.68 * p, 'Building the 3D model'));
    let fov = null; try { const meta = JSON.parse(fs.readFileSync(path.join(spec.scanDir, 'capture_meta.json'), 'utf8')); fov = meta.sensors.map(s => ({ hfov_rad: s.hfov_rad, vfov_rad: s.vfov_rad })); } catch (e) { /* older capture tool */ }
    points = res.points; info = { omega: res.omega, thetaEnd: res.thetaEnd, voxels: res.n, frames: frameTimesS.length, source: 'scanner', fov };
  }
  progress(0.75, 'Measuring your body');
  const { result, body } = measureBody(points);
  progress(0.92, 'Saving');
  // decimate for the viewer (<= ~36k points)
  const n = body.length / 3, stride = Math.max(1, Math.ceil(n / 36000));
  const view = new Int16Array(3 * Math.ceil(n / stride)); let k = 0;
  for (let i = 0; i < n; i += stride) { view[k++] = Math.round(body[3 * i]); view[k++] = Math.round(body[3 * i + 1]); view[k++] = Math.round(body[3 * i + 2]); }
  fs.writeFileSync(path.join(spec.outDir, 'view.bin'), Buffer.from(view.buffer, 0, k * 2));
  fs.writeFileSync(path.join(spec.outDir, 'pipeline.json'), JSON.stringify({ measure: result, info }));
  progress(1, 'Done');
}
try { main(); } catch (e) { process.stdout.write('ERROR ' + JSON.stringify({ message: String(e && e.stack || e) }) + '\n'); process.exit(1); }
