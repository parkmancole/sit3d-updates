(function () {
'use strict';
// Dashboard weight card: every weigh-in in one chart (Fit3D scans and the nutrition apps in different colors) with slicers and filters.
const S3 = window.S3, $ = (s, r) => (r || document).querySelector(s);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const RANGES = [['1m', 30, '1M'], ['3m', 90, '3M'], ['6m', 182, '6M'], ['1y', 365, '1Y'], ['all', 0, 'All']];
const SRC = { scan: { name: 'Fit3D scan', color: '#F58220' }, mfp: { name: 'MyFitnessPal', color: '#3B82F6' }, mnd: { name: 'MyNetDiary', color: '#10B981' }, import: { name: 'Imported file', color: '#8B93A1' } };
S3.SRC = SRC;

// ---- slicer state (remembered on this PC) ----
const load = () => { try { return Object.assign({ range: '3m', off: {}, smooth: true, cal: false }, JSON.parse(localStorage.getItem('sit3d.dash') || '{}')); } catch (e) { return { range: '3m', off: {}, smooth: true, cal: false }; } };
S3.dash = S3.dash || load();
const save = () => { try { localStorage.setItem('sit3d.dash', JSON.stringify(S3.dash)); } catch (e) { /* ignore */ } };
const rangeDays = () => (RANGES.find((r) => r[0] === S3.dash.range) || RANGES[1])[1];
S3.dashRange = () => { const d = rangeDays(); if (!d) return null; const t0 = Date.now() - d * 86400000; return (iso) => new Date(iso).getTime() >= t0; };

// ---- chart with several series on one time axis ----
// series: [{ name, color, kind: 'scan'|'app', pts: [{t, v}] }]; o: { unit, dec, from, to, avg: [{t, v}], cal: [{t, v}] }
S3.multiChart = (series, o) => {
  const W = 860, H = 320, L = 54, R = o.cal && o.cal.length ? 54 : 22, T = 18, B = 38;
  const all = []; series.forEach((s) => s.pts.forEach((p) => all.push(p))); (o.avg || []).forEach((p) => all.push(p));
  if (!all.length) return '<div class="empty"><div class="big">No weights in this range</div>Try a longer range or turn a source back on.</div>';
  let t0 = o.from != null ? o.from : Math.min.apply(null, all.map((p) => new Date(p.t).getTime())), t1 = o.to != null ? o.to : Math.max.apply(null, all.map((p) => new Date(p.t).getTime())); if (t1 - t0 < 86400000) { t0 -= 43200000; t1 += 43200000; }
  const ys = all.map((p) => p.v); let mn = Math.min.apply(null, ys), mx = Math.max.apply(null, ys); if (mx - mn < 1) { mn -= 1; mx += 1; } const pad = (mx - mn) * 0.15; mn -= pad; mx += pad;
  const X = (t) => L + ((new Date(t).getTime() - t0) / (t1 - t0)) * (W - L - R), Y = (v) => T + (1 - (v - mn) / (mx - mn)) * (H - T - B);
  const dec = o.dec == null ? 1 : o.dec; let g = '';
  for (let i = 0; i <= 4; i++) { const v = mn + (mx - mn) * i / 4, y = Y(v); g += `<line x1="${L}" x2="${W - R}" y1="${y}" y2="${y}" stroke="#F3E8DB"/><text x="${L - 10}" y="${y + 4}" text-anchor="end">${v.toFixed(dec)}</text>`; }
  // date ticks: five evenly spaced labels, so they can never collide
  const spanD = (t1 - t0) / 86400000; const fmt = (ms) => new Date(ms).toLocaleDateString(undefined, spanD > 330 ? { month: 'short', year: '2-digit' } : { month: 'short', day: 'numeric' });
  for (let i = 0; i <= 4; i++) { const ms = t0 + (t1 - t0) * i / 4, x = L + (W - L - R) * i / 4; g += `<text x="${x}" y="${H - 12}" text-anchor="${i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}">${fmt(ms)}</text>`; }
  let calSvg = '';
  if (o.cal && o.cal.length) {
    const cv = o.cal.map((p) => p.v), cmx = Math.max.apply(null, cv) * 1.15, cmn = Math.min(0, Math.min.apply(null, cv)); const Yc = (v) => T + (1 - (v - cmn) / (cmx - cmn)) * (H - T - B);
    calSvg = `<path d="${o.cal.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Yc(p.v).toFixed(1)).join(' ')}" fill="none" stroke="#C9B8A6" stroke-width="2" stroke-dasharray="2 4"/>`;
    for (let i = 0; i <= 4; i++) { const v = cmn + (cmx - cmn) * i / 4; calSvg += `<text x="${W - R + 8}" y="${Yc(v) + 4}" text-anchor="start" fill="#B8A58F">${Math.round(v / 10) * 10}</text>`; }
    calSvg += `<text x="${W - 2}" y="12" text-anchor="end" fill="#B8A58F">kcal</text>`;
  }
  const avg = o.avg && o.avg.length > 1 ? `<path d="${o.avg.map((p, i) => (i ? 'L' : 'M') + X(p.t).toFixed(1) + ',' + Y(p.v).toFixed(1)).join(' ')}" fill="none" stroke="#1D2026" stroke-opacity=".55" stroke-width="3" stroke-linejoin="round" stroke-linecap="round" stroke-dasharray="7 5"/>` : '';
  let dots = '';
  series.filter((s) => s.kind === 'app').forEach((s) => { dots += s.pts.map((p) => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="3.8" fill="${s.color}" fill-opacity=".85"><title>${esc(s.name)}, ${new Date(p.t).toLocaleDateString()}: ${p.v.toFixed(dec)} ${esc(o.unit || '')}</title></circle>`).join(''); });
  series.filter((s) => s.kind === 'scan').forEach((s) => { dots += s.pts.map((p) => `<circle cx="${X(p.t).toFixed(1)}" cy="${Y(p.v).toFixed(1)}" r="7" fill="#fff" stroke="${s.color}" stroke-width="3.5"><title>${esc(s.name)}, ${new Date(p.t).toLocaleString()}: ${p.v.toFixed(dec)} ${esc(o.unit || '')}</title></circle>`).join(''); });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none">${g}${calSvg}${avg}${dots}</svg>`;
};

const trailingAvg = (pts, days) => pts.map((p, i) => { const t = new Date(p.t).getTime(); const w = pts.filter((q) => { const x = new Date(q.t).getTime(); return x <= t && x > t - days * 86400000; }); return { t: p.t, v: w.reduce((a, q) => a + q.v, 0) / w.length }; });

S3.weightCard = async () => {
  const host = $('#wtcard'); if (!host) return;
  let pg = null; try { pg = await S3.api('nutrition:progress', 400); } catch (e) { pg = null; }
  if (!$('#wtcard')) return;   // the user left the page
  const unit = S3.unitsWt(); const kv = (v) => S3.kgVal(v);
  const raw = { scan: ((pg && pg.scanWeights) || []).map((p) => ({ t: p.t, v: kv(p.v) })) }; ((pg && pg.weights) || []).forEach((p) => { const k = SRC[p.src] ? p.src : 'import'; (raw[k] = raw[k] || []).push({ t: p.t, v: kv(p.v) }); });
  const kcal = ((pg && pg.kcal7) || []).map((p) => ({ t: p.t, v: p.v }));
  const draw = () => {
    const st = S3.dash, inR = S3.dashRange(); const now = Date.now(), d = rangeDays();
    const keys = Object.keys(raw).filter((k) => raw[k].length); const counts = {}; keys.forEach((k) => { counts[k] = raw[k].filter((p) => !inR || inR(p.t)).length; });
    const series = keys.filter((k) => !st.off[k]).map((k) => ({ name: SRC[k].name, color: SRC[k].color, kind: k === 'scan' ? 'scan' : 'app', pts: raw[k].filter((p) => !inR || inR(p.t)).sort((a, b) => (a.t < b.t ? -1 : 1)) }));
    const apps = [].concat.apply([], series.filter((s) => s.kind === 'app').map((s) => s.pts)).sort((a, b) => (a.t < b.t ? -1 : 1));
    const chips = keys.map((k) => `<button type="button" class="chip ${st.off[k] ? '' : 'on'}" data-src="${k}"><i style="background:${SRC[k].color}"></i>${SRC[k].name} <span class="muted">${counts[k]}</span></button>`).join('') +
      `<button type="button" class="chip ${st.smooth ? 'on' : ''}" data-opt="smooth"><i style="background:#1D2026;opacity:.55"></i>7-day average</button><button type="button" class="chip ${st.cal ? 'on' : ''}" data-opt="cal"><i style="background:#C9B8A6"></i>Calories</button>`;
    const every = [].concat.apply([], series.map((s) => s.pts)).sort((a, b) => (a.t < b.t ? -1 : 1));
    const first = every[0], last = every[every.length - 1]; const chg = first && last && every.length > 1 ? last.v - first.v : null;
    const stats = last ? `<div class="wtstats"><div><div class="lbl small muted">Latest</div><b>${last.v.toFixed(1)}</b> ${unit}<div class="small muted">${new Date(last.t).toLocaleDateString()}</div></div><div><div class="lbl small muted">Change in range</div><b style="color:${chg == null ? 'inherit' : chg > 0 ? '#E5484D' : '#10B981'}">${chg == null ? '—' : (chg > 0 ? '+' : '') + chg.toFixed(1)}</b> ${chg == null ? '' : unit}</div><div><div class="lbl small muted">Lowest / highest</div><b>${Math.min.apply(null, every.map((p) => p.v)).toFixed(1)}</b> / <b>${Math.max.apply(null, every.map((p) => p.v)).toFixed(1)}</b> ${unit}</div><div><div class="lbl small muted">Weigh-ins</div><b>${every.length}</b></div></div>` : '';
    const chart = S3.multiChart(series, { unit, dec: 1, from: d ? now - d * 86400000 : null, to: now, avg: st.smooth && apps.length > 2 ? trailingAvg(apps, 7) : null, cal: st.cal ? kcal.filter((p) => !inR || inR(p.t)) : null });
    host.innerHTML = `<div class="card chart-card" style="margin-bottom:16px"><div class="row" style="margin-bottom:8px;flex-wrap:wrap;gap:10px"><h3 class="grow" style="margin:0">Weight</h3><div class="seg" id="rangeseg">${RANGES.map((r) => `<button type="button" data-r="${r[0]}" class="${st.range === r[0] ? 'on' : ''}">${r[2]}</button>`).join('')}</div></div><div class="chips">${chips}</div>${stats}${chart}<p class="small muted" style="margin:6px 0 0">Orange rings are Fit3D scans. Dots are weights logged in your nutrition apps.</p></div>`;
    host.querySelectorAll('[data-r]').forEach((b) => { b.onclick = () => { st.range = b.dataset.r; save(); draw(); if (S3.dashRedraw) S3.dashRedraw(); }; });
    host.querySelectorAll('[data-src]').forEach((b) => { b.onclick = () => { st.off[b.dataset.src] = !st.off[b.dataset.src]; save(); draw(); }; });
    host.querySelectorAll('[data-opt]').forEach((b) => { b.onclick = () => { st[b.dataset.opt] = !st[b.dataset.opt]; save(); draw(); }; });
  };
  draw();
};
})();
